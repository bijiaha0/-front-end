<?php
$lang->menugroup->kevincalendar = 'kevincom';
$lang->kevincalendar = new stdclass();
$lang->kevincalendar->menu = & $lang->kevincom->menu;
$lang->kevincalendar->menuOrder = & $lang->kevincom->menuOrder;
$lang->kevincom->menuOrder[20] = 'kevincalendar';

$lang->kevincom->menu->kevincalendar = array('link' => '日历|kevincalendar|todo', 'subModule' => 'kevincalendar');
