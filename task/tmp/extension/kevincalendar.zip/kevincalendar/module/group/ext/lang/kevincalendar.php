<?php

//kevincalendar
$lang->resource->kevincalendar				 = new stdclass();
$lang->resource->kevincalendar->index		 = 'index';
$lang->resource->kevincalendar->create		 = 'create';
$lang->resource->kevincalendar->edit		 = 'edit';
$lang->resource->kevincalendar->batchcreate	 = 'batchcreate';
$lang->resource->kevincalendar->delete		 = 'delete';
$lang->resource->kevincalendar->lists		 = 'lists';
$lang->resource->kevincalendar->todo		 = 'todo';
$lang->resource->kevincalendar->log			 = 'log';
$lang->resource->kevincalendar->logdelete	 = 'logdelete';
$lang->resource->kevincalendar->logdeleteall = 'logdeleteall';
$lang->resource->kevincalendar->logdeletesql = 'logdeletesql';

$lang->kevincalendar->methodOrder[5]	 = 'index';
$lang->kevincalendar->methodOrder[10]	 = 'create';
$lang->kevincalendar->methodOrder[15]	 = 'edit';
$lang->kevincalendar->methodOrder[25]	 = 'delete';
$lang->kevincalendar->methodOrder[30]	 = 'batchcreate';
$lang->kevincalendar->methodOrder[35]	 = 'lists';
$lang->kevincalendar->methodOrder[37]	 = 'todo';
$lang->kevincalendar->methodOrder[40]	 = 'log';
$lang->kevincalendar->methodOrder[45]	 = 'logdelete';
$lang->kevincalendar->methodOrder[50]	 = 'logdeleteall';
$lang->kevincalendar->methodOrder[55]	 = 'logdeletesql';
