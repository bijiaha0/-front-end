<?php
$config->kevincalendar = new stdclass();

$config->kevincalendar->batchcreate = 8;