<?php
include (dirname(__FILE__) . '/zh-cn.php');