<?php
//db define
define('TABLE_KEVINCALENDAR',          '`' . $config->db->prefix . 'kevincalendar`');

$config->objectTables['kevincalendar']        = TABLE_KEVINCALENDAR;
