<?php

//权限相关
$lang->kevinchart->common = 'Kevin表格';
$lang->kevinchart->index  = '首页';
//base

$lang->kevinchart->YesOrNo[0] = '否';
$lang->kevinchart->YesOrNo[1] = '是';

$lang->kevinchart->index    = '首页';
$lang->kevinchart->view     = '使用视图';
$lang->kevinchart->recently = '最近';
$lang->kevinchart->mychart  = '使用曲线';
$lang->kevinchart->start    = '时间';
$lang->kevinchart->monitor  = '使用';
$lang->kevinchart->myItem   = '我的数据';
$lang->kevinchart->total    = '总数';
$lang->kevinchart->itemlist = '我的报表';
$lang->kevinchart->id			 = 'Id';

$lang->kevinchart->legendBasic    = '基本信息';
$lang->kevinchart->MoreInfor = '更多信息';
$lang->kevinchart->title = 'Kevin表格';

//个人项目工时周期
$lang->kevinchart->periods['today']      = '今天';
$lang->kevinchart->periods['yesterday']  = '昨天';
$lang->kevinchart->periods['thisweek']   = '本周';
$lang->kevinchart->periods['lastweek']   = '上周';
$lang->kevinchart->periods['thismonth']  = '本月';
$lang->kevinchart->periods['lastmonth']  = '上月';
$lang->kevinchart->periods['thisSeason'] = '本季';
$lang->kevinchart->periods['thisYear']   = '本年';
$lang->kevinchart->periods['lastYear']   = '去年';
$lang->kevinchart->periods['all']        = '所有';
$lang->kevinchart->endList[7]            = '一星期';
;
$lang->kevinchart->endList[31]           = '一个月';
$lang->kevinchart->endList[93]           = '三个月';
$lang->kevinchart->endList[186]          = '半年';
$lang->kevinchart->endList[365]          = '一年';
/*
$lang->kevinchart->browse	 = '浏览';
$lang->kevinchart->edit	 = '编辑';
$lang->kevinchart->copy	 = '复制';
$lang->kevinchart->delete	 = '删除';


//table 列名等
$lang->kevinchart->userID		 = '用户ID';
$lang->kevinchart->appID		 = 'Kevin表格ID';
$lang->kevinchart->dept		 = '部门';
$lang->kevinchart->name		 = '名称';
$lang->kevinchart->displayName = '显示名';
$lang->kevinchart->exeName	 = 'Kevin表格名';
$lang->kevinchart->name		 = '名称';
$lang->kevinchart->desc		 = '描述';
$lang->kevinchart->stations	 = '机器';
$lang->kevinchart->module		 = 'Module';
$lang->kevinchart->method		 = 'Method';
$lang->kevinchart->priv		 = 'Priviledge';
$lang->kevinchart->option		 = 'Option';
$lang->kevinchart->inside		 = '内部机器';
$lang->kevinchart->outside	 = '外部机器';
$lang->kevinchart->other		 = 'Others';
$lang->kevinchart->all		 = 'All';
$lang->kevinchart->createdate	 = '创建日期';
$lang->kevinchart->createTime	 = '创建时间';
$lang->kevinchart->value		 = '值';
$lang->kevinchart->visible	 = '可见';
$lang->kevinchart->start	 = '开始时间';
$lang->kevinchart->activeSec	 = '活动时间';
$lang->kevinchart->total	 = '周期';
$lang->kevinchart->userhost	 = '用户@机器';


//table Station
$lang->kevinchart->action	 = '动作';
$lang->kevinchart->desc	 = '说明';
$lang->kevinchart->join	 = '加入日期';
$lang->kevinchart->visits	 = '访问次数';
$lang->kevinchart->name	 = '名称';
$lang->kevinchart->type	 = '类型';
$lang->kevinchart->last	 = '最后登录';
*/
