<?php

$config->kevinchart              = new stdclass();

$config->kevinchart->confirmDelete = true;
