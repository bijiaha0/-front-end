<?php

//kevinchart
$lang->resource->kevinchart = new stdclass();

//resource detail 
$lang->resource->kevinchart->index   = 'index';
$lang->resource->kevinchart->view   = 'view';
$lang->resource->kevinchart->mychart   = 'mychart';
$lang->resource->kevinchart->itemlist   = 'itemlist';

//usage
$lang->kevinchart->methodOrder[5] = 'index';
$lang->kevinchart->methodOrder[15] = 'view';
$lang->kevinchart->methodOrder[25] = 'mychart';
$lang->kevinchart->methodOrder[30] = 'itemlist';
