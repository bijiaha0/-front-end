<?php
//kevin
$lang->resource->kevincom = new stdclass();
$lang->resource->kevincom->index = 'index';
$lang->kevincom->methodOrder[5] = 'index';