<?php
$config->kevincom = new stdclass();