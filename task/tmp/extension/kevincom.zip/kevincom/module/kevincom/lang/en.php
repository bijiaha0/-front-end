<?php
$lang->kevincom->common			= 'KEVIN';
$lang->kevincom->index			= 'Index';