<?php
$lang->kevincom->common			= '凯文';
$lang->kevincom->index			= '首页';
