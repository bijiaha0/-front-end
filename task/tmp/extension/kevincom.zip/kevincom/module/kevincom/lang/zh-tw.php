<?php
$lang->kevincom->common			= 'KEVIN';
$lang->kevincom->index			= '首页';