<?php
if(!isset( $lang->kevincom) ){
    $lang->kevincom    = new stdclass();
    $lang->kevincom->menu  = new stdclass();
    $lang->kevincom->menuOrder = array();
}

$lang->menuOrder[78]	 = 'kevincom';
$lang->kevincom->menuOrder[10] = 'index';
