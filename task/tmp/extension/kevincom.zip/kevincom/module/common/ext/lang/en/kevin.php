<?php
include (dirname(__FILE__) . '/../kevin.php');
$lang->menu->kevincom	= 'KEVIN|kevincom|index';
$lang->kevincom->menu->index  = 'Index|kevincom|index';
$lang->kevincom->kevin = "KEVIN";