<?php
include (dirname(__FILE__) . '/../kevinhours.php');
$lang->kevinhours->menu->my 	= 'my Hours|kevinhours|my|';
$lang->project->menu->kevinhours = array('link' => '工時|kevinhours|project|projectID=%s');
$lang->product->menu->kevinhours = array('link' => '工時|kevinhours|product|productID=%s');


