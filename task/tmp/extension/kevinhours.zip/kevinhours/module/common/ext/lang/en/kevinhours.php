<?php
include (dirname(__FILE__) . '/../kevinhours.php');
$lang->kevinhours->menu->my 	= 'my Hours|kevinhours|my|';
$lang->project->menu->kevinhours = array('link' => 'Hours|kevinhours|project|projectID=%s');
$lang->product->menu->kevinhours = array('link' => 'Hours|kevinhours|product|productID=%s');


