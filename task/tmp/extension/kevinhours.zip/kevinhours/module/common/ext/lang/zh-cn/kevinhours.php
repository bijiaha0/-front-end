<?php
include (dirname(__FILE__) . '/../kevinhours.php');
$lang->kevinhours->menu->my 	= '个人|kevinhours|my|';
$lang->project->menu->kevinhours = array('link' => '工时|kevinhours|project|projectID=%s');
$lang->product->menu->kevinhours = array('link' => '工时|kevinhours|product|productID=%s');


