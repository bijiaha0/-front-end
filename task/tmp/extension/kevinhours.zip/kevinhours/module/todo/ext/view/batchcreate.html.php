<?php include '../../../common/view/header.html.php';?>
<script language=javascript> ;
	var link = createLink('kevinhours', 'batchcreate');
	window.top.location.href=link;   
</script>
