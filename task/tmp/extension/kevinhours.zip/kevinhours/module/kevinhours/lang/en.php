<?php
include (dirname(__FILE__) . '/samelang.php');

$lang->kevinhours->common			 = 'Kevin hours';