<?php
$lang->user->code        = '工号';
$lang->user->deptdispatch        = '服务部门';
