<?php
$lang->user->code        = 'code';
$lang->user->deptdispatch        = 'deptdispatch';
