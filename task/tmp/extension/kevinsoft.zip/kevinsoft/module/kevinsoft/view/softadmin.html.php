<?php
/**
 * @package     kevinsoft
 */
?>
<?php include '../../kevincom/view/header.html.php';?>
<?php include '../../common/view/treeview.html.php';?>

<div class ='main'>
	<br>
   main index page.
</div>
<?php include '../../common/view/footer.html.php';?>