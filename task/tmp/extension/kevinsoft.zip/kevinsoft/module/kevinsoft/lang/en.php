<?php
include (dirname(__FILE__) . '/resource.php');
$lang->kevinsoft->common			= 'Kevin Soft';