<?php
include (dirname(__FILE__) . '/../kevinsoft.php');
