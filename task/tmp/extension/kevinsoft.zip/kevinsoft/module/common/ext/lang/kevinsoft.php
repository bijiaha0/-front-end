<?php
//kevin menu
$lang->kevin->menu->kevinsoft	 =  array('link' => '软件|kevinsoft|softlist', '',
	'alias' => 'softlist,versionlist,groupversionlist,index,modulelist,filelist,statistic');
$lang->kevin->menuOrder[30]		 = 'kevinsoft';

//self menu
$lang->menugroup->kevinsoft = 'kevincom';
$lang->kevinsoft			 = new stdclass();
$lang->kevinsoft->menu		 = new stdclass();

//menu list
$lang->kevinsoft->menu->softlist = '软件列表|kevinsoft|softlist';
$lang->kevinsoft->menu->versionlist = '版本列表|kevinsoft|versionlist';
$lang->kevinsoft->menu->groupversionlist = '组版本列表|kevinsoft|groupversionlist';
$lang->kevinsoft->menu->filelist = '文件列表|kevinsoft|filelist';
$lang->kevinsoft->menu->modulelist = '模块列表|kevinsoft|modulelist';
$lang->kevinsoft->menu->statistic = '统计|kevinsoft|statistic';
$lang->kevinsoft->menu->notes = '说明|kevinsoft|index';

$lang->kevinsoft->menuOrder[10]	 = 'softlist';
$lang->kevinsoft->menuOrder[20]	 = 'versionlist';
$lang->kevinsoft->menuOrder[30]	 = 'groupversionlist';
$lang->kevinsoft->menuOrder[40]	 = 'filelist';
$lang->kevinsoft->menuOrder[50]	 = 'modulelist';
$lang->kevinsoft->menuOrder[60]	 = 'statistic';
$lang->kevinsoft->menuOrder[70]	 = 'notes';
 
