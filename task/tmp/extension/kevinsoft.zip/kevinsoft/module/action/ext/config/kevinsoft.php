<?php
//db define
$config->action->objectNameFields['kevinsoftversion']    = 'name';

