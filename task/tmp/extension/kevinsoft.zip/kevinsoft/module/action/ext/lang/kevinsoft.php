<?php
$lang->action->objectTypes['kevinsoftversion']    = '凯文版本';
$lang->action->label->kevinsoftversion    = '凯文版本|kevinsoft|versionview|softID=%s';




 
