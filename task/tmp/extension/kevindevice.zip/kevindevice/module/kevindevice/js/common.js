function SubmitFormByID(FormIID) {
	document.getElementById(FormIID).submit();
}