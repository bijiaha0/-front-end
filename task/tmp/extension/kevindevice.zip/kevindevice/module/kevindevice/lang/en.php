<?php
include (dirname(__FILE__) . '/resource.php');

$lang->kevindevice->title				 = 'License';
$lang->kevindevice->browse				 = 'Browse';
$lang->kevindevice->edit				 = 'Edit';
$lang->kevindevice->groupcopy				 = 'Copy';
$lang->kevindevice->delete				 = 'Delete';

$lang->kevindevice->id		 = 'Id';
$lang->kevindevice->name	 = 'Name';
$lang->kevindevice->desc	 = 'Desc';
$lang->kevindevice->users	 = 'Users';
$lang->kevindevice->module	 = 'Module';
$lang->kevindevice->method	 = 'Method';
$lang->kevindevice->priv	 = 'Priviledge';
$lang->kevindevice->option	 = 'Option';
$lang->kevindevice->inside	 = 'Group users';
$lang->kevindevice->outside = 'Other users';
$lang->kevindevice->other	 = 'Others';
$lang->kevindevice->all	 = 'All';
