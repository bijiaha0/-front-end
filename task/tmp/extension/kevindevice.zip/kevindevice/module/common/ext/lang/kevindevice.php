﻿<?php
//kevin menu
$lang->kevin->menu->kevindevice	 = array('link' => '设备|kevindevice|devlist', '', 'alias' => 'devlist,grouplist,groupview,devedit,devview,statistic');
$lang->kevin->menuOrder[20]		 = 'kevindevice';

//self menu
$lang->menugroup->kevindevice = 'kevincom';
$lang->kevindevice			 = new stdclass();
$lang->kevindevice->menu		 = new stdclass();

//menu list
$lang->kevindevice->menu->devlist = '设备列表|kevindevice|devlist';
$lang->kevindevice->menu->grouplist = '浏览分组|kevindevice|grouplist';
$lang->kevindevice->menu->statistic = '统计|kevindevice|statistic';

$lang->kevindevice->menuOrder[10]	 = 'index';
$lang->kevindevice->menuOrder[20]	 = 'grouplist';
$lang->kevindevice->menuOrder[30]	 = 'statistic';


