<?php

//kevindevice
$lang->resource->kevindevice = new stdclass();

/* Group. */
$lang->resource->kevindevice = new stdclass();

//group
$lang->resource->kevindevice->grouplist   = 'grouplist';
$lang->resource->kevindevice->groupcreate = 'groupcreate';
$lang->resource->kevindevice->groupedit   = 'groupedit';
$lang->resource->kevindevice->groupdelete = 'groupdelete';
$lang->resource->kevindevice->groupview   = 'groupview';

//dev
$lang->resource->kevindevice->devview   = 'devview';
$lang->resource->kevindevice->devlist   = 'devlist';
$lang->resource->kevindevice->devcreate = 'devcreate';
$lang->resource->kevindevice->devedit   = 'devedit';
$lang->resource->kevindevice->devdelete = 'devdelete';

//statistic
$lang->resource->kevindevice->statistic = 'statistic';

//group
$lang->kevindevice->methodOrder[5]  = 'grouplist';
$lang->kevindevice->methodOrder[10] = 'groupcreate';
$lang->kevindevice->methodOrder[15] = 'groupedit';
$lang->kevindevice->methodOrder[25] = 'groupdelete';
$lang->kevindevice->methodOrder[35] = 'groupview';

//dev
$lang->kevindevice->methodOrder[50] = 'devview';
$lang->kevindevice->methodOrder[53] = 'devlist';
$lang->kevindevice->methodOrder[55] = 'devcreate';
$lang->kevindevice->methodOrder[60] = 'devedit';
$lang->kevindevice->methodOrder[70] = 'devdelete';

//statistic
$lang->kevindevice->methodOrder[80] = 'statistic';

