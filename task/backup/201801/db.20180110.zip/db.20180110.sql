SET NAMES utf8;
DROP TABLE IF EXISTS `zt_action`;
CREATE TABLE `zt_action` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `objectType` varchar(30) NOT NULL DEFAULT '',
  `objectID` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `product` varchar(255) NOT NULL,
  `project` mediumint(9) NOT NULL,
  `actor` varchar(30) NOT NULL DEFAULT '',
  `action` varchar(30) NOT NULL DEFAULT '',
  `date` datetime NOT NULL,
  `comment` text NOT NULL,
  `extra` text NOT NULL,
  `read` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `action` (`objectID`,`product`,`project`,`action`,`date`)
) ENGINE=MyISAM AUTO_INCREMENT=461 DEFAULT CHARSET=utf8;
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('1','user','1',',0,','0','neroyang','login','2016-11-18 19:36:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('2','user','2',',0,','0','wjd','login','2016-11-18 19:53:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('3','product','1',',1,','0','neroyang','opened','2016-11-18 20:20:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('4','product','2',',2,','0','neroyang','opened','2016-11-18 20:22:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('5','product','3',',3,','0','neroyang','opened','2016-11-18 20:23:50','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('6','project','1',',1,2,3,','1','neroyang','opened','2016-11-18 20:25:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('7','story','1',',2,','0','neroyang','opened','2016-11-18 20:28:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('8','project','1',',1,2,3,','1','neroyang','started','2016-11-18 20:31:44','各位加油，加速，comeon。','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('9','user','4',',0,','0','VickySong','login','2016-11-18 20:38:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('10','user','1',',0,','0','neroyang','login','2016-11-18 21:26:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('11','user','3',',0,','0','yuchunyu','login','2016-11-18 21:34:15','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('12','user','7',',0,','0','zhangjian','login','2016-11-18 21:41:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('13','story','2',',2,','0','neroyang','opened','2016-11-18 21:49:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('14','story','3',',1,','0','neroyang','opened','2016-11-18 21:52:01','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('15','story','4',',1,','0','neroyang','opened','2016-11-18 21:52:24','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('16','story','5',',1,','0','neroyang','opened','2016-11-18 21:53:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('17','story','6',',1,','0','neroyang','opened','2016-11-18 21:53:50','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('18','story','6',',1,','0','neroyang','edited','2016-11-18 21:54:20','新闻 相关操作','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('19','story','7',',1,','0','neroyang','opened','2016-11-18 21:54:51','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('20','story','8',',1,','0','neroyang','opened','2016-11-18 21:55:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('21','story','9',',1,','0','neroyang','opened','2016-11-18 21:55:25','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('22','story','10',',1,','0','neroyang','opened','2016-11-18 21:56:10','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('23','user','7',',0,','0','zhangjian','login','2016-11-18 21:56:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('24','user','8',',0,','0','lifeng','login','2016-11-18 21:58:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('25','task','1',',1,2,3,','1','neroyang','opened','2016-11-18 22:00:56','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('26','task','1',',1,2,3,','1','neroyang','started','2016-11-18 22:02:07','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('27','task','2',',1,2,3,','1','neroyang','opened','2016-11-18 22:03:12','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('28','project','2',',,','2','neroyang','opened','2016-11-18 22:08:23','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('29','project','2',',,','2','neroyang','started','2016-11-18 22:10:48','快速上手，fighting','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('30','user','7',',0,','0','zhangjian','login','2016-11-18 22:12:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('31','user','5',',0,','0','bjh','login','2016-11-18 22:13:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('32','user','11',',0,','0','gqf','login','2016-11-18 22:13:19','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('33','todo','1',',0,','0','zhangjian','opened','2016-11-18 22:13:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('34','task','3',',,','2','neroyang','opened','2016-11-18 22:16:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('35','todo','2',',0,','0','gqf','opened','2016-11-18 22:16:15','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('36','task','3',',,','2','neroyang','started','2016-11-18 22:16:26','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('37','user','7',',0,','0','zhangjian','login','2016-11-18 22:17:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('38','task','3',',,','2','neroyang','edited','2016-11-18 22:17:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('39','user','12',',0,','0','szy','login','2016-11-18 22:18:39','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('40','task','4',',,','2','neroyang','opened','2016-11-18 22:22:39','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('41','task','4',',,','2','neroyang','started','2016-11-18 22:22:49','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('42','task','4',',,','2','neroyang','edited','2016-11-18 22:23:01','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('43','user','7',',0,','0','zhangjian','login','2016-11-18 22:24:20','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('44','task','4',',,','2','neroyang','assigned','2016-11-18 23:08:16','','szy','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('45','task','5',',1,2,3,','1','neroyang','opened','2016-11-18 23:16:46','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('46','task','6',',1,2,3,','1','neroyang','opened','2016-11-18 23:18:48','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('47','task','6',',1,2,3,','1','neroyang','finished','2016-11-18 23:20:02','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('48','task','2',',1,2,3,','1','neroyang','started','2016-11-18 23:20:17','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('49','task','2',',1,2,3,','1','neroyang','assigned','2016-11-18 23:20:25','','wjd','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('50','task','5',',1,2,3,','1','neroyang','started','2016-11-18 23:20:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('51','user','10',',0,','0','tyf','login','2016-11-18 23:20:38','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('52','task','5',',1,2,3,','1','neroyang','assigned','2016-11-18 23:20:41','','wjd','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('53','user','10',',0,','0','tyf','login','2016-11-18 23:22:41','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('54','task','7',',,','2','neroyang','opened','2016-11-18 23:25:03','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('55','task','7',',,','2','neroyang','started','2016-11-18 23:25:15','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('56','task','7',',,','2','neroyang','assigned','2016-11-18 23:25:23','','tyf','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('57','user','1',',0,','0','neroyang','logout','2016-11-18 23:31:10','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('58','user','1',',0,','0','neroyang','login','2016-11-18 23:31:49','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('59','user','12',',0,','0','szy','login','2016-11-18 23:35:24','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('60','user','1',',0,','0','neroyang','login','2016-11-19 01:06:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('61','todo','3',',0,','0','neroyang','opened','2016-11-19 01:16:10','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('62','todo','3',',0,','0','neroyang','finished','2016-11-19 01:16:32','','done','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('63','task','8',',1,2,3,','1','neroyang','opened','2016-11-19 01:44:28','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('64','task','8',',1,2,3,','1','neroyang','started','2016-11-19 01:44:36','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('65','task','8',',1,2,3,','1','neroyang','assigned','2016-11-19 01:44:43','','bjh','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('66','doc','1',',0,','2','neroyang','created','2016-11-19 01:47:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('67','doclib','6',',0,','0','neroyang','created','2016-11-19 01:49:30','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('68','doc','2',',0,','1','neroyang','created','2016-11-19 01:50:40','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('69','user','1',',0,','0','neroyang','login','2016-11-19 01:54:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('70','user','7',',0,','0','zhangjian','login','2016-11-19 08:48:36','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('71','todo','4',',0,','0','zhangjian','opened','2016-11-19 08:50:45','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('72','user','1',',0,','0','neroyang','login','2016-11-19 13:07:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('73','task','9',',,','2','neroyang','opened','2016-11-19 13:21:29','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('74','task','9',',,','2','neroyang','started','2016-11-19 13:22:14','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('75','task','9',',,','2','neroyang','assigned','2016-11-19 13:22:21','','lifeng','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('76','task','10',',1,2,3,','1','neroyang','opened','2016-11-19 13:28:14','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('77','task','11',',1,2,3,','1','neroyang','opened','2016-11-19 13:29:42','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('78','task','12',',1,2,3,','1','neroyang','opened','2016-11-19 13:31:20','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('79','task','10',',1,2,3,','1','neroyang','started','2016-11-19 13:32:20','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('80','task','12',',1,2,3,','1','neroyang','started','2016-11-19 13:33:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('81','task','12',',1,2,3,','1','neroyang','assigned','2016-11-19 13:33:31','','yuchunyu','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('82','todo','3',',0,','0','neroyang','erased','2016-11-19 13:42:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('83','task','11',',1,2,3,','1','neroyang','edited','2016-11-19 13:44:17','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('84','task','11',',1,2,3,','1','neroyang','started','2016-11-19 13:44:32','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('85','doclib','7',',0,','0','neroyang','created','2016-11-19 13:46:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('86','doclib','7',',0,','0','neroyang','deleted','2016-11-19 13:46:21','','1','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('87','doclib','8',',0,','0','neroyang','created','2016-11-19 13:46:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('88','doclib','9',',0,','0','neroyang','created','2016-11-19 13:47:08','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('89','task','12',',1,2,3,','1','neroyang','finished','2016-11-19 13:49:54','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('90','doclib','10',',0,','0','neroyang','created','2016-11-19 14:59:07','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('91','doc','3',',0,','0','neroyang','created','2016-11-19 15:00:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('92','user','11',',0,','0','gqf','login','2016-11-19 15:00:47','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('93','user','1',',0,','0','neroyang','login','2016-11-19 15:01:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('94','doc','3',',0,','0','gqf','commented','2016-11-19 15:04:26','<p>gqf</p>','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('95','task','1',',1,2,3,','1','neroyang','edited','2016-11-19 15:04:34','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('96','task','5',',1,2,3,','1','neroyang','deleted','2016-11-19 15:06:45','','1','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('97','task','6',',1,2,3,','1','neroyang','closed','2016-11-19 15:12:22','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('98','user','10',',0,','0','tyf','login','2016-11-19 15:29:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('99','task','12',',1,2,3,','1','neroyang','closed','2016-11-19 16:19:47','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('100','user','7',',0,','0','zhangjian','login','2016-11-19 16:43:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('101','user','1',',0,','0','neroyang','login','2016-11-19 17:51:34','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('102','user','9',',0,','0','tws','login','2016-11-19 18:36:41','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('103','user','9',',0,','0','tws','logout','2016-11-19 18:37:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('104','user','9',',0,','0','tws','login','2016-11-19 18:40:37','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('105','user','1',',0,','0','neroyang','login','2016-11-19 20:08:27','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('106','user','1',',0,','0','neroyang','login','2016-11-19 22:27:56','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('107','user','1',',0,','0','neroyang','login','2016-11-20 00:02:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('108','user','1',',0,','0','neroyang','login','2016-11-20 14:03:30','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('109','user','1',',0,','0','neroyang','login','2016-11-20 14:48:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('110','task','10',',1,2,3,','1','neroyang','finished','2016-11-20 14:48:59','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('111','doclib','11',',0,','0','neroyang','created','2016-11-20 15:07:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('112','doc','4',',1,','0','neroyang','created','2016-11-20 15:07:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('113','doc','5',',1,','0','neroyang','created','2016-11-20 15:08:18','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('114','doc','6',',1,','0','neroyang','created','2016-11-20 15:09:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('115','doc','4',',1,','0','neroyang','edited','2016-11-20 15:10:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('116','doc','7',',1,','0','neroyang','created','2016-11-20 15:16:40','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('117','user','10',',0,','0','tyf','login','2016-11-20 15:26:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('118','user','12',',0,','0','szy','login','2016-11-20 15:30:07','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('119','user','1',',0,','0','neroyang','login','2016-11-20 15:56:58','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('120','user','1',',0,','0','neroyang','login','2016-11-20 19:31:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('121','user','1',',0,','0','neroyang','login','2016-11-20 20:38:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('122','user','1',',0,','0','neroyang','login','2016-11-21 00:36:19','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('123','doclib','12',',0,','0','neroyang','created','2016-11-21 01:24:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('124','doc','8',',0,','0','neroyang','created','2016-11-21 01:43:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('125','doc','8',',0,','0','neroyang','edited','2016-11-21 01:44:39','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('126','doc','8',',0,','0','neroyang','edited','2016-11-21 01:47:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('127','doc','8',',0,','0','neroyang','edited','2016-11-21 01:49:47','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('128','doc','8',',0,','0','neroyang','edited','2016-11-21 01:50:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('129','doc','8',',0,','0','neroyang','edited','2016-11-21 01:51:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('130','user','5',',0,','0','bjh','login','2016-11-21 03:44:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('131','user','5',',0,','0','bjh','login','2016-11-21 03:45:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('132','user','1',',0,','0','neroyang','login','2016-11-21 12:02:40','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('133','user','1',',0,','0','neroyang','login','2016-11-21 12:44:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('134','user','1',',0,','0','neroyang','login','2016-11-21 17:25:29','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('135','user','1',',0,','0','neroyang','login','2016-11-21 19:21:41','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('136','user','1',',0,','0','neroyang','login','2016-11-21 22:17:27','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('137','user','1',',0,','0','neroyang','login','2016-11-22 02:40:29','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('138','user','10',',0,','0','tyf','login','2016-11-22 12:42:24','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('139','user','10',',0,','0','tyf','login','2016-11-22 12:44:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('140','user','1',',0,','0','neroyang','login','2016-11-22 13:36:27','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('141','doc','9',',0,','0','neroyang','created','2016-11-22 13:50:39','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('142','doc','9',',0,','0','neroyang','edited','2016-11-22 13:52:45','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('143','doc','9',',0,','0','neroyang','edited','2016-11-22 13:56:04','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('144','doc','9',',0,','0','neroyang','edited','2016-11-22 13:56:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('145','doclib','13',',0,','0','neroyang','created','2016-11-22 13:57:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('146','doc','10',',1,','0','neroyang','created','2016-11-22 13:58:55','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('147','doc','9',',0,','0','neroyang','deleted','2016-11-22 13:59:05','','1','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('148','user','5',',0,','0','bjh','login','2016-11-22 14:41:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('149','doc','10',',1,','0','neroyang','edited','2016-11-22 14:51:36','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('150','doc','10',',1,','0','neroyang','edited','2016-11-22 14:56:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('151','task','11',',1,2,3,','1','neroyang','canceled','2016-11-22 14:58:43','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('152','doc','10',',1,','0','neroyang','edited','2016-11-22 15:01:15','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('153','user','1',',0,','0','neroyang','login','2016-11-22 16:19:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('154','user','1',',0,','0','neroyang','login','2016-11-22 19:45:25','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('155','task','13',',1,2,3,','1','neroyang','opened','2016-11-22 19:54:39','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('156','task','14',',1,2,3,','1','neroyang','opened','2016-11-22 19:55:01','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('157','task','15',',1,2,3,','1','neroyang','opened','2016-11-22 19:55:23','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('158','task','15',',1,2,3,','1','neroyang','finished','2016-11-22 19:55:39','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('159','task','14',',1,2,3,','1','neroyang','finished','2016-11-22 19:55:44','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('160','task','13',',1,2,3,','1','neroyang','finished','2016-11-22 19:55:50','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('161','task','16',',1,2,3,','1','neroyang','opened','2016-11-22 19:56:20','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('162','task','16',',1,2,3,','1','neroyang','finished','2016-11-22 19:56:27','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('163','task','17',',1,2,3,','1','neroyang','opened','2016-11-22 19:57:31','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('164','task','18',',1,2,3,','1','neroyang','opened','2016-11-22 19:58:27','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('165','task','19',',1,2,3,','1','neroyang','opened','2016-11-22 19:58:54','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('166','task','20',',1,2,3,','1','neroyang','opened','2016-11-22 19:59:19','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('167','task','21',',1,2,3,','1','neroyang','opened','2016-11-22 19:59:35','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('168','task','21',',1,2,3,','1','neroyang','finished','2016-11-22 19:59:40','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('169','task','20',',1,2,3,','1','neroyang','finished','2016-11-22 19:59:47','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('170','task','19',',1,2,3,','1','neroyang','finished','2016-11-22 19:59:52','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('171','task','22',',1,2,3,','1','neroyang','opened','2016-11-22 20:00:47','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('172','task','22',',1,2,3,','1','neroyang','finished','2016-11-22 20:00:55','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('173','task','11',',1,2,3,','1','neroyang','activated','2016-11-22 20:01:21','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('174','task','2',',1,2,3,','1','neroyang','canceled','2016-11-22 20:01:57','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('175','task','23',',1,2,3,','1','neroyang','opened','2016-11-22 20:03:01','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('176','task','24',',1,2,3,','1','neroyang','opened','2016-11-22 20:05:01','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('177','task','25',',1,2,3,','1','neroyang','opened','2016-11-22 20:05:54','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('178','task','26',',1,2,3,','1','neroyang','opened','2016-11-22 20:06:20','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('179','task','27',',1,2,3,','1','neroyang','opened','2016-11-22 20:06:47','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('180','task','27',',1,2,3,','1','neroyang','finished','2016-11-22 20:07:00','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('181','task','1',',1,2,3,','1','neroyang','edited','2016-11-22 20:17:24','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('182','task','28',',1,2,3,','1','neroyang','opened','2016-11-22 20:18:00','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('183','task','10',',1,2,3,','1','neroyang','activated','2016-11-22 20:18:47','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('184','task','6',',1,2,3,','1','neroyang','activated','2016-11-22 20:19:27','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('185','task','6',',1,2,3,','1','neroyang','canceled','2016-11-22 20:19:39','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('186','user','1',',0,','0','neroyang','login','2016-11-22 23:13:14','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('187','user','1',',0,','0','neroyang','login','2016-11-23 00:57:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('188','user','1',',0,','0','neroyang','login','2016-11-23 11:36:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('189','user','4',',0,','0','VickySong','login','2016-11-23 13:08:39','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('190','user','1',',0,','0','neroyang','login','2016-11-23 14:45:35','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('191','task','29',',1,2,3,','1','neroyang','opened','2016-11-23 14:46:24','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('192','user','1',',0,','0','neroyang','login','2016-11-23 15:11:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('193','task','29',',1,2,3,','1','neroyang','edited','2016-11-23 15:13:03','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('194','project','1',',1,2,3,','1','neroyang','edited','2016-11-23 15:15:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('195','task','30',',1,2,3,','1','neroyang','opened','2016-11-23 15:19:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('196','task','30',',1,2,3,','1','neroyang','started','2016-11-23 15:19:31','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('197','task','30',',1,2,3,','1','neroyang','assigned','2016-11-23 15:19:45','','yuchunyu','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('198','task','29',',1,2,3,','1','neroyang','started','2016-11-23 15:19:52','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('199','task','6',',1,2,3,','1','neroyang','activated','2016-11-23 15:20:47','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('200','task','28',',1,2,3,','1','neroyang','edited','2016-11-23 16:05:00','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('201','task','26',',1,2,3,','1','neroyang','edited','2016-11-23 16:05:37','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('202','task','25',',1,2,3,','1','neroyang','edited','2016-11-23 16:05:53','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('203','task','24',',1,2,3,','1','neroyang','edited','2016-11-23 16:06:06','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('204','task','23',',1,2,3,','1','neroyang','edited','2016-11-23 16:06:28','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('205','task','18',',1,2,3,','1','neroyang','edited','2016-11-23 16:06:45','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('206','task','17',',1,2,3,','1','neroyang','edited','2016-11-23 16:07:00','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('207','task','1',',1,2,3,','1','neroyang','edited','2016-11-23 16:07:18','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('208','task','30',',1,2,3,','1','neroyang','edited','2016-11-23 16:07:36','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('209','task','29',',1,2,3,','1','neroyang','edited','2016-11-23 16:07:51','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('210','task','11',',1,2,3,','1','neroyang','edited','2016-11-23 16:08:24','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('211','task','10',',1,2,3,','1','neroyang','edited','2016-11-23 16:08:41','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('212','task','8',',1,2,3,','1','neroyang','edited','2016-11-23 16:08:55','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('213','task','6',',1,2,3,','1','neroyang','edited','2016-11-23 16:09:16','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('214','task','27',',1,2,3,','1','neroyang','edited','2016-11-23 16:09:31','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('215','task','27',',1,2,3,','1','neroyang','edited','2016-11-23 16:09:46','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('216','task','22',',1,2,3,','1','neroyang','edited','2016-11-23 16:10:05','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('217','task','21',',1,2,3,','1','neroyang','edited','2016-11-23 16:10:19','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('218','task','20',',1,2,3,','1','neroyang','edited','2016-11-23 16:10:36','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('219','task','19',',1,2,3,','1','neroyang','edited','2016-11-23 16:10:50','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('220','task','16',',1,2,3,','1','neroyang','edited','2016-11-23 16:11:10','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('221','task','15',',1,2,3,','1','neroyang','edited','2016-11-23 16:11:25','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('222','task','14',',1,2,3,','1','neroyang','edited','2016-11-23 16:11:39','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('223','task','13',',1,2,3,','1','neroyang','edited','2016-11-23 16:11:53','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('224','task','2',',1,2,3,','1','neroyang','edited','2016-11-23 16:12:07','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('225','user','1',',0,','0','neroyang','login','2016-11-23 17:22:07','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('226','user','1',',0,','0','neroyang','login','2016-11-23 21:19:19','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('227','doclib','14',',0,','0','neroyang','created','2016-11-23 21:58:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('228','doc','11',',0,','0','neroyang','created','2016-11-23 22:06:27','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('229','doc','11',',0,','0','neroyang','edited','2016-11-23 22:09:49','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('230','doc','11',',0,','0','neroyang','edited','2016-11-23 22:10:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('231','user','5',',0,','0','bjh','login','2016-11-23 22:10:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('232','doc','11',',0,','0','neroyang','edited','2016-11-23 22:20:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('233','doc','11',',0,','0','neroyang','edited','2016-11-23 22:25:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('234','user','1',',0,','0','neroyang','login','2016-11-23 23:40:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('235','user','1',',0,','0','neroyang','login','2016-11-24 14:50:26','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('236','user','1',',0,','0','neroyang','login','2016-11-24 15:43:40','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('237','doc','12',',0,','0','neroyang','created','2016-11-24 15:56:46','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('238','doc','12',',0,','0','neroyang','commented','2016-11-24 16:27:26','<p>I have invited NodeX think-tanks</p>','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('239','user','1',',0,','0','neroyang','login','2016-11-24 20:26:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('240','user','1',',0,','0','neroyang','login','2016-11-24 21:12:41','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('241','task','29',',1,2,3,','1','neroyang','finished','2016-11-24 21:12:58','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('242','doc','13',',0,','0','neroyang','created','2016-11-24 21:34:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('243','user','8',',0,','0','lifeng','login','2016-11-24 21:41:00','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('244','user','8',',0,','0','lifeng','logout','2016-11-24 21:43:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('245','user','6',',0,','0','czw','login','2016-11-24 21:43:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('246','task','31',',1,2,3,','1','neroyang','opened','2016-11-24 22:15:25','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('247','task','31',',1,2,3,','1','neroyang','started','2016-11-24 22:15:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('248','user','1',',0,','0','neroyang','login','2016-11-25 00:06:48','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('249','task','31',',1,2,3,','1','neroyang','assigned','2016-11-25 00:07:25','','czw','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('250','user','1',',0,','0','neroyang','login','2016-11-25 02:20:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('251','user','1',',0,','0','neroyang','login','2016-11-25 13:13:23','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('252','task','6',',1,2,3,','1','neroyang','finished','2016-11-25 13:14:13','','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('253','task','2',',1,2,3,','1','neroyang','activated','2016-11-25 13:14:31','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('254','task','1',',1,2,3,','1','neroyang','started','2016-11-25 14:04:27','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('255','doc','14',',0,','1','neroyang','created','2016-11-25 14:18:00','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('256','task','32',',1,2,3,','1','neroyang','opened','2016-11-25 14:36:51','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('257','task','31',',1,2,3,','1','neroyang','edited','2016-11-25 14:38:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('258','task','3',',,','2','neroyang','finished','2016-11-25 14:54:36','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('259','user','7',',0,','0','zhangjian','login','2016-11-25 15:08:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('260','user','6',',0,','0','czw','login','2016-11-25 15:39:14','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('261','user','2',',0,','0','wjd','login','2016-11-25 17:33:41','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('262','task','9',',,','2','wjd','edited','2016-11-25 17:45:20','上传了附件 laravel-v5.1.11
<p>本次学习需要完成的任务：</p>
<p>1.基本了解laravel框架的整体结构，包括路由、中间件、模型、控制器、数据库入门等（view不需要了解，blade引擎也不需要了解）。</p>
<p>2.使用Eloquent ORM进行简单的数据库的增删改查操作。</p>','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('263','user','1',',0,','0','neroyang','login','2016-11-25 18:27:37','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('264','user','7',',0,','0','zhangjian','login','2016-11-25 19:00:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('265','task','8',',1,2,3,','1','neroyang','finished','2016-11-25 19:37:29','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('266','doc','15',',1,','0','neroyang','created','2016-11-25 20:04:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('267','user','5',',0,','0','bjh','login','2016-11-25 20:05:44','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('268','user','1',',0,','0','neroyang','login','2016-11-25 22:46:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('269','task','33',',1,2,3,','1','neroyang','opened','2016-11-25 22:47:25','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('270','task','33',',1,2,3,','1','neroyang','started','2016-11-25 22:47:35','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('271','user','1',',0,','0','neroyang','login','2016-11-26 14:12:44','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('272','user','1',',0,','0','neroyang','login','2016-11-27 02:33:43','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('273','task','10',',1,2,3,','1','neroyang','finished','2016-11-27 02:33:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('274','task','33',',1,2,3,','1','neroyang','finished','2016-11-27 02:34:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('275','task','1',',1,2,3,','1','neroyang','finished','2016-11-27 02:34:19','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('276','task','24',',1,2,3,','1','neroyang','started','2016-11-27 02:35:40','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('277','task','26',',1,2,3,','1','neroyang','canceled','2016-11-27 02:35:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('278','user','1',',0,','0','neroyang','login','2016-11-27 13:34:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('279','user','1',',0,','0','neroyang','login','2016-11-27 15:33:29','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('280','user','1',',0,','0','neroyang','login','2016-11-27 17:44:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('281','task','25',',1,2,3,','1','neroyang','finished','2016-11-27 17:44:26','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('282','user','12',',0,','0','szy','login','2016-11-27 20:49:48','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('283','user','12',',0,','0','szy','login','2016-11-27 20:54:04','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('284','user','1',',0,','0','neroyang','login','2016-11-28 00:28:27','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('285','user','1',',0,','0','neroyang','login','2016-11-28 18:24:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('286','user','1',',0,','0','neroyang','login','2016-11-28 18:46:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('287','doc','16',',1,','0','neroyang','created','2016-11-28 18:50:15','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('288','doc','16',',1,','0','neroyang','edited','2016-11-28 18:50:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('289','doc','16',',1,','0','neroyang','edited','2016-11-28 18:50:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('290','task','34',',1,2,3,','1','neroyang','opened','2016-11-28 18:52:30','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('291','task','35',',1,2,3,','1','neroyang','opened','2016-11-28 18:53:00','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('292','user','5',',0,','0','bjh','login','2016-11-28 19:15:46','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('293','doc','16',',1,','0','neroyang','edited','2016-11-28 19:20:41','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('294','doc','16',',1,','0','neroyang','edited','2016-11-28 19:21:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('295','user','1',',0,','0','neroyang','login','2016-11-29 16:47:36','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('296','user','5',',0,','0','bjh','login','2016-11-29 20:25:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('297','user','12',',0,','0','szy','login','2016-11-29 20:28:54','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('298','user','1',',0,','0','neroyang','login','2016-11-30 19:55:46','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('299','user','12',',0,','0','szy','login','2016-11-30 21:40:40','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('300','user','12',',0,','0','szy','login','2016-11-30 22:52:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('301','task','4',',,','2','szy','finished','2016-11-30 23:20:30','页面用div分块大致能看懂了，但向其中插入图片存在问题，图片只显示一小部分。','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('302','user','1',',0,','0','neroyang','login','2016-12-01 00:08:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('303','task','4',',,','2','neroyang','commented','2016-12-01 00:08:44','你发张截图','','1');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('304','user','9',',0,','0','tws','login','2016-12-01 16:03:45','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('305','user','12',',0,','0','szy','login','2016-12-01 17:12:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('306','user','1',',0,','0','neroyang','login','2016-12-02 15:57:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('307','user','10',',0,','0','tyf','login','2016-12-02 16:00:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('308','user','1',',0,','0','neroyang','login','2016-12-02 17:38:19','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('309','doclib','15',',0,','0','neroyang','created','2016-12-02 17:38:43','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('310','doc','17',',0,','0','neroyang','created','2016-12-02 17:39:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('311','doc','18',',0,','0','neroyang','created','2016-12-02 17:39:36','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('312','doc','19',',0,','0','neroyang','created','2016-12-02 17:39:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('313','doc','20',',0,','0','neroyang','created','2016-12-02 17:40:14','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('314','doc','21',',0,','0','neroyang','created','2016-12-02 17:40:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('315','doc','20',',0,','0','neroyang','edited','2016-12-02 17:50:37','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('316','doc','19',',0,','0','neroyang','edited','2016-12-02 18:15:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('317','user','1',',0,','0','neroyang','login','2016-12-02 22:59:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('318','user','13',',0,','0','zyf','login','2016-12-03 00:36:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('319','user','1',',0,','0','neroyang','login','2016-12-03 00:50:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('320','user','15',',0,','0','huanghao','login','2016-12-03 00:51:41','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('321','user','16',',0,','0','jiangpeng','login','2016-12-03 00:53:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('322','user','15',',0,','0','huanghao','login','2016-12-03 08:48:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('323','user','15',',0,','0','huanghao','login','2016-12-03 08:51:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('324','user','13',',0,','0','zyf','login','2016-12-03 11:42:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('325','user','1',',0,','0','neroyang','login','2016-12-03 17:48:10','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('326','user','14',',0,','0','zmh','login','2016-12-03 19:47:01','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('327','user','14',',0,','0','zmh','login','2016-12-03 19:55:46','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('328','user','15',',0,','0','huanghao','login','2016-12-03 20:05:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('329','user','17',',0,','0','xrs','login','2016-12-03 20:38:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('330','user','14',',0,','0','zmh','login','2016-12-03 22:46:49','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('331','user','1',',0,','0','neroyang','login','2016-12-04 01:18:30','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('332','user','1',',0,','0','neroyang','login','2016-12-05 17:50:20','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('333','user','1',',0,','0','neroyang','login','2016-12-07 00:07:48','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('334','user','19',',0,','0','rwb','login','2016-12-07 08:37:43','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('335','user','1',',0,','0','neroyang','login','2016-12-07 12:15:38','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('336','user','19',',0,','0','rwb','login','2016-12-07 12:55:47','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('337','user','12',',0,','0','szy','login','2016-12-07 18:57:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('338','user','18',',0,','0','zxt','login','2016-12-07 23:10:29','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('339','user','18',',0,','0','zxt','login','2016-12-09 15:19:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('340','user','1',',0,','0','neroyang','login','2016-12-09 19:06:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('341','user','1',',0,','0','neroyang','login','2016-12-10 01:22:44','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('342','user','19',',0,','0','rwb','login','2016-12-10 16:20:38','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('343','user','1',',0,','0','neroyang','login','2016-12-11 16:35:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('344','doc','22',',0,','1','neroyang','created','2016-12-11 16:36:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('345','doc','22',',0,','1','neroyang','edited','2016-12-11 16:36:28','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('346','user','1',',0,','0','neroyang','login','2016-12-11 19:31:31','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('347','doc','22',',0,','1','neroyang','edited','2016-12-11 19:31:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('348','user','12',',0,','0','szy','login','2016-12-11 19:41:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('349','user','11',',0,','0','gqf','login','2016-12-11 19:56:47','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('350','user','7',',0,','0','zhangjian','login','2016-12-11 21:04:26','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('351','user','1',',0,','0','neroyang','login','2016-12-11 21:50:18','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('352','user','12',',0,','0','szy','login','2016-12-11 22:39:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('353','user','12',',0,','0','szy','login','2016-12-12 10:02:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('354','user','10',',0,','0','tyf','login','2016-12-12 16:07:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('355','user','1',',0,','0','neroyang','login','2016-12-13 00:00:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('356','user','19',',0,','0','rwb','login','2016-12-13 09:43:04','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('357','user','16',',0,','0','jiangpeng','login','2016-12-13 20:44:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('358','user','16',',0,','0','jiangpeng','login','2016-12-13 20:46:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('359','user','8',',0,','0','lifeng','login','2016-12-14 14:22:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('360','user','11',',0,','0','gqf','login','2016-12-16 13:13:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('361','user','11',',0,','0','gqf','login','2016-12-16 13:29:38','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('362','user','11',',0,','0','gqf','login','2016-12-16 16:12:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('363','user','10',',0,','0','tyf','login','2016-12-16 16:12:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('364','user','10',',0,','0','tyf','login','2016-12-16 20:31:27','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('365','user','1',',0,','0','neroyang','login','2016-12-16 21:36:54','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('366','user','1',',0,','0','neroyang','login','2016-12-18 02:26:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('367','user','11',',0,','0','gqf','login','2016-12-25 16:50:23','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('368','user','1',',0,','0','neroyang','login','2016-12-25 16:57:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('369','doc','23',',0,','1','neroyang','created','2016-12-25 17:00:31','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('370','user','1',',0,','0','neroyang','login','2016-12-25 19:03:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('371','user','5',',0,','0','bjh','login','2016-12-25 19:05:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('372','user','5',',0,','0','bjh','login','2016-12-25 19:05:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('373','doc','10',',1,','0','neroyang','edited','2016-12-25 19:26:31','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('374','doc','10',',1,','0','neroyang','edited','2016-12-25 19:26:51','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('375','user','5',',0,','0','bjh','login','2016-12-25 21:24:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('376','user','15',',0,','0','huanghao','login','2016-12-26 16:34:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('377','user','1',',0,','0','neroyang','login','2016-12-26 17:42:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('378','user','10',',0,','0','tyf','login','2016-12-26 19:30:58','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('379','user','1',',0,','0','neroyang','login','2016-12-26 19:36:10','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('380','user','1',',0,','0','neroyang','login','2016-12-27 19:56:35','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('381','user','10',',0,','0','tyf','login','2017-01-12 23:02:01','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('382','user','10',',0,','0','tyf','login','2017-01-14 23:52:59','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('383','user','12',',0,','0','szy','login','2017-01-16 09:41:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('384','user','5',',0,','0','bjh','login','2017-01-16 12:18:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('385','user','1',',0,','0','neroyang','login','2017-01-16 12:50:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('386','user','21',',0,','0','qzw','login','2017-01-16 12:52:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('387','user','1',',0,','0','neroyang','login','2017-01-20 11:03:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('388','doc','24',',1,','0','neroyang','created','2017-01-20 11:04:04','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('389','user','1',',0,','0','neroyang','login','2017-01-20 11:11:50','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('390','doc','24',',1,','0','neroyang','edited','2017-01-20 11:21:25','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('391','doc','24',',1,','0','neroyang','edited','2017-01-20 11:22:11','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('392','doc','24',',1,','0','neroyang','edited','2017-01-20 11:25:58','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('393','user','5',',0,','0','bjh','login','2017-01-20 11:27:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('394','user','1',',0,','0','neroyang','login','2017-01-20 16:40:46','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('395','user','11',',0,','0','gqf','login','2017-01-23 17:46:34','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('396','todo','2',',0,','0','gqf','finished','2017-01-23 17:48:02','','done','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('397','user','5',',0,','0','bjh','login','2017-01-23 17:51:03','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('398','user','12',',0,','0','szy','login','2017-02-01 11:53:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('399','user','5',',0,','0','bjh','login','2017-02-01 12:25:01','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('400','user','9',',0,','0','tws','login','2017-02-03 23:15:30','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('401','user','9',',0,','0','tws','login','2017-02-15 13:30:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('402','user','1',',0,','0','neroyang','login','2017-02-24 16:38:44','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('403','user','1',',0,','0','neroyang','logout','2017-02-24 16:46:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('404','user','22',',0,','0','que1240434456','login','2017-02-24 16:47:04','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('405','user','22',',0,','0','que1240434456','logout','2017-02-24 16:47:21','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('406','user','22',',0,','0','que1240434456','login','2017-02-24 16:47:49','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('407','user','22',',0,','0','que1240434456','logout','2017-02-24 16:48:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('408','user','1',',0,','0','neroyang','login','2017-02-24 16:49:44','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('409','user','1',',0,','0','neroyang','logout','2017-02-24 16:50:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('410','user','22',',0,','0','que1240434456','login','2017-02-24 16:50:53','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('411','user','22',',0,','0','que1240434456','logout','2017-02-24 16:51:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('412','user','1',',0,','0','neroyang','login','2017-02-24 16:51:23','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('413','user','20',',0,','0','neroyang','deleted','2017-02-24 16:51:49','','1','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('414','user','1',',0,','0','neroyang','logout','2017-02-24 16:52:23','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('415','user','22',',0,','0','que1240434456','login','2017-02-24 16:52:42','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('416','user','22',',0,','0','que1240434456','logout','2017-02-24 16:52:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('417','user','1',',0,','0','neroyang','login','2017-02-24 16:53:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('418','user','1',',0,','0','neroyang','logout','2017-02-24 16:53:47','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('419','user','22',',0,','0','que1240434456','login','2017-02-24 16:54:06','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('420','user','22',',0,','0','que1240434456','logout','2017-02-24 17:27:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('421','user','1',',0,','0','neroyang','login','2017-02-24 17:27:33','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('422','user','1',',0,','0','neroyang','logout','2017-02-24 17:28:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('423','user','22',',0,','0','que1240434456','login','2017-02-24 17:28:43','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('424','doclib','16',',0,','0','que1240434456','created','2017-02-24 17:30:38','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('425','user','10',',0,','0','tyf','login','2017-02-25 09:37:13','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('426','user','1',',0,','0','neroyang','login','2017-02-26 22:53:10','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('427','user','1',',0,','0','neroyang','login','2017-02-28 16:26:24','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('428','user','1',',0,','0','neroyang','login','2017-03-01 15:01:09','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('429','user','10',',0,','0','tyf','login','2017-03-17 19:52:58','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('430','user','10',',0,','0','tyf','login','2017-03-18 09:00:23','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('431','user','10',',0,','0','tyf','login','2017-03-21 09:23:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('432','user','10',',0,','0','tyf','login','2017-03-21 14:46:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('433','user','12',',0,','0','szy','login','2017-03-24 22:16:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('434','user','10',',0,','0','tyf','login','2017-03-26 14:30:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('435','user','1',',0,','0','neroyang','login','2017-03-26 15:16:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('436','doc','25',',0,','1','neroyang','created','2017-03-26 15:18:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('437','doc','26',',0,','1','neroyang','created','2017-03-26 15:18:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('438','doc','27',',0,','1','neroyang','created','2017-03-26 15:21:32','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('439','user','10',',0,','0','tyf','login','2017-03-26 20:59:17','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('440','user','10',',0,','0','tyf','login','2017-03-26 21:03:05','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('441','user','10',',0,','0','tyf','login','2017-03-26 21:20:38','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('442','user','10',',0,','0','tyf','login','2017-03-26 22:10:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('443','user','10',',0,','0','tyf','login','2017-03-27 00:59:48','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('444','user','10',',0,','0','tyf','login','2017-03-27 11:04:45','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('445','user','10',',0,','0','tyf','login','2017-03-27 11:59:08','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('446','user','10',',0,','0','tyf','login','2017-03-27 19:24:22','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('447','user','10',',0,','0','tyf','login','2017-03-28 10:57:43','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('448','user','10',',0,','0','tyf','login','2017-03-29 18:31:40','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('449','user','10',',0,','0','tyf','login','2017-03-30 10:02:49','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('450','user','9',',0,','0','tws','login','2017-04-15 12:55:00','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('451','user','1',',0,','0','neroyang','login','2017-06-16 02:05:12','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('452','task','24',',1,2,3,','1','neroyang','finished','2017-06-16 02:06:02','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('453','task','30',',1,2,3,','1','neroyang','finished','2017-06-16 02:06:18','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('454','task','2',',1,2,3,','1','neroyang','finished','2017-06-16 02:06:29','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('455','task','32',',1,2,3,','1','neroyang','started','2017-06-16 02:06:52','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('456','user','11',',0,','0','gqf','login','2017-07-03 09:35:57','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('457','user','10',',0,','0','tyf','login','2017-07-10 15:42:16','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('458','user','10',',0,','0','tyf','login','2017-08-29 20:17:30','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('459','user','10',',0,','0','tyf','login','2017-11-15 19:55:35','','','0');
INSERT INTO `zt_action`(`id`,`objectType`,`objectID`,`product`,`project`,`actor`,`action`,`date`,`comment`,`extra`,`read`) VALUES ('460','user','1',',0,','0','neroyang','login','2017-11-19 15:05:02','','','0');
DROP TABLE IF EXISTS `zt_block`;
CREATE TABLE `zt_block` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(30) NOT NULL,
  `module` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `source` varchar(20) NOT NULL,
  `block` varchar(20) NOT NULL,
  `params` text NOT NULL,
  `order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `accountModuleOrder` (`account`,`module`,`order`),
  KEY `block` (`account`,`module`)
) ENGINE=MyISAM AUTO_INCREMENT=205 DEFAULT CHARSET=utf8;
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('1','neroyang','my','流程图','','flowchart','{\"color\":\"default\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('2','neroyang','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('3','neroyang','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('4','neroyang','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('5','neroyang','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('6','neroyang','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('7','neroyang','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('8','neroyang','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('9','neroyang','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('10','neroyang','product','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('11','neroyang','product','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('12','neroyang','project','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('13','neroyang','project','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('14','wjd','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('15','wjd','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('16','wjd','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('17','wjd','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('18','wjd','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('19','wjd','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('20','wjd','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('21','wjd','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('22','wjd','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('23','neroyang','qa','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','1','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('24','neroyang','qa','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('25','neroyang','qa','待测版本列表','qa','testtask','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"wait\"}','3','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('26','yuchunyu','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('27','yuchunyu','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('28','yuchunyu','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('29','yuchunyu','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('30','yuchunyu','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('31','yuchunyu','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('32','yuchunyu','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('33','yuchunyu','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('34','yuchunyu','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('35','zhangjian','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('36','zhangjian','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('37','zhangjian','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('38','zhangjian','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('39','zhangjian','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('40','zhangjian','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('41','zhangjian','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('42','zhangjian','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('43','zhangjian','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('44','neroyang','product','计划列表','product','plan','{\"color\":\"default\",\"num\":\"20\"}','3','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('45','neroyang','product','需求列表','product','story','{\"color\":\"default\",\"type\":\"assignedTo\",\"num\":\"20\",\"orderBy\":\"id_desc\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('46','neroyang','product','发布列表','product','release','{\"color\":\"default\",\"num\":\"20\"}','5','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('47','tyf','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('48','tyf','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('49','tyf','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('50','tyf','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('51','tyf','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('52','tyf','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('53','tyf','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('54','tyf','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('55','tyf','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('56','tyf','project','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('57','tyf','project','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('58','tyf','product','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('59','tyf','product','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('60','szy','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('61','szy','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('62','szy','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('63','szy','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('64','szy','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('65','szy','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('66','szy','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('67','szy','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('68','szy','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('69','tws','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('70','tws','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('71','tws','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('72','tws','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('73','tws','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('74','tws','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('75','tws','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('76','tws','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('77','tws','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('78','bjh','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('79','bjh','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('80','bjh','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('81','bjh','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('82','bjh','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('83','bjh','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('84','bjh','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('85','bjh','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('86','bjh','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('87','bjh','project','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('88','bjh','project','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('89','VickySong','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('90','VickySong','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('91','VickySong','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('92','VickySong','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('93','VickySong','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('94','VickySong','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('95','VickySong','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('96','VickySong','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('97','VickySong','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('98','tws','product','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('99','tws','product','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('100','tws','project','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('101','tws','project','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('102','huanghao','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('103','huanghao','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('104','huanghao','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('105','huanghao','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('106','huanghao','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('107','huanghao','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('108','huanghao','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('109','huanghao','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('110','huanghao','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('111','jiangpeng','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('112','jiangpeng','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('113','jiangpeng','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('114','jiangpeng','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('115','jiangpeng','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('116','jiangpeng','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('117','jiangpeng','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('118','jiangpeng','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('119','jiangpeng','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('120','huanghao','product','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('121','huanghao','product','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('122','zyf','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('123','zyf','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('124','zyf','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('125','zyf','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('126','zyf','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('127','zyf','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('128','zyf','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('129','zyf','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('130','zyf','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('131','zyf','product','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('132','zyf','product','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('133','zmh','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('134','zmh','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('135','zmh','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('136','zmh','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('137','zmh','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('138','zmh','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('139','zmh','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('140','zmh','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('141','zmh','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('142','xrs','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('143','xrs','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('144','xrs','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('145','xrs','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('146','xrs','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('147','xrs','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('148','xrs','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('149','xrs','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('150','xrs','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('151','rwb','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('152','rwb','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('153','rwb','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('154','rwb','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('155','rwb','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('156','rwb','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('157','rwb','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('158','rwb','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('159','rwb','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('160','jiangpeng','qa','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','1','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('161','jiangpeng','qa','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('162','jiangpeng','qa','待测版本列表','qa','testtask','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"wait\"}','3','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('163','gqf','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('164','gqf','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('165','gqf','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('166','gqf','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('167','gqf','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('168','gqf','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('169','gqf','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('170','gqf','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('171','gqf','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('172','gqf','qa','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','1','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('173','gqf','qa','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('174','gqf','qa','待测版本列表','qa','testtask','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"wait\"}','3','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('175','qzw','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('176','qzw','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('177','qzw','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('178','qzw','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('179','qzw','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('180','qzw','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('181','qzw','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('182','qzw','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('183','qzw','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('184','gqf','product','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('185','gqf','product','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('186','tws','qa','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','1','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('187','tws','qa','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('188','tws','qa','待测版本列表','qa','testtask','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"wait\"}','3','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('189','que1240434456','my','流程图','','flowchart','','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('190','que1240434456','my','最新动态','','dynamic','','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('191','que1240434456','my','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','3','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('192','que1240434456','my','我的待办','todo','list','{\"num\":\"20\"}','4','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('193','que1240434456','my','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','5','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('194','que1240434456','my','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','6','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('195','que1240434456','my','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','7','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('196','que1240434456','my','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','8','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('197','que1240434456','my','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','9','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('198','que1240434456','project','进行中的项目','project','list','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"undone\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('199','que1240434456','project','指派给我的任务','project','task','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('200','que1240434456','product','未关闭的产品','product','list','{\"num\":15,\"type\":\"noclosed\"}','1','8','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('201','que1240434456','product','指派给我的需求','product','story','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('202','que1240434456','qa','指派给我的Bug','qa','bug','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assignedTo\"}','1','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('203','que1240434456','qa','指派给我的用例','qa','case','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"assigntome\"}','2','4','0');
INSERT INTO `zt_block`(`id`,`account`,`module`,`title`,`source`,`block`,`params`,`order`,`grid`,`hidden`) VALUES ('204','que1240434456','qa','待测版本列表','qa','testtask','{\"num\":15,\"orderBy\":\"id_desc\",\"type\":\"wait\"}','3','4','0');
DROP TABLE IF EXISTS `zt_branch`;
CREATE TABLE `zt_branch` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product` (`product`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_bug`;
CREATE TABLE `zt_bug` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `branch` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `module` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `project` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `plan` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `story` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `storyVersion` smallint(6) NOT NULL DEFAULT '1',
  `task` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `toTask` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `toStory` mediumint(8) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `severity` tinyint(4) NOT NULL DEFAULT '0',
  `pri` tinyint(3) unsigned NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT '',
  `os` varchar(30) NOT NULL DEFAULT '',
  `browser` varchar(30) NOT NULL DEFAULT '',
  `hardware` varchar(30) NOT NULL,
  `found` varchar(30) NOT NULL DEFAULT '',
  `steps` text NOT NULL,
  `status` enum('active','resolved','closed') NOT NULL DEFAULT 'active',
  `color` char(7) NOT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `activatedCount` smallint(6) NOT NULL,
  `mailto` varchar(255) NOT NULL DEFAULT '',
  `openedBy` varchar(30) NOT NULL DEFAULT '',
  `openedDate` datetime NOT NULL,
  `openedBuild` varchar(255) NOT NULL,
  `assignedTo` varchar(30) NOT NULL DEFAULT '',
  `assignedDate` datetime NOT NULL,
  `resolvedBy` varchar(30) NOT NULL DEFAULT '',
  `resolution` varchar(30) NOT NULL DEFAULT '',
  `resolvedBuild` varchar(30) NOT NULL DEFAULT '',
  `resolvedDate` datetime NOT NULL,
  `closedBy` varchar(30) NOT NULL DEFAULT '',
  `closedDate` datetime NOT NULL,
  `duplicateBug` mediumint(8) unsigned NOT NULL,
  `linkBug` varchar(255) NOT NULL,
  `case` mediumint(8) unsigned NOT NULL,
  `caseVersion` smallint(6) NOT NULL DEFAULT '1',
  `result` mediumint(8) unsigned NOT NULL,
  `testtask` mediumint(8) unsigned NOT NULL,
  `lastEditedBy` varchar(30) NOT NULL DEFAULT '',
  `lastEditedDate` datetime NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `bug` (`product`,`module`,`project`,`assignedTo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_build`;
CREATE TABLE `zt_build` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `branch` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `project` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` char(150) NOT NULL,
  `scmPath` char(255) NOT NULL,
  `filePath` char(255) NOT NULL,
  `date` date NOT NULL,
  `stories` text NOT NULL,
  `bugs` text NOT NULL,
  `builder` char(30) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `build` (`product`,`project`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_burn`;
CREATE TABLE `zt_burn` (
  `project` mediumint(8) unsigned NOT NULL,
  `date` date NOT NULL,
  `left` float NOT NULL,
  `consumed` float NOT NULL,
  PRIMARY KEY (`project`,`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `zt_burn`(`project`,`date`,`left`,`consumed`) VALUES ('1','2016-11-19','382','0');
INSERT INTO `zt_burn`(`project`,`date`,`left`,`consumed`) VALUES ('2','2016-11-19','219','0');
DROP TABLE IF EXISTS `zt_case`;
CREATE TABLE `zt_case` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `branch` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `module` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `path` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `story` mediumint(30) unsigned NOT NULL DEFAULT '0',
  `storyVersion` smallint(6) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `precondition` text NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `pri` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `type` char(30) NOT NULL DEFAULT '1',
  `stage` varchar(255) NOT NULL,
  `howRun` varchar(30) NOT NULL,
  `scriptedBy` varchar(30) NOT NULL,
  `scriptedDate` date NOT NULL,
  `scriptStatus` varchar(30) NOT NULL,
  `scriptLocation` varchar(255) NOT NULL,
  `status` char(30) NOT NULL DEFAULT '1',
  `color` char(7) NOT NULL,
  `frequency` enum('1','2','3') NOT NULL DEFAULT '1',
  `order` tinyint(30) unsigned NOT NULL DEFAULT '0',
  `openedBy` char(30) NOT NULL DEFAULT '',
  `openedDate` datetime NOT NULL,
  `lastEditedBy` char(30) NOT NULL DEFAULT '',
  `lastEditedDate` datetime NOT NULL,
  `version` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `linkCase` varchar(255) NOT NULL,
  `fromBug` mediumint(8) unsigned NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  `lastRunner` varchar(30) NOT NULL,
  `lastRunDate` datetime NOT NULL,
  `lastRunResult` char(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `case` (`product`,`module`,`story`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_casestep`;
CREATE TABLE `zt_casestep` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `case` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `version` smallint(3) unsigned NOT NULL DEFAULT '0',
  `desc` text NOT NULL,
  `expect` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `case` (`case`,`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_company`;
CREATE TABLE `zt_company` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(120) DEFAULT NULL,
  `phone` char(20) DEFAULT NULL,
  `fax` char(20) DEFAULT NULL,
  `address` char(120) DEFAULT NULL,
  `zipcode` char(10) DEFAULT NULL,
  `website` char(120) DEFAULT NULL,
  `backyard` char(120) DEFAULT NULL,
  `guest` enum('1','0') NOT NULL DEFAULT '0',
  `admins` char(255) DEFAULT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `zt_company`(`id`,`name`,`phone`,`fax`,`address`,`zipcode`,`website`,`backyard`,`guest`,`admins`,`deleted`) VALUES ('1','Click','','','','','http://www.clickgwas.org','','0',',neroyang,','0');
DROP TABLE IF EXISTS `zt_config`;
CREATE TABLE `zt_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `owner` char(30) NOT NULL DEFAULT '',
  `module` varchar(30) NOT NULL,
  `section` char(30) NOT NULL DEFAULT '',
  `key` char(30) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique` (`owner`,`module`,`section`,`key`)
) ENGINE=MyISAM AUTO_INCREMENT=290 DEFAULT CHARSET=utf8;
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('1','system','common','global','version','8.3');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('2','system','common','global','flow','full');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('3','neroyang','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('36','neroyang','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('14','neroyang','tutorial','tasks','setting','createAccount,createProduct,createStory,createProject,manageTeam,linkStory,createTask,createBug');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('17','neroyang','product','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('18','neroyang','product','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('38','neroyang','project','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('20','neroyang','project','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('21','neroyang','qa','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('22','wjd','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('24','wjd','common','global','novice','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('25','system','common','global','sn','2faca3f191e8e4f48832a8fea7157604');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('26','system','common','global','community','na');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('27','neroyang','qa','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('28','yuchunyu','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('32','yuchunyu','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('33','yuchunyu','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('37','zhangjian','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('123','system','mail','smtp','host','smtp.smilewithu.com');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('124','system','mail','smtp','port','25');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('125','system','mail','smtp','auth','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('126','system','mail','smtp','username','click@smilewithu.com');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('127','system','mail','smtp','password','c.l.i.c.k.123');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('128','system','mail','smtp','secure','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('129','system','mail','smtp','debug','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('130','system','mail','smtp','charset','utf-8');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('131','system','mail','','turnon','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('132','system','mail','','mta','smtp');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('133','system','mail','','async','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('134','system','mail','','fromAddress','click@smilewithu.com');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('135','system','mail','','fromName','neroyang');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('217','neroyang','common','customMenu','main','[{\"name\":\"my\",\"order\":0},{\"name\":\"product\",\"order\":1},{\"name\":\"project\",\"order\":2},{\"name\":\"qa\",\"order\":3},{\"name\":\"doc\",\"order\":4},{\"name\":\"report\",\"order\":5,\"hidden\":true},{\"name\":\"company\",\"order\":6},{\"name\":\"admin\",\"order\":7,\"hidden\":true},{\"name\":\"kevincom\",\"order\":8,\"hidden\":true}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('186','neroyang','common','customMenu','report','[{\"name\":\"product\",\"order\":1},{\"name\":\"prj\",\"order\":2},{\"name\":\"test\",\"order\":3},{\"name\":\"staff\",\"order\":4}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('221','neroyang','common','customMenu','kevincom','[{\"name\":\"index\",\"order\":1},{\"name\":\"kevincalendar\",\"order\":2}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('220','neroyang','common','customMenu','admin','[{\"name\":\"index\",\"order\":1},{\"name\":\"extension\",\"order\":2},{\"name\":\"mail\",\"order\":4},{\"name\":\"custom\",\"order\":5},{\"name\":\"convert\",\"order\":6},{\"name\":\"cron\",\"order\":7},{\"name\":\"backup\",\"order\":8},{\"name\":\"dev\",\"order\":9},{\"name\":\"safe\",\"order\":10},{\"name\":\"sso\",\"order\":11},{\"name\":\"trashes\",\"order\":12}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('121','neroyang','common','customMenu','action','[{\"name\":\"index\",\"order\":1},{\"name\":\"extension\",\"order\":2},{\"name\":\"mail\",\"order\":4},{\"name\":\"custom\",\"order\":5},{\"name\":\"convert\",\"order\":6},{\"name\":\"cron\",\"order\":7},{\"name\":\"backup\",\"order\":8},{\"name\":\"dev\",\"order\":9},{\"name\":\"safe\",\"order\":10},{\"name\":\"sso\",\"order\":11},{\"name\":\"trashes\",\"order\":12}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('166','neroyang','common','customMenu','product','[{\"name\":\"index\",\"order\":0,\"float\":\"right\"},{\"name\":\"story\",\"order\":1},{\"name\":\"dynamic\",\"order\":2},{\"name\":\"plan\",\"order\":3},{\"name\":\"release\",\"order\":4},{\"name\":\"roadmap\",\"order\":5},{\"name\":\"doc\",\"order\":6},{\"name\":\"project\",\"order\":7},{\"name\":\"branch\",\"order\":8},{\"name\":\"module\",\"order\":9},{\"name\":\"view\",\"order\":10},{\"name\":\"create\",\"order\":11,\"float\":\"right\"},{\"name\":\"all\",\"order\":12,\"float\":\"right\"}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('183','neroyang','common','customMenu','qa','[{\"name\":\"product\",\"order\":-1},{\"name\":\"index\",\"order\":2,\"float\":\"right\"},{\"name\":\"bug\",\"order\":3},{\"name\":\"testcase\",\"order\":4},{\"name\":\"testtask\",\"order\":5}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('218','neroyang','common','customMenu','doc','[{\"name\":\"list\",\"order\":-1},{\"name\":\"crumb\",\"order\":0},{\"name\":\"create\",\"order\":1,\"float\":\"right\"}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('167','neroyang','common','customMenu','release','[{\"name\":\"list\",\"order\":-1},{\"name\":\"index\",\"order\":2,\"float\":\"right\"},{\"name\":\"story\",\"order\":3},{\"name\":\"dynamic\",\"order\":4},{\"name\":\"plan\",\"order\":5},{\"name\":\"release\",\"order\":6},{\"name\":\"roadmap\",\"order\":7},{\"name\":\"doc\",\"order\":8},{\"name\":\"project\",\"order\":9},{\"name\":\"branch\",\"order\":10},{\"name\":\"module\",\"order\":11},{\"name\":\"view\",\"order\":12},{\"name\":\"create\",\"order\":13,\"float\":\"right\"},{\"name\":\"all\",\"order\":14,\"float\":\"right\"}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('219','neroyang','common','customMenu','company','[{\"name\":\"name\",\"order\":-1},{\"name\":\"browseUser\",\"order\":2},{\"name\":\"dept\",\"order\":3},{\"name\":\"browseGroup\",\"order\":4},{\"name\":\"view\",\"order\":5},{\"name\":\"dynamic\",\"order\":6},{\"name\":\"addGroup\",\"order\":7,\"float\":\"right\"},{\"name\":\"batchAddUser\",\"order\":8,\"float\":\"right\"},{\"name\":\"addUser\",\"order\":9,\"float\":\"right\"}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('75','tyf','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('78','tyf','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('79','tyf','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('80','tyf','project','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('81','tyf','project','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('82','tyf','product','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('83','tyf','product','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('98','szy','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('184','neroyang','common','customMenu','project','[{\"name\":\"list\",\"order\":-1},{\"name\":\"index\",\"order\":2,\"float\":\"right\"},{\"name\":\"task\",\"order\":3},{\"name\":\"story\",\"order\":4},{\"name\":\"bug\",\"order\":5},{\"name\":\"build\",\"order\":6},{\"name\":\"testtask\",\"order\":7},{\"name\":\"team\",\"order\":8},{\"name\":\"dynamic\",\"order\":9},{\"name\":\"doc\",\"order\":10},{\"name\":\"product\",\"order\":11},{\"name\":\"view\",\"order\":12},{\"name\":\"create\",\"order\":13,\"float\":\"right\"},{\"name\":\"all\",\"order\":14,\"float\":\"right\"}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('182','neroyang','common','customMenu','my','[{\"name\":\"account\",\"order\":-1},{\"name\":\"index\",\"order\":2},{\"name\":\"todo\",\"order\":3},{\"name\":\"task\",\"order\":4},{\"name\":\"bug\",\"order\":5},{\"name\":\"testtask\",\"order\":6},{\"name\":\"story\",\"order\":7},{\"name\":\"myProject\",\"order\":8},{\"name\":\"dynamic\",\"order\":9},{\"name\":\"profile\",\"order\":10},{\"name\":\"changePassword\",\"order\":11},{\"name\":\"manageContacts\",\"order\":12}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('99','szy','common','global','novice','false');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('100','szy','project','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('122','neroyang','common','customMenu','feature_project_task','[{\"name\":\"unclosed\",\"order\":1},{\"name\":\"all\",\"order\":2},{\"name\":\"delayed\",\"order\":3},{\"name\":\"needconfirm\",\"order\":4},{\"name\":\"status\",\"order\":5}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('107','neroyang','datatable','projectTask','mode','datatable');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('137','neroyang','common','customMenu','mail','[{\"name\":\"index\",\"order\":1},{\"name\":\"extension\",\"order\":2},{\"name\":\"mail\",\"order\":4},{\"name\":\"custom\",\"order\":5},{\"name\":\"convert\",\"order\":6},{\"name\":\"cron\",\"order\":7},{\"name\":\"backup\",\"order\":8},{\"name\":\"dev\",\"order\":9},{\"name\":\"safe\",\"order\":10},{\"name\":\"sso\",\"order\":11},{\"name\":\"trashes\",\"order\":12}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('152','gqf','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('153','zhangjian','common','global','novice','false');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('154','tws','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('157','tws','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('168','neroyang','common','customMenu','productplan','[{\"name\":\"list\",\"order\":-1},{\"name\":\"index\",\"order\":2,\"float\":\"right\"},{\"name\":\"story\",\"order\":3},{\"name\":\"dynamic\",\"order\":4},{\"name\":\"plan\",\"order\":5},{\"name\":\"release\",\"order\":6},{\"name\":\"roadmap\",\"order\":7},{\"name\":\"doc\",\"order\":8},{\"name\":\"project\",\"order\":9},{\"name\":\"branch\",\"order\":10},{\"name\":\"module\",\"order\":11},{\"name\":\"view\",\"order\":12},{\"name\":\"create\",\"order\":13,\"float\":\"right\"},{\"name\":\"all\",\"order\":14,\"float\":\"right\"}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('175','bjh','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('176','bjh','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('177','bjh','project','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('178','bjh','project','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('179','bjh','product','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('180','bjh','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('189','neroyang','common','customMenu','group','[{\"name\":\"name\",\"order\":-1},{\"name\":\"browseUser\",\"order\":2},{\"name\":\"dept\",\"order\":3},{\"name\":\"browseGroup\",\"order\":4},{\"name\":\"view\",\"order\":5},{\"name\":\"dynamic\",\"order\":6},{\"name\":\"addGroup\",\"order\":7,\"float\":\"right\"},{\"name\":\"batchAddUser\",\"order\":8,\"float\":\"right\"},{\"name\":\"addUser\",\"order\":9,\"float\":\"right\"}]');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('191','VickySong','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('192','VickySong','common','global','novice','false');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('193','VickySong','project','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('194','VickySong','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('207','null','project','kanban','project1','{\"story\":[],\"wait\":[\"task17\",\"task18\",\"task23\",\"task24\",\"task25\",\"task26\",\"task28\",\"task32\"],\"doing\":[\"task1\",\"task2\",\"task8\",\"task10\",\"task11\",\"task30\",\"task31\"],\"done\":[\"task6\",\"task13\",\"task14\",\"task15\",\"task16\",\"task19\",\"task20\",\"task21\",\"task22\",\"task27\",\"task29\"]}');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('203','lifeng','common','global','novice','false');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('204','lifeng','product','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('205','czw','common','global','novice','false');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('208','wjd','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('209','wjd','project','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('210','szy','product','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('211','szy','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('212','tws','product','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('213','tws','product','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('214','tws','project','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('215','tws','project','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('216','tws','datatable','projectTask','showModule','0');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('223','zyf','common','global','novice','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('227','huanghao','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('228','huanghao','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('235','jiangpeng','common','global','novice','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('234','jiangpeng','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('236','huanghao','product','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('237','huanghao','product','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('238','zyf','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('239','zyf','product','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('240','zyf','product','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('244','zmh','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('245','zmh','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('246','zmh','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('247','zmh','project','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('248','xrs','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('252','xrs','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('253','zmh','product','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('256','rwb','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('257','rwb','qa','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('258','rwb','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('259','zxt','common','global','novice','false');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('260','rwb','project','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('261','jiangpeng','qa','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('262','jiangpeng','qa','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('263','gqf','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('264','gqf','qa','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('265','gqf','qa','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('266','gqf','project','','homepage','browse');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('267','qzw','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('268','qzw','common','global','novice','false');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('269','gqf','product','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('270','gqf','product','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('271','tws','qa','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('272','tws','qa','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('282','que1240434456','common','global','novice','');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('283','que1240434456','my','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('284','que1240434456','project','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('285','que1240434456','project','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('286','que1240434456','product','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('287','que1240434456','product','common','blockInited','1');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('288','que1240434456','qa','','homepage','index');
INSERT INTO `zt_config`(`id`,`owner`,`module`,`section`,`key`,`value`) VALUES ('289','que1240434456','qa','common','blockInited','1');
DROP TABLE IF EXISTS `zt_cron`;
CREATE TABLE `zt_cron` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `m` varchar(20) NOT NULL,
  `h` varchar(20) NOT NULL,
  `dom` varchar(20) NOT NULL,
  `mon` varchar(20) NOT NULL,
  `dow` varchar(20) NOT NULL,
  `command` text NOT NULL,
  `remark` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `buildin` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL,
  `lastTime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lastTime` (`lastTime`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
INSERT INTO `zt_cron`(`id`,`m`,`h`,`dom`,`mon`,`dow`,`command`,`remark`,`type`,`buildin`,`status`,`lastTime`) VALUES ('1','*','*','*','*','*','','监控定时任务','zentao','1','normal','0000-00-00 00:00:00');
INSERT INTO `zt_cron`(`id`,`m`,`h`,`dom`,`mon`,`dow`,`command`,`remark`,`type`,`buildin`,`status`,`lastTime`) VALUES ('2','30','23','*','*','*','moduleName=project&methodName=computeburn','更新燃尽图','zentao','1','normal','0000-00-00 00:00:00');
INSERT INTO `zt_cron`(`id`,`m`,`h`,`dom`,`mon`,`dow`,`command`,`remark`,`type`,`buildin`,`status`,`lastTime`) VALUES ('3','0','1','*','*','*','moduleName=report&methodName=remind','每日任务提醒','zentao','1','normal','0000-00-00 00:00:00');
INSERT INTO `zt_cron`(`id`,`m`,`h`,`dom`,`mon`,`dow`,`command`,`remark`,`type`,`buildin`,`status`,`lastTime`) VALUES ('4','*/5','*','*','*','*','moduleName=svn&methodName=run','同步SVN','zentao','1','stop','0000-00-00 00:00:00');
INSERT INTO `zt_cron`(`id`,`m`,`h`,`dom`,`mon`,`dow`,`command`,`remark`,`type`,`buildin`,`status`,`lastTime`) VALUES ('5','*/5','*','*','*','*','moduleName=git&methodName=run','同步GIT','zentao','1','stop','0000-00-00 00:00:00');
INSERT INTO `zt_cron`(`id`,`m`,`h`,`dom`,`mon`,`dow`,`command`,`remark`,`type`,`buildin`,`status`,`lastTime`) VALUES ('6','30','0','*','*','*','moduleName=backup&methodName=backup','备份数据和附件','zentao','1','normal','0000-00-00 00:00:00');
INSERT INTO `zt_cron`(`id`,`m`,`h`,`dom`,`mon`,`dow`,`command`,`remark`,`type`,`buildin`,`status`,`lastTime`) VALUES ('7','*/5','*','*','*','*','moduleName=mail&methodName=asyncSend','异步发信','zentao','1','normal','0000-00-00 00:00:00');
DROP TABLE IF EXISTS `zt_dept`;
CREATE TABLE `zt_dept` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(60) NOT NULL,
  `parent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `path` char(255) NOT NULL DEFAULT '',
  `grade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `position` char(30) NOT NULL DEFAULT '',
  `function` char(255) NOT NULL DEFAULT '',
  `manager` char(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `dept` (`parent`,`path`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
INSERT INTO `zt_dept`(`id`,`name`,`parent`,`path`,`grade`,`order`,`position`,`function`,`manager`) VALUES ('1','开发','4',',4,1,','2','10','','','neroyang');
INSERT INTO `zt_dept`(`id`,`name`,`parent`,`path`,`grade`,`order`,`position`,`function`,`manager`) VALUES ('2','数据','4',',4,2,','2','20','','','bjh');
INSERT INTO `zt_dept`(`id`,`name`,`parent`,`path`,`grade`,`order`,`position`,`function`,`manager`) VALUES ('3','测试','4',',4,3,','2','30','','','');
INSERT INTO `zt_dept`(`id`,`name`,`parent`,`path`,`grade`,`order`,`position`,`function`,`manager`) VALUES ('4','管理','0',',4,','1','40','','','VickySong');
DROP TABLE IF EXISTS `zt_doc`;
CREATE TABLE `zt_doc` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL,
  `project` mediumint(8) unsigned NOT NULL,
  `lib` varchar(30) NOT NULL,
  `module` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `type` varchar(30) NOT NULL,
  `views` smallint(5) unsigned NOT NULL,
  `addedBy` varchar(30) NOT NULL,
  `addedDate` datetime NOT NULL,
  `editedBy` varchar(30) NOT NULL,
  `editedDate` datetime NOT NULL,
  `acl` varchar(10) NOT NULL DEFAULT 'open',
  `groups` varchar(255) NOT NULL,
  `users` text NOT NULL,
  `version` smallint(5) unsigned NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `doc` (`product`,`project`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('1','0','2','5','0','html+css学习地址','html','url','0','neroyang','2016-11-19 01:47:16','','0000-00-00 00:00:00','custom','12','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('2','0','1','6','0','click 后端代码托管地址','github','url','0','neroyang','2016-11-19 01:50:40','','0000-00-00 00:00:00','custom','16,13','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('3','0','0','10','0','vpn领取','vpn','text','0','neroyang','2016-11-19 15:00:13','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('4','1','0','11','0','springmvc文档','springmvc','url','0','neroyang','2016-11-20 15:07:32','neroyang','2016-11-20 15:10:42','open','','','2','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('5','1','0','11','0','dubbo文档','dubbo','url','0','neroyang','2016-11-20 15:08:18','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('6','1','0','11','0','mybatis文档','mybatis','url','0','neroyang','2016-11-20 15:09:02','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('7','1','0','11','0','mysql文档','mysql','url','0','neroyang','2016-11-20 15:16:40','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('8','0','0','12','0','分组','分组','text','0','neroyang','2016-11-21 01:43:32','neroyang','2016-11-21 01:51:03','open','','','6','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('9','0','0','12','0','新数据库方案数据表命名规范','数据库','text','0','neroyang','2016-11-22 13:50:39','neroyang','2016-11-22 13:56:22','open','','','4','1');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('10','1','0','13','0','数据表命名规范 1.0  [新方案]','数据表','text','0','neroyang','2016-11-22 13:58:55','neroyang','2016-12-25 19:26:51','open','','','6','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('11','0','0','14','0','mac设备购置','设备','text','0','neroyang','2016-11-23 22:06:27','neroyang','2016-11-23 22:25:13','open','','','5','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('12','0','0','12','0','index design ','design','text','0','neroyang','2016-11-24 15:56:46','neroyang','2016-11-24 16:25:13','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('13','0','0','12','0','document','','text','0','neroyang','2016-11-24 21:34:57','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('14','0','1','6','0','click前端代码托管地址','代码','url','0','neroyang','2016-11-25 14:18:00','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('15','1','0','13','0','数据总表命名规范 1.0','总表','text','0','neroyang','2016-11-25 20:04:52','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('16','1','0','13','0','麦哈顿图数据数据表命名规范 1.0','规范','text','0','neroyang','2016-11-28 18:50:15','neroyang','2016-11-28 19:21:06','open','','','5','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('17','0','0','15','0','前端学习任务','前端','text','0','neroyang','2016-12-02 17:39:02','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('18','0','0','15','0','php后端学习任务','php后端','text','0','neroyang','2016-12-02 17:39:36','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('19','0','0','15','0','java后端学习任务','java后端','text','0','neroyang','2016-12-02 17:39:53','neroyang','2016-12-02 18:15:13','open','','','2','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('20','0','0','15','0','linux运维学习任务','运维','text','0','neroyang','2016-12-02 17:40:14','neroyang','2016-12-02 17:50:53','open','','','2','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('21','0','0','15','0','数据处理学习任务','数据处理','text','0','neroyang','2016-12-02 17:40:42','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('22','0','1','4','0','click架构文档','架构','text','0','neroyang','2016-12-11 16:36:12','neroyang','2016-12-11 19:31:57','open','','','3','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('23','0','1','4','0','click部署文档','','text','0','neroyang','2016-12-25 17:00:31','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('24','1','0','13','0','mean／mid表命名规范','mean mid','text','0','neroyang','2017-01-20 11:04:04','neroyang','2017-01-20 11:25:58','open','','','4','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('25','0','1','4','0','服务接口命名规范','','text','0','neroyang','2017-03-26 15:18:05','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('26','0','1','4','0','服务上线须知','','text','0','neroyang','2017-03-26 15:18:17','','0000-00-00 00:00:00','open','','','1','0');
INSERT INTO `zt_doc`(`id`,`product`,`project`,`lib`,`module`,`title`,`keywords`,`type`,`views`,`addedBy`,`addedDate`,`editedBy`,`editedDate`,`acl`,`groups`,`users`,`version`,`deleted`) VALUES ('27','0','1','4','0','服务上线须知','','text','0','neroyang','2017-03-26 15:21:32','','0000-00-00 00:00:00','open','','','1','0');
DROP TABLE IF EXISTS `zt_doccontent`;
CREATE TABLE `zt_doccontent` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `doc` mediumint(8) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `digest` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `files` text NOT NULL,
  `type` varchar(10) NOT NULL,
  `version` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `doc_version` (`doc`,`version`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('1','1','html+css学习地址','','http://www.imooc.com/learn/9','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('2','2','click 后端代码托管地址','','https://github.com/nerososft/click.git','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('3','3','vpn领取','','<p>留个人姓名首字母领取vpn账号，可翻墙，免流量。</p>','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('4','4','spriingmvc文档','','http://docs.spring.io/spring/docs/current/spring-framework-reference/html/mvc.html','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('5','5','dubbo文档','','http://dubbo.io/Developer+Guide-zh.htm','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('6','6','mybatis文档','','http://www.mybatis.org/mybatis-3/zh/getting-started.html','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('7','4','springmvc文档','','http://docs.spring.io/spring/docs/current/spring-framework-reference/html/mvc.html','','html','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('8','7','mysql文档','','http://dev.mysql.com/doc/refman/8.0/en/','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('9','8','分组','','># php后端
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
># 前端
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('10','8','分组','','># php后端
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
># 前端
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','','markdown','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('11','8','分组','','># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','','markdown','3');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('12','8','分组','','# 分组描述
___
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。

___
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
___
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','','markdown','4');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('13','8','分组','','# 分组描述
_________________________________________________________________________________________
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。

__________________________________________________________________________________________
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
____________________________________________________________________________________________
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','','markdown','5');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('14','8','分组','','# 分组描述
***
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
***
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
***
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','','markdown','6');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('15','9','新数据库方案数据表命名规范','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1,2,3,4。。。（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，。。。。）
***
> ## 整合表示例
> ### example1：lgg_n_c_0_1
> ### example2: gbm_t_m_1_3','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('16','9','新数据库方案数据表命名规范','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：lgg_n_c_0_1
> ### example2: gbm_t_m_1_3','','markdown','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('17','9','新数据库方案数据表命名规范','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1.#### gbm_t_m_1_3
> 2.#### gnm_t_m_2_3
> 3.#### gbm_t_m_3_3
> ','','markdown','3');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('18','9','新数据库方案数据表命名规范','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1. #### gbm_t_m_1_3
> 2. #### gnm_t_m_2_3
> 3. #### gbm_t_m_3_3
> ','','markdown','4');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('19','10','数据表命名规范[新方案]','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1. #### gbm_t_m_1_3
> 2. #### gnm_t_m_2_3
> 3. #### gbm_t_m_3_3
> ','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('20','10','数据表命名规范[新方案]','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1. #### gbm_t_m_1_3
> 2. #### gnm_t_m_2_3
> 3. #### gbm_t_m_3_3
> ','','markdown','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('21','10','数据表命名规范[新方案]','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','','markdown','3');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('22','10','数据表命名规范 1.0  [新方案]','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','','markdown','4');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('23','11','mac设备购置','','# 设备购置
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 * 2
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 * 1
> ## 颜色 银白
> ## 大小 13 寸','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('24','11','mac设备购置','','# 设备购置
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 × 1 = ￥12422
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 33124
','','markdown','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('25','11','mac设备购置','','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 × 1 = ￥12422
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 33124
','','markdown','3');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('26','11','mac设备购置','','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 ￥ 11488 × 2 = ￥ 22976
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格  ￥13888
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 36864
','','markdown','4');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('27','11','mac设备购置','','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 ￥ 11488 × 2 = ￥ 22976
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格  ￥13888
> ## 颜色 深空灰色
> ## 大小 13 寸

***
## 总价 ￥ 36864
','','markdown','5');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('28','12','index design ','','# index design
> # module
> ## Logo
> ## menu
> 1. ### Home
> 2. ### Analysis
> 3. ### Forum
> 4. ### Papers
> 5. ### Links
> 6. ### About Us
***
> ## data analysis
>  1. ### by cancertype(lgg,gbm.....)
>  2. ### by datatype(copynumber,expression,methylation...)
>  3. ### by graph (beesworm,moutain,defflection,manhattan...)
***
> ## paper
***
>  ## news','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('29','13','document','','# document
***
># project introduction (Must contain images and words for description)
>
***
># team introduction (like project introduction)
***
 ># analysis introduction(each item\'s  description contains at least 200 words )
>## analysis by cancer
>## analysis by data type
>1. ### copy number
>2. ### methylation
>3. ### expression
>4. ### mutation
>## analysis by graph
>1. ### beesworm
>2. ### mountain
>3. ### manhattan
>4. ### deflection
***','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('30','14','click前端代码托管地址','','https://github.com/nerososft/click_js.git','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('31','15','数据总表命名规范 1.0','','# 数据总表
> # 数据类型
> ## c，m, e  (m为甲基化，c为拷贝数，e为表达量)
***
> # 整合示例
>  ## m_gene','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('32','16','买哈顿图数据数据表命名规范','','# 卖哈顿图数据表命名规范
> # 数据命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('33','16','麦哈顿图数据数据表命名规范','','# 卖哈顿图数据表命名规范
> # 数据命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan','','markdown','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('34','16','麦哈顿图数据数据表命名规范 1.0','','# 卖哈顿图数据表命名规范
> # 数据命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan','','markdown','3');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('35','16','麦哈顿图数据数据表命名规范 1.0','','# 卖哈顿图数据表命名规范
> # 总表命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan
***
># 样本表命名
> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 麦哈顿标识manhattan
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】
> ','','markdown','4');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('36','16','麦哈顿图数据数据表命名规范 1.0','','# 卖哈顿图数据表命名规范
> # 总表命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan
***
># 样本表命名
> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 麦哈顿标识manhattan
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】
> ','','markdown','5');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('37','17','前端学习任务','','','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('38','18','php后端学习任务','','','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('39','19','java后端学习任务','','','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('40','20','linux运维学习任务','','','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('41','21','数据处理学习任务','','','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('42','20','linux运维学习任务','','# linux运维学习任务

***
> 1. ## Linux系统基础
### 这个不用说了，是基础中的基础，连这个都不会就别干了，参考书籍，可以看鸟哥linux基础篇,没必须全部掌握，但基本命令总得会吧。
***
> 2. ## 网络服务
### 服务有很多种，每间公司都会用到不同的，但基础的服务肯定要掌握，如FTP, DNS,SAMBA, 邮件, 这几个大概学一下就行，LAMP和LNMP是必须要熟练，我所指的不是光光会搭建，而是要很熟悉里面的相当配置才行，因为公司最关键的绝对是WEB服务器，所以nginx和apache要熟悉，特别是nginx一定要很熟悉才行，至少有些公司还会用tomcat，这个也最好学一下。其实网络服务方面不用太担心，一般公司的环境都已经搭建好，就算有新服务器或让你整改，公司会有相应的文档让你参照来弄，不会让你乱来的，但至少相关的配置一定要学熟，而且肯定是编译安装多，那些模块要熟悉一下他的作用，特别是PHP那些模块。
***
> 3. ## shell脚本和另一个脚本语言
### shell是运维人员必须具备的，不懂这个连入职都不行，至少也要写出一些系统管理脚本，最简单也得写个监控CPU，内存比率的脚本吧，这是最最最基本了，别以为会写那些猜数字和计算什么数的，这些没什么作用，只作学习意义，写系统脚本才是最有意义，而另一个脚本语言是可选的，一般是3P，即python, perl和php，php就不需要考虑了，除非你要做开发，我个人建议学python会比较好，难实现自动化运维，perl是文本处理很强大，反正这两个学一个就行了。
***
> 4. ## sed和awk工具
### 必须要掌握，在掌握这两个工具同时，还要掌握正则表达式，这个就痛苦了，正则是最难学的表达式，但结合到sed和awk中会很强大，在处理文本内容和过滤WEB内容时十分有用，不过在学shell的同时一般会经常结合用到的，所以学第3点就会顺便学第4点。
***
> 5. ## 文本处理命令
### sort, tr, cut, paste, uniq, tee等，必学，也是结合第3点时一并学习的。
***
> 6. ## 数据库
### 首选mysql，别问我为什么不学sqlserver和oracle，因为Linux用得最多绝对是mysql，增删改查必学，特别要学熟查，其它方面可能不太需要，因为运维人员使用最多还是查，哪些优化和开发语句不会让你弄的。
***
> 7. ## 防火墙
### 不学不行，防火墙也算是个难点，说难不难，说易不易，最重要弄懂规则，如果学过CCNA的朋友可能会比较好学，因为iptables也有NAT表，原理是一样的，而FILTER表用得最多，反正不学就肯定不合格。
***
> 8. ## 监控工具
### 十分十分重要，我个人建议，最好学这3个，cacti，nagios，zabbix，企业用得最多应该是 nagios 和 zabbix，反正都学吧，但nagios会有点难，因为会涉及到用脚本写自动监控，那个地方很难。
***
> 9. ## 集群和热备
### 这个很重要，肯定要懂的，但到了公司就不会让你去弄，因为新手基本不让你碰，集群工具有很多，最好学是LVS，这是必学，最好也学学nginx集群，反向代理，还有热备，这个就更多工具能实现了，像我公司是自己开发热备工具的，mysql热备也要学，就是主从复制，这个别告诉我容易，其实不容易的，要学懂整个流程一点也不容易，只照着做根本没意思。
***
> 10. ## 数据备份
### 不学不行，工具有很多，但至少要把RAID的原理弄懂，特别是企业最常用的1+0或0+1，自己做实验也要弄出来，备份工具有很多，如tar, dump, rsync等，最好多了解一下。
*** 

## 前面3条必须学会，后面的也要学。



***','','markdown','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('43','19','java后端学习任务','','# java后端
> 1. ## java 
> ### 掌握基本java语法，面向对象编程思想，继承，组合 等，掌握基本容器，List，Map，Set，掌握字符串操作，io操作。掌握socket编程。
***
> 2. ## SpringMvc
> ### 参考 http://www.cnblogs.com/baiduligang/p/4247164.html
***
> 3. ## mybatis
> ### 学习基本配置，映射文件编写（前提学会mysql）。
> ### 参考 http://www.mybatis.org/mybatis-3/zh/
***
> 4. ## 了解分布式系统与SOA,学习dubbo
> ### 
>5. ## 了解redis缓存，以及redis集群搭建。
>6. ## 了解zookeeper，以及zookeeper集群搭建。
>7. ## 了解linux操作系统，以及shell脚本编写。','','markdown','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('44','22','click','','','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('45','22','click架构文档','','','','html','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('46','22','click架构文档','','<p style=\"text-align:center;\"><span style=\"font-family:\'宋体\';font-size:14px;\">Click<span style=\"font-family:\'宋体\';\">架构文档</span></span></p><h1><span style=\"font-family:\'宋体\';font-size:29px;\">1.</span><strong><span style=\"font-family:\'宋体\';font-size:29px;\"><span style=\"font-family:\'宋体\';\">架构设计</span></span></strong></h1><h2><span style=\"font-family:\'黑体\';font-size:21px;\">1.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">架构设计</span></span></strong></h2><p><img src=\"/data/upload/1/201612/1119315309268s1s.png\" title=\"\" alt=\"\" /><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p style=\"text-indent:28px;text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">分布式</span></span><span style=\"font-family:Arial;color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">面向服务的体系结构（</span></span><span style=\"font-family:Arial;color:rgb(204,0,0);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">SOA</span><span style=\"font-family:Arial;color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">）</span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">，</span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">通过阿里</span>dubbo <span style=\"font-family:\'宋体\';\">框架，实现模块功能服务化，通过</span><span style=\"font-family:Arial;\">zookeeper</span><span style=\"font-family:\'宋体\';\">技术，实现服务注册与发现，系统分布化。通过</span><span style=\"font-family:Arial;\">linkedin </span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">K</span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">afka<span style=\"font-family:\'宋体\';\">技术，实现分布式日志与日志聚合。使用</span><span style=\"font-family:Arial;\">echarts </span><span style=\"font-family:\'宋体\';\">实现前端数据绘制。</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">1.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">web<span style=\"font-family:\'黑体\';\">前端页面展示层</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">前端数据可视模块</span></span></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">前端页面</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">2.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">Ajax<span style=\"font-family:\'黑体\';\">接口封装层（服务消费者）</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">通过注册中心集群发现服务提供者并联合调用相应服务提供者产生相应数据传输对象。</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">3.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">Service<span style=\"font-family:\'黑体\';\">服务层（服务提供者）</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">注册服务，业务逻辑实现，等待消费者调用。</span></span></p><p><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">4.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">缓存层</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">数据磁盘缓存，分布式</span>session<span style=\"font-family:\'宋体\';\">共享，分布式日志缓存。</span></span></p><p><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p><strong><span style=\"font-family:\'黑体\';font-size:21px;\">5.</span></strong><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">数据库</span></span></strong></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">基因数据库，用户数据库，日志数据库，页面相关数据库。</span></span></p><h1><strong><span style=\"font-family:\'宋体\';font-size:29px;\">2.<span style=\"font-family:\'宋体\';\">模块划分</span></span></strong></h1><p style=\"text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p style=\"text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p><br /></p>','','html','3');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('47','23','click部署文档','','# CLICK部署文档V1.0
> 1. ## zookeeper注册中心下载安装以及配置。
>    ### http://zookeeper.apache.org
> 2. ## tomcat下载
>    ### http://tomcat.apache.org
> 3. ## 数据库安装
>    ### http://www.mysql.com/downloads/
>    ### 数据库schema在common项目sql目录下
> 4. ## dubbo-admin 部署及运行
>    ###  将dubbo-admin.war放至tomcat webapp下
> 5. ## 服务部署与运行
>    ### ⚠️服务打jar包nohup运行
>    ### ⚠️注意端口冲突
> 6. ## web 部署与运行
>    ### 打war包放至tomcat webapp目录下并运行tomcat
>    
>    
>    
>   
> 
> 
> 
> ','','markdown','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('48','10','数据表命名规范 1.0  [新方案]','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
>## 数据类型
>### l取对数
>### y不取对数
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】
> ### example2: 
> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','','markdown','5');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('49','10','数据表命名规范 1.0  [新方案]','','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
>## 数据类型
>### l取对数
>### y不取对数
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】
> ### example2: 
> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','','markdown','6');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('50','24','mean／mid表命名规范','','','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('51','24','mean／mid表命名规范','','<h1>mean mid 表命名规范 1.0<br /></h1><p>表名：数据类型_样本类型_是否取对数_moutain</p><p>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><p>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</p><p>&nbsp; &nbsp; 注：1.geneid为基因id</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</p><p><br /></p>','','html','2');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('52','24','mean／mid表命名规范','','<h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></h3><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><h2>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</h2><h3>&nbsp; &nbsp; 注：1.geneid为基因id</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</h3><p><br /></p>','','html','3');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('53','24','mean／mid表命名规范','','<h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></h3><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><h2>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</h2><h3>&nbsp; &nbsp; 注：1.geneid为基因id</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</h3><h1>例：</h1><h2>表: c_n_y_moutain</h2><table><tbody><tr class=\"firstRow\"><td width=\"276\" valign=\"top\">geneid</td><td width=\"276\" valign=\"top\">cancertype</td><td width=\"276\" valign=\"top\">mean</td><td width=\"276\" valign=\"top\">mid</td></tr><tr><td width=\"276\" valign=\"top\">1</td><td width=\"276\" valign=\"top\">gbm</td><td width=\"276\" valign=\"top\">0.989767</td><td width=\"276\" valign=\"top\">1</td></tr><tr><td width=\"276\" valign=\"top\">1</td><td width=\"276\" valign=\"top\">lgg</td><td width=\"276\" valign=\"top\">0.775648</td><td width=\"276\" valign=\"top\">0.8</td></tr></tbody></table><p><br /></p><p>行数为24702 * 35</p>','','html','4');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('54','25','服务接口命名规范','','','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('55','26','服务上线须知','','','','html','1');
INSERT INTO `zt_doccontent`(`id`,`doc`,`title`,`digest`,`content`,`files`,`type`,`version`) VALUES ('56','27','服务上线须知','','','','html','1');
DROP TABLE IF EXISTS `zt_doclib`;
CREATE TABLE `zt_doclib` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL,
  `project` mediumint(8) unsigned NOT NULL,
  `name` varchar(60) NOT NULL,
  `acl` varchar(10) NOT NULL DEFAULT 'open',
  `groups` varchar(255) NOT NULL,
  `users` text NOT NULL,
  `main` enum('0','1') NOT NULL DEFAULT '0',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('1','1','0','产品库','open','','bjh,czw,gqf,lifeng,neroyang,szy,tws,tyf,wjd,yuchunyu,zhangjian','1','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('2','2','0','产品库','open','','neroyang','1','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('3','3','0','产品库','open','','bjh,czw,gqf,lifeng,neroyang,szy,tws,tyf,wjd,yuchunyu,zhangjian','1','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('4','0','1','项目库','open','','bjh,czw,lifeng,neroyang,tws,tyf,wjd,yuchunyu','1','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('5','0','2','项目库','open','','neroyang','1','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('6','0','1','代码','open','','bjh,czw,lifeng,neroyang,tws,tyf,wjd,yuchunyu,','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('7','0','0','服务接口文档','open','','','0','1');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('8','1','0','服务接口','open','','bjh,czw,gqf,lifeng,neroyang,szy,tws,tyf,wjd,yuchunyu,zhangjian,','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('9','1','0','web接口','open','','bjh,czw,gqf,lifeng,neroyang,szy,tws,tyf,wjd,yuchunyu,zhangjian,','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('10','0','0','通知','open','','','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('11','1','0','技术文档','open','','bjh,czw,gqf,lifeng,neroyang,szy,tws,tyf,wjd,yuchunyu,zhangjian,','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('12','0','0','其他','open','','','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('13','1','0','数据库相关','open','','bjh,czw,gqf,lifeng,neroyang,szy,tws,tyf,wjd,yuchunyu,zhangjian,','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('14','0','0','设备','open','','','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('15','0','0','学习任务','open','','','0','0');
INSERT INTO `zt_doclib`(`id`,`product`,`project`,`name`,`acl`,`groups`,`users`,`main`,`deleted`) VALUES ('16','3','0','需求','open','','bjh,czw,gqf,lifeng,neroyang,szy,tws,tyf,wjd,yuchunyu,zhangjian,','0','0');
DROP TABLE IF EXISTS `zt_effort`;
CREATE TABLE `zt_effort` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user` char(30) NOT NULL DEFAULT '',
  `todo` enum('1','0') NOT NULL DEFAULT '1',
  `date` date NOT NULL,
  `begin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` enum('1','2','3') NOT NULL DEFAULT '1',
  `idvalue` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` char(30) NOT NULL DEFAULT '',
  `desc` char(255) NOT NULL DEFAULT '',
  `status` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_extension`;
CREATE TABLE `zt_extension` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(30) NOT NULL,
  `version` varchar(50) NOT NULL,
  `author` varchar(100) NOT NULL,
  `desc` text NOT NULL,
  `license` text NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'extension',
  `site` varchar(150) NOT NULL,
  `zentaoCompatible` varchar(100) NOT NULL,
  `installedTime` datetime NOT NULL,
  `depends` varchar(100) NOT NULL,
  `dirs` text NOT NULL,
  `files` text NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `extension` (`name`,`installedTime`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
INSERT INTO `zt_extension`(`id`,`name`,`code`,`version`,`author`,`desc`,`license`,`type`,`site`,`zentaoCompatible`,`installedTime`,`depends`,`dirs`,`files`,`status`) VALUES ('1','禅道补丁','zentaopatch','8.3.2','azhi<congzhi@cnezsoft.com>','禅道8.3版本补丁。','LGPL','patch','http://www.zentao.net','8.3.1','2016-11-18 22:49:25','','[\"module\\/kevinchart\\/view\",\"module\\/kevinchart\\/js\",\"module\\/kevinchart\\/lang\",\"config\\/ext\"]','{\"www\\/theme\\/default\\/en.blackberry.css\":\"94f734d9b6ba10c7eb38918390b20252\",\"www\\/theme\\/default\\/en.default.css\":\"ccd1330e7b0673505ce78293e55560cb\",\"www\\/theme\\/default\\/en.green.css\":\"c096ac9d5f3a2a1a8e8677322386b5e8\",\"www\\/theme\\/default\\/en.lightblue.css\":\"d6623809183e5e3714aab9e6bce8c024\",\"www\\/theme\\/default\\/en.red.css\":\"0d2994d2cfc24706efdd386a936be678\",\"www\\/theme\\/default\\/style.css\":\"9f028b1565fd42a53ab959ba83c4587a\",\"www\\/theme\\/default\\/zh-cn.blackberry.css\":\"94f734d9b6ba10c7eb38918390b20252\",\"www\\/theme\\/default\\/zh-cn.default.css\":\"ccd1330e7b0673505ce78293e55560cb\",\"www\\/theme\\/default\\/zh-cn.green.css\":\"c096ac9d5f3a2a1a8e8677322386b5e8\",\"www\\/theme\\/default\\/zh-cn.lightblue.css\":\"d6623809183e5e3714aab9e6bce8c024\",\"www\\/theme\\/default\\/zh-cn.red.css\":\"0d2994d2cfc24706efdd386a936be678\",\"www\\/theme\\/default\\/zh-tw.blackberry.css\":\"94f734d9b6ba10c7eb38918390b20252\",\"www\\/theme\\/default\\/zh-tw.default.css\":\"ccd1330e7b0673505ce78293e55560cb\",\"www\\/theme\\/default\\/zh-tw.green.css\":\"c096ac9d5f3a2a1a8e8677322386b5e8\",\"www\\/theme\\/default\\/zh-tw.lightblue.css\":\"d6623809183e5e3714aab9e6bce8c024\",\"www\\/theme\\/default\\/zh-tw.red.css\":\"0d2994d2cfc24706efdd386a936be678\"}','installed');
INSERT INTO `zt_extension`(`id`,`name`,`code`,`version`,`author`,`desc`,`license`,`type`,`site`,`zentaoCompatible`,`installedTime`,`depends`,`dirs`,`files`,`status`) VALUES ('2','Kevin公用函数','kevincom','1.7','kevin<3301647@qq.com>','kevin 插件的一部分公用函数.','ZPL (http://zpl.pub/v1)','extension','http://kevincom.sourceforge.net/','all','2016-11-18 22:59:20','','[\"module\\/kevincalendar\\/view\",\"module\\/kevincalendar\\/js\",\"module\\/kevincalendar\\/lang\",\"module\\/kevincalendar\\/css\"]','{\"lib\\/kevin\\/kevin.class.php\":\"e7707088453c3f5c81c83a7d3662d3b9\",\"lib\\/kevinchart\\/kevinchart.class.php\":\"48787bb1db515f73babead728279b831\",\"module\\/common\\/ext\\/lang\\/en\\/kevin.php\":\"53bb13721c7cff437f00cd0c43977a98\",\"module\\/common\\/ext\\/lang\\/kevin.php\":\"3d82cd3109f4dcbcafe3f3b7cf0fff8a\",\"module\\/common\\/ext\\/lang\\/zh-cn\\/kevin.php\":\"bfde3d686e1e2ca8ebe1d961d61f6dc6\",\"module\\/common\\/ext\\/lang\\/zh-tw\\/kevin.php\":\"7238002fc25cbb152391779ef873aff1\",\"module\\/group\\/ext\\/lang\\/en\\/kevin.php\":\"8add6f4b0d8ed89158cbf9aef67c3605\",\"module\\/group\\/ext\\/lang\\/kevin.php\":\"2add67c7a6f80694f42319b4efc732dd\",\"module\\/group\\/ext\\/lang\\/zh-cn\\/kevin.php\":\"8add6f4b0d8ed89158cbf9aef67c3605\",\"module\\/group\\/ext\\/lang\\/zh-tw\\/kevin.php\":\"8add6f4b0d8ed89158cbf9aef67c3605\",\"module\\/kevincom\\/config.php\":\"00f771286a949b03263054c9ddfbdf72\",\"module\\/kevincom\\/control.php\":\"a01f0e8f208bc9f36cc8a27589615463\",\"module\\/kevincom\\/css\\/index.css\":\"48f2096a354de7b098876960b49a413e\",\"module\\/kevincom\\/lang\\/en.php\":\"e91b88db3a8a5d75375d53dd1a8fe0d0\",\"module\\/kevincom\\/lang\\/zh-cn.php\":\"666038b7366f1429f95dbb6a127e4f26\",\"module\\/kevincom\\/lang\\/zh-tw.php\":\"7ca8d0a4c8ff336743d123c2ec5be871\",\"module\\/kevincom\\/model.php\":\"4fd9aa49984d86ee9191b729a8602ffd\",\"module\\/kevincom\\/view\\/index.html.php\":\"f22af8570aa96de658353f92a655851a\",\"www\\/js\\/kevin\\/kevin.js\":\"44225d086fd57d2388af8a436cab1cab\"}','installed');
INSERT INTO `zt_extension`(`id`,`name`,`code`,`version`,`author`,`desc`,`license`,`type`,`site`,`zentaoCompatible`,`installedTime`,`depends`,`dirs`,`files`,`status`) VALUES ('4','Kevin 日历','kevincalendar','1.5','kevin<3301647@qq.com>','自定义日历假期，日历视图显示，显示待办信息.','unknown','extension','','all','2016-11-18 23:02:02','{\"kevincom\":{\"min\":1.6,\"max\":\"\"}}','[]','{\"config\\/ext\\/kevincalendar.php\":\"e4db38c783b0ed95cc5516a37cfbb0b1\",\"module\\/common\\/ext\\/lang\\/en\\/kevincalendar.php\":\"556fe6c50eab798ca073c3fd71899aea\",\"module\\/common\\/ext\\/lang\\/kevincalendar.php\":\"f25b7f3086bc2a33c2815d9be0a3979f\",\"module\\/common\\/ext\\/lang\\/zh-cn\\/kevincalendar.php\":\"556fe6c50eab798ca073c3fd71899aea\",\"module\\/common\\/ext\\/lang\\/zh-tw\\/kevincalendar.php\":\"556fe6c50eab798ca073c3fd71899aea\",\"module\\/group\\/ext\\/lang\\/en\\/kevincalendar.php\":\"556fe6c50eab798ca073c3fd71899aea\",\"module\\/group\\/ext\\/lang\\/kevincalendar.php\":\"ff4f33d61db702a4707666788b2b6375\",\"module\\/group\\/ext\\/lang\\/zh-cn\\/kevincalendar.php\":\"556fe6c50eab798ca073c3fd71899aea\",\"module\\/group\\/ext\\/lang\\/zh-tw\\/kevincalendar.php\":\"556fe6c50eab798ca073c3fd71899aea\",\"module\\/kevincalendar\\/config.php\":\"2fb24ff71dc59573d218f9c076ebe9dc\",\"module\\/kevincalendar\\/control.php\":\"e7da666ce1bb4f54905ff64bad9727b6\",\"module\\/kevincalendar\\/css\\/common.css\":\"6fb021ee75626e30361a9629272fe4c7\",\"module\\/kevincalendar\\/css\\/todo.css\":\"2151bc2c0e67f7a90225581e4f5d01b4\",\"module\\/kevincalendar\\/js\\/common.js\":\"d54f9b311891b5ed31d6c6c4a259b8b3\",\"module\\/kevincalendar\\/lang\\/en.php\":\"52af6e7eca10274deedf594084f643a1\",\"module\\/kevincalendar\\/lang\\/zh-cn.php\":\"5878c12406a12997a4e814fa946af959\",\"module\\/kevincalendar\\/lang\\/zh-tw.php\":\"80b03ac46b719874138872e6eea521b9\",\"module\\/kevincalendar\\/model.php\":\"1ccbb4e85edecfa3f0a60d5f7807e9ad\",\"module\\/kevincalendar\\/view\\/batchcreate.html.php\":\"c4c194d3e9cb9dde3c352ee20c688e8b\",\"module\\/kevincalendar\\/view\\/create.html.php\":\"acaff413662e65cd9bd7b3fe44e2ac57\",\"module\\/kevincalendar\\/view\\/edit.html.php\":\"76aefeb45dfa507a4e832a9267ebd0e4\",\"module\\/kevincalendar\\/view\\/index.html.php\":\"acf8a5e6a3b138a37cc0c6e140050305\",\"module\\/kevincalendar\\/view\\/lists.html.php\":\"c71b576b084ad6f2739a2e46a1230675\",\"module\\/kevincalendar\\/view\\/log.html.php\":\"ce93b2fe1202420a19f8dcaf714f8e6d\",\"module\\/kevincalendar\\/view\\/titlebar.html.php\":\"3ae3c99f702d8b43444cf783f60a9418\",\"module\\/kevincalendar\\/view\\/todo.html.php\":\"577a3d247831abd0e8e62a935286f097\"}','installed');
DROP TABLE IF EXISTS `zt_file`;
CREATE TABLE `zt_file` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `pathname` char(50) NOT NULL,
  `title` char(90) NOT NULL,
  `extension` char(30) NOT NULL,
  `size` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `objectType` char(30) NOT NULL,
  `objectID` mediumint(9) NOT NULL,
  `addedBy` char(30) NOT NULL DEFAULT '',
  `addedDate` datetime NOT NULL,
  `downloads` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `extra` varchar(255) NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `file` (`objectType`,`objectID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
INSERT INTO `zt_file`(`id`,`pathname`,`title`,`extension`,`size`,`objectType`,`objectID`,`addedBy`,`addedDate`,`downloads`,`extra`,`deleted`) VALUES ('1','201611/2517452005808jo4.zip','laravel-v5.1.11','zip','8352587','task','9','wjd','2016-11-25 00:00:00','0','','0');
INSERT INTO `zt_file`(`id`,`pathname`,`title`,`extension`,`size`,`objectType`,`objectID`,`addedBy`,`addedDate`,`downloads`,`extra`,`deleted`) VALUES ('2','201612/1119315309268s1s.png','click','png','26870','doc','22','neroyang','2016-12-11 00:00:00','0','editor','0');
DROP TABLE IF EXISTS `zt_group`;
CREATE TABLE `zt_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  `role` char(30) NOT NULL DEFAULT '',
  `desc` char(255) NOT NULL DEFAULT '',
  `acl` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('1','管理员','admin','系统管理员','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('2','研发','dev','研发人员','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('3','测试','qa','测试人员','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('6','研发主管','td','研发主管','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('8','测试主管','qd','测试主管','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('9','高层管理','top','高层管理','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('16','架构','','架构整体系统','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('12','前端','','负责前端开发','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('13','java后端','','后端开发','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('14','数据','','负责数据处理以及分析','');
INSERT INTO `zt_group`(`id`,`name`,`role`,`desc`,`acl`) VALUES ('15','php后端','','负责php后端开发','');
DROP TABLE IF EXISTS `zt_grouppriv`;
CREATE TABLE `zt_grouppriv` (
  `group` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `module` char(30) NOT NULL DEFAULT '',
  `method` char(30) NOT NULL DEFAULT '',
  UNIQUE KEY `group` (`group`,`module`,`method`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','action','editComment');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','action','hideAll');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','action','hideOne');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','action','trash');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','action','undelete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','admin','checkDB');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','admin','checkWeak');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','admin','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','admin','safe');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','api','debug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','api','getModel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','api','sql');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','backup','backup');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','backup','change');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','backup','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','backup','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','backup','restore');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','branch','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','branch','manage');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','batchConfirm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','batchResolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','confirmBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','deleteTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','linkBugs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','resolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','saveTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','bug','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','batchUnlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','batchUnlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','linkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','linkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','unlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','build','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','company','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','company','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','company','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','company','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','company','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','checkBugFree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','checkConfig');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','checkRedmine');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','convertBugFree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','convertRedmine');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','execute');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','selectSource');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','setBugfree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','setConfig');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','convert','setRedmine');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','cron','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','cron','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','cron','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','cron','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','cron','toggle');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','cron','turnon');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','custom','flow');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','custom','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','custom','restore');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','custom','set');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','dept','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','dept','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','dept','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','dept','manageChild');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','dept','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','dev','api');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','dev','db');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','allLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','createLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','deleteLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','editLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','objectLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','showFiles');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','doc','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','editor','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','editor','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','editor','extend');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','editor','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','editor','newPage');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','editor','save');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','deactivate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','erase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','install');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','obtain');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','structure');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','uninstall');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','upgrade');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','extension','upload');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','file','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','file','download');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','file','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','file','uploadImages');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','git','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','git','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','git','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','copy');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','manageMember');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','managePriv');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','group','manageView');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','index','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','batchDelete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','detect');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','reset');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','save');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','mail','test');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','misc','ping');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','changePassword');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','editProfile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','my','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','order');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','roadmap');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','product','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','batchUnlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','batchUnlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','linkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','linkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','unlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','productplan','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','batchedit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','batchUnlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','build');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','burn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','burnData');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','computeBurn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','grouptask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','importBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','importtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','kanban');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','linkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','manageMembers');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','manageProducts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','order');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','putoff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','suspend');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','team');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','testtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','tree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','unlinkMember');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','unlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','project','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','qa','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','batchUnlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','batchUnlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','changeStatus');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','linkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','linkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','unlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','release','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','report','bugAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','report','bugCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','report','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','report','productSummary');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','report','projectDeviation');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','report','workload');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','search','buildForm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','search','buildQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','search','deleteQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','search','saveQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','search','select');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchChangeBranch');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchChangePlan');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchChangeStage');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','batchReview');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','change');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','linkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','review');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','tasks');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','unlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','story','zeroCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','svn','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','svn','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','svn','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','cancel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','deleteEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','editEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','pause');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','recordEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','restart');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','task','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','batchDelete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','confirmChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','createBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','exportTemplet');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','import');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','linkCases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','showImport');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','unlinkCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testcase','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','batchAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','batchRun');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','cases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','linkcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','results');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','runcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','unlinkcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','testtask','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','batchFinish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','import2Today');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','todo','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','tree','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','tree','browseTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','tree','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','tree','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','tree','fix');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','tree','manageChild');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','tree','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','unlock');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('1','user','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','action','editComment');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','api','getModel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','batchConfirm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','batchResolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','confirmBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','deleteTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','linkBugs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','resolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','saveTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','bug','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','build','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','build','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','build','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','build','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','company','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','company','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','company','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','company','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','allLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','objectLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','showFiles');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','doc','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','file','download');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','file','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','git','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','git','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','git','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','group','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','index','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','misc','ping');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','changePassword');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','editProfile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','my','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','roadmap');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','product','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','productplan','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','productplan','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','build');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','burn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','burnData');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','computeBurn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','grouptask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','importBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','importtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','kanban');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','team');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','testtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','tree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','project','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','qa','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','release','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','release','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','release','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','report','bugAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','report','bugCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','report','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','report','productSummary');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','report','projectDeviation');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','report','workload');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','search','buildForm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','search','buildQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','search','deleteQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','search','saveQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','search','select');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','story','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','story','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','story','tasks');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','story','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','svn','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','svn','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','svn','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','cancel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','deleteEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','editEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','pause');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','recordEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','restart');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','task','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testcase','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testcase','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testcase','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testcase','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testcase','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','cases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','results');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','testtask','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','batchFinish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','import2Today');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','todo','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('2','user','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','action','editComment');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','api','getModel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','batchConfirm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','batchResolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','confirmBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','deleteTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','linkBugs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','resolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','saveTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','bug','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','build','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','build','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','build','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','company','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','company','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','company','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','company','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','allLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','objectLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','showFiles');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','doc','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','file','download');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','file','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','git','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','git','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','git','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','group','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','index','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','misc','ping');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','changePassword');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','editProfile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','my','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','roadmap');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','product','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','productplan','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','productplan','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','build');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','burn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','burnData');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','computeBurn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','grouptask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','importBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','importtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','kanban');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','team');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','testtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','tree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','project','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','qa','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','release','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','release','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','release','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','report','bugAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','report','bugCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','report','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','report','productSummary');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','report','projectDeviation');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','report','workload');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','search','buildForm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','search','buildQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','search','deleteQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','search','saveQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','search','select');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','story','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','story','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','story','tasks');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','story','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','story','zeroCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','svn','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','svn','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','svn','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','cancel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','deleteEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','editEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','pause');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','recordEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','restart');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','task','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','confirmChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','createBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','exportTemplet');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','import');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','linkCases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','showImport');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','unlinkCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testcase','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','batchAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','batchRun');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','cases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','linkcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','results');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','runcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','unlinkcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','testtask','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','batchFinish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','import2Today');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','todo','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('3','user','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','action','editComment');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','action','hideAll');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','action','hideOne');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','action','trash');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','action','undelete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','admin','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','api','getModel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','batchConfirm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','batchResolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','confirmBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','deleteTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','linkBugs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','resolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','saveTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','bug','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','batchUnlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','batchUnlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','linkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','linkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','unlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','build','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','company','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','company','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','company','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','company','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','allLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','createLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','deleteLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','editLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','objectLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','showFiles');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','doc','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','extension','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','extension','obtain');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','extension','structure');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','file','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','file','download');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','file','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','file','uploadImages');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','git','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','git','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','git','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','group','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','index','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','misc','ping');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','changePassword');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','editProfile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','my','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','roadmap');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','product','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','productplan','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','productplan','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','batchedit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','batchUnlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','build');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','burn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','burnData');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','computeBurn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','grouptask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','importBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','importtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','kanban');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','linkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','manageMembers');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','manageProducts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','order');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','putoff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','suspend');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','team');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','testtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','tree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','unlinkMember');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','unlinkStory');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','project','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','qa','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','release','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','release','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','release','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','report','bugAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','report','bugCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','report','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','report','productSummary');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','report','projectDeviation');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','report','workload');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','search','buildForm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','search','buildQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','search','deleteQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','search','saveQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','search','select');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','story','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','story','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','story','tasks');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','story','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','story','zeroCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','svn','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','svn','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','svn','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','cancel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','deleteEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','editEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','pause');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','recordEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','restart');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','task','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testcase','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testcase','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testcase','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testcase','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testcase','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','cases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','results');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','testtask','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','batchFinish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','import2Today');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','todo','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','tree','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','tree','browseTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','tree','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','tree','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','tree','fix');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','tree','manageChild');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','tree','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('6','user','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','action','editComment');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','action','hideAll');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','action','hideOne');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','action','trash');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','action','undelete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','admin','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','api','getModel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','batchConfirm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','batchResolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','confirmBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','deleteTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','linkBugs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','resolve');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','saveTemplate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','unlinkBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','bug','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','build','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','build','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','build','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','build','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','company','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','company','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','company','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','company','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','allLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','createLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','deleteLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','editLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','objectLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','showFiles');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','doc','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','extension','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','extension','obtain');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','extension','structure');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','file','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','file','download');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','file','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','file','uploadImages');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','git','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','git','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','git','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','group','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','index','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','misc','ping');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','changePassword');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','editProfile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','my','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','roadmap');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','product','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','productplan','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','productplan','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','build');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','burn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','burnData');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','grouptask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','importBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','importtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','kanban');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','team');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','testtask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','tree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','project','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','qa','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','release','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','release','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','release','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','report','bugAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','report','bugCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','report','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','report','productSummary');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','report','projectDeviation');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','report','workload');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','search','buildForm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','search','buildQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','search','deleteQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','search','saveQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','search','select');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','story','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','story','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','story','tasks');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','story','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','story','zeroCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','svn','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','svn','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','svn','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','activate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','assignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','batchAssignTo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','batchClose');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','cancel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','deleteEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','editEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','pause');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','recordEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','restart');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','task','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','batchChangeModule');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','batchDelete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','confirmChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','confirmStoryChange');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','createBug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','exportTemplet');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','import');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','linkCases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','showImport');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','unlinkCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testcase','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','batchAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','batchRun');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','cases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','close');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','linkcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','results');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','runcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','start');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','unlinkcase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','testtask','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','batchFinish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','import2Today');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','todo','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','tree','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','tree','browseTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','tree','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','tree','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','tree','fix');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','tree','manageChild');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','tree','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('8','user','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','action','editComment');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','action','hideAll');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','action','hideOne');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','action','trash');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','action','undelete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','admin','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','api','getModel');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','bug','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','bug','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','bug','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','bug','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','bug','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','build','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','company','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','company','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','company','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','company','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','company','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','dept','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','dept','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','dept','manageChild');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','dept','updateOrder');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','allLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','createLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','deleteLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','editLib');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','objectLibs');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','showFiles');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','doc','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','extension','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','extension','obtain');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','extension','structure');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','file','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','file','download');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','file','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','file','uploadImages');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','git','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','git','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','git','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','group','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','index','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','misc','ping');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','changePassword');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','editProfile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','my','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','roadmap');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','product','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','productplan','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','productplan','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','all');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','build');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','burn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','burnData');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','computeBurn');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','doc');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','grouptask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','kanban');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','team');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','tree');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','project','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','qa','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','release','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','release','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','release','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','report','bugAssign');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','report','bugCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','report','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','report','productSummary');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','report','projectDeviation');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','report','workload');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','search','buildForm');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','search','buildQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','search','deleteQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','search','saveQuery');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','search','select');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','story','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','story','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','story','review');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','story','tasks');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','story','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','story','zeroCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','svn','apiSync');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','svn','cat');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','svn','diff');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','task','deleteEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','task','editEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','task','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','task','recordEstimate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','task','report');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','task','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testcase','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testcase','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testcase','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testcase','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testcase','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testtask','browse');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testtask','cases');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testtask','groupCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testtask','index');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testtask','results');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','testtask','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','batchFinish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','export');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','finish');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','import2Today');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','todo','view');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','batchCreate');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','batchEdit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','bug');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','create');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','delete');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','deleteContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','dynamic');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','edit');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','manageContacts');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','profile');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','project');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','story');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','task');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','testCase');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','testTask');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','todo');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','unbind');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','unlock');
INSERT INTO `zt_grouppriv`(`group`,`module`,`method`) VALUES ('9','user','view');
DROP TABLE IF EXISTS `zt_history`;
CREATE TABLE `zt_history` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `action` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `field` varchar(30) NOT NULL DEFAULT '',
  `old` text NOT NULL,
  `new` text NOT NULL,
  `diff` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `action` (`action`)
) ENGINE=MyISAM AUTO_INCREMENT=364 DEFAULT CHARSET=utf8;
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('1','8','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('2','18','uid','','582f07fd3d20c','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('3','26','realStarted','0000-00-00','2016-11-18','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('4','26','uid','','582f09dd80299','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('5','26','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('6','29','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('7','36','realStarted','0000-00-00','2016-11-18','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('8','36','left','0','9','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('9','36','uid','','582f0d280dac5','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('10','36','assignedTo','gqf','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('11','36','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('12','38','assignedTo','neroyang','gqf','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('13','41','realStarted','0000-00-00','2016-11-18','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('14','41','left','0','70','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('15','41','uid','','582f0eb30d5d1','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('16','41','assignedTo','szy','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('17','41','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('18','42','assignedTo','neroyang','szy','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('19','44','uid','','582f195be38a5','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('20','47','consumed','0','1','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('21','47','finishedDate','','2016-11-18 23:20:02','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('22','47','uid','','582f1c14416da','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('23','47','left','70','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('24','47','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('25','47','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('26','48','realStarted','0000-00-00','2016-11-18','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('27','48','uid','','582f1c2caf6a5','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('28','48','assignedTo','wjd','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('29','48','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('30','49','assignedTo','neroyang','wjd','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('31','49','uid','','582f1c36104e9','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('32','50','realStarted','0000-00-00','2016-11-18','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('33','50','uid','','582f1c3dcb4e9','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('34','50','assignedTo','wjd','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('35','50','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('36','52','assignedTo','neroyang','wjd','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('37','52','uid','','582f1c453de46','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('38','55','realStarted','0000-00-00','2016-11-18','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('39','55','uid','','582f1d572dfba','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('40','55','assignedTo','tyf','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('41','55','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('42','56','assignedTo','neroyang','tyf','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('43','56','uid','','582f1d5fc5d76','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('44','64','realStarted','0000-00-00','2016-11-19','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('45','64','uid','','582f3e010f07d','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('46','64','assignedTo','bjh','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('47','64','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('48','65','assignedTo','neroyang','bjh','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('49','65','uid','','582f3e05b3c15','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('50','74','realStarted','0000-00-00','2016-11-19','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('51','74','uid','','582fe171350cb','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('52','74','assignedTo','lifeng','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('53','74','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('54','75','assignedTo','neroyang','lifeng','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('55','75','uid','','582fe189796df','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('56','79','realStarted','0000-00-00','2016-11-19','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('57','79','uid','','582fe3e1596fb','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('58','79','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('59','80','realStarted','0000-00-00','2016-11-19','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('60','80','uid','','582fe41f89c65','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('61','80','assignedTo','yuchunyu','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('62','80','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('63','81','assignedTo','neroyang','yuchunyu','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('64','81','uid','','582fe4264480a','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('65','83','name','管理平台资源管理','资源管理服务联调','001- <del>管理平台资源管理</del>
001+ <ins>资源管理服务联调</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('66','84','realStarted','0000-00-00','2016-11-19','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('67','84','uid','','582fe6bdebd1e','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('68','84','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('69','89','consumed','0','1','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('70','89','finishedDate','','2016-11-19 13:49:54','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('71','89','uid','','582fe7f3051e8','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('72','89','left','7','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('73','89','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('74','89','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('75','95','status','doing','wait','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('76','95','mailto',',bjh',',bjh,neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('77','97','uid','','582ffb53b8b29','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('78','97','status','done','closed','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('79','97','assignedTo','wjd','closed','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('80','97','closedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('81','97','closedDate','','2016-11-19 15:12:22','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('82','97','closedReason','','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('83','99','uid','','58300b1d7d4bb','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('84','99','status','done','closed','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('85','99','assignedTo','yuchunyu','closed','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('86','99','closedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('87','99','closedDate','','2016-11-19 16:19:47','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('88','99','closedReason','','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('89','110','consumed','0','7','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('90','110','finishedDate','','2016-11-20 14:48:59','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('91','110','uid','','583147525b8ea','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('92','110','left','5','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('93','110','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('94','110','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('95','115','title','spriingmvc文档','springmvc文档','001- <del>spriingmvc文档</del>
001+ <ins>springmvc文档</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('96','125','content','># php后端
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
># 前端
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','># php后端
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
># 前端
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','009- <del>># 前端</del>
009+ <ins>5. ## 了解linux操作系统，以及shell脚本编写。</ins>
010- <del>1. ## 掌握html，css，javascript语言，jquery框架。</del>
010+ <ins>># 前端</ins>
011- <del>2. ## 了解vue，react，angular等热门前端框架。</del>
011+ <ins>1. ## 掌握html，css，javascript语言，jquery框架。</ins>
012- <del>3. ## 了解webpack等前端构建工具。</del>
012+ <ins>2. ## 了解vue，react，angular等热门前端框架。</ins>
013+ <ins>3. ## 了解webpack等前端构建工具。</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('97','126','content','># php后端
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
># 前端
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','002- <del>1. ## 掌握php语言，laravel框架，以及mysql。</del>
002+ <ins>> ##  负责click问答社区后端开发及维护。</ins>
003- <del>2. ## 了解linux操作系统，掌握基本命令。</del>
003+ <ins>1. ## 掌握php语言，laravel框架，以及mysql。</ins>
004- <del>># java后端</del>
004+ <ins>2. ## 了解linux操作系统，掌握基本命令。</ins>
005- <del>1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。</del>
005+ <ins>># java后端</ins>
006- <del>2. ## 了解分布式系统，了解SOA架构（面向服务架构）。</del>
006+ <ins>>## 负责click基因大数据可视平台后端开发及维护。</ins>
007- <del>3. ## 了解redis缓存，以及redis集群搭建。</del>
007+ <ins>1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。</ins>
008- <del>4. ## 了解zookeeper，以及zookeeper集群搭建。</del>
008+ <ins>2. ## 了解分布式系统，了解SOA架构（面向服务架构）。</ins>
009- <del>5. ## 了解linux操作系统，以及shell脚本编写。</del>
009+ <ins>3. ## 了解redis缓存，以及redis集群搭建。</ins>
010- <del>># 前端</del>
010+ <ins>4. ## 了解zookeeper，以及zookeeper集群搭建。</ins>
011- <del>1. ## 掌握html，css，javascript语言，jquery框架。</del>
011+ <ins>5. ## 了解linux操作系统，以及shell脚本编写。</ins>
012- <del>2. ## 了解vue，react，angular等热门前端框架。</del>
012+ <ins>># 前端</ins>
013- <del>3. ## 了解webpack等前端构建工具。</del>
013+ <ins>>## 负责click全站前端开发及维护。</ins>
014+ <ins>1. ## 掌握html，css，javascript语言，jquery框架。</ins>
015+ <ins>2. ## 了解vue，react，angular等热门前端框架。</ins>
016+ <ins>3. ## 了解webpack等前端构建工具。</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('98','127','content','># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','# 分组描述
___
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。

___
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
___
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','001- <del>># php后端</del>
001+ <ins># 分组描述</ins>
002- <del>> ##  负责click问答社区后端开发及维护。</del>
002+ <ins>___</ins>
003- <del>1. ## 掌握php语言，laravel框架，以及mysql。</del>
003+ <ins>># php后端</ins>
004- <del>2. ## 了解linux操作系统，掌握基本命令。</del>
004+ <ins>> ##  负责click问答社区后端开发及维护。</ins>
005- <del>># java后端</del>
005+ <ins>1. ## 掌握php语言，laravel框架，以及mysql。</ins>
006- <del>>## 负责click基因大数据可视平台后端开发及维护。</del>
006+ <ins>2. ## 了解linux操作系统，掌握基本命令。</ins>
007- <del>1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。</del>
007+ <ins></ins>
008- <del>2. ## 了解分布式系统，了解SOA架构（面向服务架构）。</del>
008+ <ins>___</ins>
009- <del>3. ## 了解redis缓存，以及redis集群搭建。</del>
009+ <ins>># java后端</ins>
010- <del>4. ## 了解zookeeper，以及zookeeper集群搭建。</del>
010+ <ins>>## 负责click基因大数据可视平台后端开发及维护。</ins>
011- <del>5. ## 了解linux操作系统，以及shell脚本编写。</del>
011+ <ins>1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。</ins>
012- <del>># 前端</del>
012+ <ins>2. ## 了解分布式系统，了解SOA架构（面向服务架构）。</ins>
013- <del>>## 负责click全站前端开发及维护。</del>
013+ <ins>3. ## 了解redis缓存，以及redis集群搭建。</ins>
014- <del>1. ## 掌握html，css，javascript语言，jquery框架。</del>
014+ <ins>4. ## 了解zookeeper，以及zookeeper集群搭建。</ins>
015- <del>2. ## 了解vue，react，angular等热门前端框架。</del>
015+ <ins>5. ## 了解linux操作系统，以及shell脚本编写。</ins>
016- <del>3. ## 了解webpack等前端构建工具。</del>
016+ <ins>___</ins>
017+ <ins>># 前端</ins>
018+ <ins>>## 负责click全站前端开发及维护。</ins>
019+ <ins>1. ## 掌握html，css，javascript语言，jquery框架。</ins>
020+ <ins>2. ## 了解vue，react，angular等热门前端框架。</ins>
021+ <ins>3. ## 了解webpack等前端构建工具。</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('99','128','content','# 分组描述
___
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。

___
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
___
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','# 分组描述
_________________________________________________________________________________________
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。

__________________________________________________________________________________________
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
____________________________________________________________________________________________
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','002- <del>___</del>
002+ <ins>_________________________________________________________________________________________</ins>
008- <del>___</del>
008+ <ins>__________________________________________________________________________________________</ins>
016- <del>___</del>
016+ <ins>____________________________________________________________________________________________</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('100','129','content','# 分组描述
_________________________________________________________________________________________
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。

__________________________________________________________________________________________
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
____________________________________________________________________________________________
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','# 分组描述
***
># php后端
> ##  负责click问答社区后端开发及维护。
1. ## 掌握php语言，laravel框架，以及mysql。
2. ## 了解linux操作系统，掌握基本命令。
***
># java后端
>## 负责click基因大数据可视平台后端开发及维护。
1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。
2. ## 了解分布式系统，了解SOA架构（面向服务架构）。
3. ## 了解redis缓存，以及redis集群搭建。
4. ## 了解zookeeper，以及zookeeper集群搭建。
5. ## 了解linux操作系统，以及shell脚本编写。
***
># 前端
>## 负责click全站前端开发及维护。
1. ## 掌握html，css，javascript语言，jquery框架。
2. ## 了解vue，react，angular等热门前端框架。
3. ## 了解webpack等前端构建工具。','002- <del>_________________________________________________________________________________________</del>
002+ <ins>***</ins>
007- <del></del>
007+ <ins>***</ins>
008- <del>__________________________________________________________________________________________</del>
008+ <ins>># java后端</ins>
009- <del>># java后端</del>
009+ <ins>>## 负责click基因大数据可视平台后端开发及维护。</ins>
010- <del>>## 负责click基因大数据可视平台后端开发及维护。</del>
010+ <ins>1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。</ins>
011- <del>1. ## 掌握java语言，springMVC框架，mybatis框架，dubbo，mysql。</del>
011+ <ins>2. ## 了解分布式系统，了解SOA架构（面向服务架构）。</ins>
012- <del>2. ## 了解分布式系统，了解SOA架构（面向服务架构）。</del>
012+ <ins>3. ## 了解redis缓存，以及redis集群搭建。</ins>
013- <del>3. ## 了解redis缓存，以及redis集群搭建。</del>
013+ <ins>4. ## 了解zookeeper，以及zookeeper集群搭建。</ins>
014- <del>4. ## 了解zookeeper，以及zookeeper集群搭建。</del>
014+ <ins>5. ## 了解linux操作系统，以及shell脚本编写。</ins>
015- <del>5. ## 了解linux操作系统，以及shell脚本编写。</del>
015+ <ins>***</ins>
016- <del>____________________________________________________________________________________________</del>
016+ <ins>># 前端</ins>
017- <del>># 前端</del>
017+ <ins>>## 负责click全站前端开发及维护。</ins>
018- <del>>## 负责click全站前端开发及维护。</del>
018+ <ins>1. ## 掌握html，css，javascript语言，jquery框架。</ins>
019- <del>1. ## 掌握html，css，javascript语言，jquery框架。</del>
019+ <ins>2. ## 了解vue，react，angular等热门前端框架。</ins>
020- <del>2. ## 了解vue，react，angular等热门前端框架。</del>
020+ <ins>3. ## 了解webpack等前端构建工具。</ins>
021- <del>3. ## 了解webpack等前端构建工具。</del>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('101','142','content','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1,2,3,4。。。（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，。。。。）
***
> ## 整合表示例
> ### example1：lgg_n_c_0_1
> ### example2: gbm_t_m_1_3','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：lgg_n_c_0_1
> ### example2: gbm_t_m_1_3','013- <del>> ### 0,1,2,3,4。。。（0只有单表，1表示有多表）</del>
013+ <ins>> ### 0,1（0只有单表，1表示有多表）</ins>
016- <del>> ### 1,2,3,4。。。（1，表示只有单张表，。。。。）</del>
016+ <ins>> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('102','143','content','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：lgg_n_c_0_1
> ### example2: gbm_t_m_1_3','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1.#### gbm_t_m_1_3
> 2.#### gnm_t_m_2_3
> 3.#### gbm_t_m_3_3
> ','019- <del>> ### example1：lgg_n_c_0_1</del>
019+ <ins>> ### example1：</ins>
020- <del>> ### example2: gbm_t_m_1_3</del>
020+ <ins>>1. #### lgg_n_c_0_1</ins>
021+ <ins>> ### example2:</ins>
022+ <ins>> 1.#### gbm_t_m_1_3</ins>
023+ <ins>> 2.#### gnm_t_m_2_3</ins>
024+ <ins>> 3.#### gbm_t_m_3_3</ins>
025+ <ins>></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('103','144','content','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1.#### gbm_t_m_1_3
> 2.#### gnm_t_m_2_3
> 3.#### gbm_t_m_3_3
> ','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1. #### gbm_t_m_1_3
> 2. #### gnm_t_m_2_3
> 3. #### gbm_t_m_3_3
> ','022- <del>> 1.#### gbm_t_m_1_3</del>
022+ <ins>> 1. #### gbm_t_m_1_3</ins>
023- <del>> 2.#### gnm_t_m_2_3</del>
023+ <ins>> 2. #### gnm_t_m_2_3</ins>
024- <del>> 3.#### gbm_t_m_3_3</del>
024+ <ins>> 3. #### gbm_t_m_3_3</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('104','149','content','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1（0只有单表，1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1. #### gbm_t_m_1_3
> 2. #### gnm_t_m_2_3
> 3. #### gbm_t_m_3_3
> ','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1. #### gbm_t_m_1_3
> 2. #### gnm_t_m_2_3
> 3. #### gbm_t_m_3_3
> ','013- <del>> ### 0,1（0只有单表，1表示有多表）</del>
013+ <ins>> ### 0,1，2...n（0只有单表，>=1表示有多表）</ins>
016- <del>> ### 1,2,3,4。。。（1，表示只有单张表，2。。。。）</del>
016+ <ins>> ### 1,2,3,4...n（1，表示只有单张表，2....n）</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('105','150','content','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1
> ### example2: 
> 1. #### gbm_t_m_1_3
> 2. #### gnm_t_m_2_3
> 3. #### gbm_t_m_3_3
> ','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','020- <del>>1. #### lgg_n_c_0_1</del>
020+ <ins>>1. #### lgg_n_c_0_1   【基因lgg正常拷贝数数据单张表】</ins>
022- <del>> 1. #### gbm_t_m_1_3</del>
022+ <ins>> 1. #### gbm_t_m_1_3 【基因gbm不正常甲基化样本数据三张表第一张】</ins>
023- <del>> 2. #### gnm_t_m_2_3</del>
023+ <ins>> 2. #### gnm_t_m_2_3 【基因gbm不正常甲基化样本数据三张表第二张】</ins>
024- <del>> 3. #### gbm_t_m_3_3</del>
024+ <ins>> 3. #### gbm_t_m_3_3 【基因gbm不正常甲基化样本数据三张表第三张】</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('106','151','uid','','5833eca1482dd','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('107','151','status','doing','cancel','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('108','151','finishedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('109','151','canceledBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('110','151','canceledDate','','2016-11-22 14:58:43','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('111','152','title','数据表命名规范[新方案]','数据表命名规范 1.0  [新方案]','001- <del>数据表命名规范[新方案]</del>
001+ <ins>数据表命名规范 1.0  [新方案]</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('112','158','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('113','158','finishedDate','','2016-11-22 19:55:39','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('114','158','uid','','58343232c760c','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('115','158','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('116','158','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('117','159','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('118','159','finishedDate','','2016-11-22 19:55:44','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('119','159','uid','','5834323d5ea8b','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('120','159','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('121','159','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('122','160','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('123','160','finishedDate','','2016-11-22 19:55:50','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('124','160','uid','','583432433ee51','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('125','160','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('126','160','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('127','162','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('128','162','finishedDate','','2016-11-22 19:56:27','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('129','162','uid','','5834326791358','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('130','162','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('131','162','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('132','168','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('133','168','finishedDate','','2016-11-22 19:59:40','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('134','168','uid','','583433295a9ca','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('135','168','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('136','168','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('137','169','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('138','169','finishedDate','','2016-11-22 19:59:47','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('139','169','uid','','5834332f9b6a5','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('140','169','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('141','169','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('142','170','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('143','170','finishedDate','','2016-11-22 19:59:52','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('144','170','uid','','5834333501db5','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('145','170','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('146','170','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('147','172','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('148','172','finishedDate','','2016-11-22 20:00:55','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('149','172','uid','','5834337314700000000','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('150','172','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('151','172','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('152','173','left','7','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('153','173','uid','','5834338abec96','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('154','173','status','cancel','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('155','173','canceledBy','neroyang','','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('156','173','finishedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('157','173','canceledDate','2016-11-22 14:58:43','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('158','173','closedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('159','174','uid','','583433b3da472','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('160','174','status','doing','cancel','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('161','174','assignedTo','wjd','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('162','174','finishedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('163','174','canceledBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('164','174','canceledDate','','2016-11-22 20:01:57','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('165','180','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('166','180','finishedDate','','2016-11-22 20:07:00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('167','180','uid','','583434df81d8e','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('168','180','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('169','180','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('170','181','name','数据库使用新方案','数据新方案','001- <del>数据库使用新方案</del>
001+ <ins>数据新方案</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('171','183','left','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('172','183','uid','','583437a345cfe','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('173','183','status','done','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('174','183','finishedBy','neroyang','','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('175','183','finishedDate','2016-11-20 14:48:59','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('176','183','canceledDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('177','183','closedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('178','184','assignedTo','closed','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('179','184','left','0','1','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('180','184','uid','','583437c9581e1','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('181','184','status','closed','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('182','184','finishedBy','neroyang','','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('183','184','closedBy','neroyang','','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('184','184','closedReason','done','','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('185','184','finishedDate','2016-11-18 23:20:02','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('186','184','canceledDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('187','184','closedDate','2016-11-19 15:12:22','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('188','185','uid','','583437d864b49','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('189','185','status','doing','cancel','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('190','185','finishedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('191','185','canceledBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('192','185','canceledDate','','2016-11-22 20:19:39','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('193','193','name','阿里云部署','服务部署【阿里云】','001- <del>阿里云部署</del>
001+ <ins>服务部署【阿里云】</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('194','194','PO','','neroyang','001- <del></del>
001+ <ins>neroyang</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('195','194','QD','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('196','194','PM','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('197','194','RD','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('198','196','realStarted','0000-00-00','2016-11-23','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('199','196','uid','','583542ff870fb','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('200','196','assignedTo','yuchunyu','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('201','196','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('202','197','assignedTo','neroyang','yuchunyu','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('203','197','uid','','5835430a595f9','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('204','198','realStarted','0000-00-00','2016-11-23','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('205','198','uid','','5835431638587','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('206','198','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('207','199','assignedTo','neroyang','wjd','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('208','199','left','1','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('209','199','uid','','58354345e9f94','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('210','199','status','cancel','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('211','199','canceledBy','neroyang','','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('212','199','finishedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('213','199','canceledDate','2016-11-22 20:19:39','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('214','199','closedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('215','200','name','分布式数据库','【数据库】分布式数据库','001- <del>分布式数据库</del>
001+ <ins>【数据库】分布式数据库</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('216','201','name','deflection','【data service】deflection','001- <del>deflection</del>
001+ <ins>【data service】deflection</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('217','202','name','manhattan','【data service】manhattan','001- <del>manhattan</del>
001+ <ins>【data service】manhattan</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('218','203','name','mountain','【data service】mountain','001- <del>mountain</del>
001+ <ins>【data service】mountain</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('219','204','name','模块管理，page管理，资源管理整合','【admin web】模块管理，page管理，资源管理整合','001- <del>模块管理，page管理，资源管理整合</del>
001+ <ins>【admin web】模块管理，page管理，资源管理整合</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('220','205','name','analysis模块管理 服务联调','【data web】analysis模块管理 服务联调','001- <del>analysis模块管理 服务联调</del>
001+ <ins>【data web】analysis模块管理 服务联调</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('221','206','name','analysis模块管理','【admin service】analysis模块管理','001- <del>analysis模块管理</del>
001+ <ins>【admin service】analysis模块管理</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('222','207','name','数据新方案','【database】数据新方案','001- <del>数据新方案</del>
001+ <ins>【database】数据新方案</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('223','208','name','首页修改 1','【前端】首页修改 1','001- <del>首页修改 1</del>
001+ <ins>【前端】首页修改 1</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('224','209','name','服务部署【阿里云】','【集成】服务部署【阿里云】','001- <del>服务部署【阿里云】</del>
001+ <ins>【集成】服务部署【阿里云】</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('225','210','name','资源管理服务联调','【resource web】资源管理服务联调','001- <del>资源管理服务联调</del>
001+ <ins>【resource web】资源管理服务联调</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('226','211','name','ResourceService 测试','【resource service】ResourceService 测试','001- <del>ResourceService 测试</del>
001+ <ins>【resource service】ResourceService 测试</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('227','212','name','数据库新方案数据','【database】数据库新方案数据','001- <del>数据库新方案数据</del>
001+ <ins>【database】数据库新方案数据</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('228','213','name','问答社区软件整体设计','【社区】问答社区软件整体设计','001- <del>问答社区软件整体设计</del>
001+ <ins>【社区】问答社区软件整体设计</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('229','214','name','分布式缓存','【cache】分布式缓存','001- <del>分布式缓存</del>
001+ <ins>【cache】分布式缓存</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('230','215','name','【cache】分布式缓存','【cache service】分布式缓存','001- <del>【cache】分布式缓存</del>
001+ <ins>【cache service】分布式缓存</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('231','216','name','管理login，auth服务联调','【sso web】管理login，auth服务联调','001- <del>管理login，auth服务联调</del>
001+ <ins>【sso web】管理login，auth服务联调</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('232','217','name','auth','【sso service】auth','001- <del>auth</del>
001+ <ins>【sso service】auth</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('233','218','name','register ','【sso service】register ','001- <del>register</del>
001+ <ins>【sso service】register</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('234','219','name','login','【sso service】login','001- <del>login</del>
001+ <ins>【sso service】login</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('235','220','name','beesworm data','【data service】beesworm data','001- <del>beesworm data</del>
001+ <ins>【data service】beesworm data</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('236','221','name','beesworm T-test','【data web】beesworm T-test','001- <del>beesworm T-test</del>
001+ <ins>【data web】beesworm T-test</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('237','222','name','beesworm cutoff','【data web】beesworm cutoff','001- <del>beesworm cutoff</del>
001+ <ins>【data web】beesworm cutoff</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('238','223','name','beesworm boxplot','【data web】beesworm boxplot','001- <del>beesworm boxplot</del>
001+ <ins>【data web】beesworm boxplot</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('239','224','name','问答社区','【社区】问答社区','001- <del>问答社区</del>
001+ <ins>【社区】问答社区</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('240','229','content','# 设备购置
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 * 2
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 * 1
> ## 颜色 银白
> ## 大小 13 寸','# 设备购置
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 × 1 = ￥12422
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 33124
','006- <del>> ## 价格 $1499 * 2</del>
006+ <ins>> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702</ins>
014- <del>> ## 价格 $1799 * 1</del>
014+ <ins>> ## 价格 $1799 × 1 = ￥12422</ins>
017+ <ins></ins>
018+ <ins>***</ins>
019+ <ins>## 总价 ￥ 33124</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('241','230','content','# 设备购置
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 × 1 = ￥12422
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 33124
','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 × 1 = ￥12422
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 33124
','002- <del>>  # mac book pro</del>
002+ <ins>***</ins>
003- <del>> ## mac book pro 2016 无 TouchBar</del>
003+ <ins>>  # mac book pro</ins>
004- <del>> ## 购置数量 2 台</del>
004+ <ins>> ## mac book pro 2016 无 TouchBar</ins>
005- <del>> ## 配置 默认配置</del>
005+ <ins>> ## 购置数量 2 台</ins>
006- <del>> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702</del>
006+ <ins>> ## 配置 默认配置</ins>
007- <del>> ## 颜色 深空灰色</del>
007+ <ins>> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702</ins>
008- <del>> ## 大小 13 寸</del>
008+ <ins>> ## 颜色 深空灰色</ins>
009- <del>***</del>
009+ <ins>> ## 大小 13 寸</ins>
010- <del>> # mac book pro</del>
010+ <ins>***</ins>
011- <del>> ## mac book pro 2016 有 TouchBar</del>
011+ <ins>> # mac book pro</ins>
012- <del>> ## 购置数量 1 台</del>
012+ <ins>> ## mac book pro 2016 有 TouchBar</ins>
013- <del>> ## 配置 默认配置</del>
013+ <ins>> ## 购置数量 1 台</ins>
014- <del>> ## 价格 $1799 × 1 = ￥12422</del>
014+ <ins>> ## 配置 默认配置</ins>
015- <del>> ## 颜色 银白</del>
015+ <ins>> ## 价格 $1799 × 1 = ￥12422</ins>
016- <del>> ## 大小 13 寸</del>
016+ <ins>> ## 颜色 银白</ins>
017- <del></del>
017+ <ins>> ## 大小 13 寸</ins>
018- <del>***</del>
018+ <ins></ins>
019- <del>## 总价 ￥ 33124</del>
019+ <ins>***</ins>
020+ <ins>## 总价 ￥ 33124</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('242','232','content','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格 $1799 × 1 = ￥12422
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 33124
','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 ￥ 11488 × 2 = ￥ 22976
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格  ￥13888
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 36864
','007- <del>> ## 价格 $1499 × 2 = ￥ 10351 × 2 = ￥ 20702</del>
007+ <ins>> ## 价格 ￥ 11488 × 2 = ￥ 22976</ins>
015- <del>> ## 价格 $1799 × 1 = ￥12422</del>
015+ <ins>> ## 价格  ￥13888</ins>
020- <del>## 总价 ￥ 33124</del>
020+ <ins>## 总价 ￥ 36864</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('243','233','content','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 ￥ 11488 × 2 = ￥ 22976
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格  ￥13888
> ## 颜色 银白
> ## 大小 13 寸

***
## 总价 ￥ 36864
','# 设备购置
***
>  # mac book pro 
> ## mac book pro 2016 无 TouchBar
> ## 购置数量 2 台
> ## 配置 默认配置
> ## 价格 ￥ 11488 × 2 = ￥ 22976
> ## 颜色 深空灰色
> ## 大小 13 寸
***
> # mac book pro
> ## mac book pro 2016 有 TouchBar
> ## 购置数量 1 台
> ## 配置 默认配置
> ## 价格  ￥13888
> ## 颜色 深空灰色
> ## 大小 13 寸

***
## 总价 ￥ 36864
','016- <del>> ## 颜色 银白</del>
016+ <ins>> ## 颜色 深空灰色</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('244','241','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('245','241','finishedDate','','2016-11-24 21:12:58','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('246','241','uid','','5836e754bde5f','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('247','241','left','10','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('248','241','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('249','241','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('250','247','realStarted','0000-00-00','2016-11-24','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('251','247','uid','','5836f60312943','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('252','247','assignedTo','czw','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('253','247','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('254','249','assignedTo','neroyang','czw','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('255','249','uid','','58371039091fd','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('256','252','finishedDate','','2016-11-25 13:14:13','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('257','252','uid','','5837c89ea9d23','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('258','252','left','10','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('259','252','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('260','252','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('261','253','assignedTo','neroyang','wjd','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('262','253','left','250','200','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('263','253','uid','','5837c8add0719','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('264','253','status','cancel','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('265','253','canceledBy','neroyang','','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('266','253','finishedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('267','253','canceledDate','2016-11-22 20:01:57','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('268','253','closedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('269','254','uid','','5837d46652169','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('270','254','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('271','257','name','[document] introduction document','【文档】介绍等相关文档编写','001- <del>[document] introduction document</del>
001+ <ins>【文档】介绍等相关文档编写</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('272','258','consumed','0','4','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('273','258','finishedDate','','2016-11-25 14:54:36','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('274','258','uid','','5837e0222fa4a','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('275','258','left','9','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('276','258','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('277','258','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('278','262','desc','搭建lamp开发环境，并搭建laravel框架，实现简单留言板系统，留言，增删改查即可。','<p>搭建lamp开发环境，并搭建laravel框架.</p>
<p>laravel5.1.11的一键安装包在附件里.</p>
<p>解压后放到wamp/www/目录下即可</p>
<p><br /></p>
<p><br /></p>','001- <del>搭建lamp开发环境，并搭建laravel框架，实现简单留言板系统，留言，增删改查即可。</del>
001+ <ins><p>搭建lamp开发环境，并搭建laravel框架.</p></ins>
002+ <ins><p>laravel5.1.11的一键安装包在附件里.</p></ins>
003+ <ins><p>解压后放到wamp/www/目录下即可</p></ins>
004+ <ins><p><br /></p></ins>
005+ <ins><p><br /></p></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('279','265','consumed','0','70','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('280','265','finishedDate','','2016-11-25 19:37:29','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('281','265','uid','','5838226ee9bf5','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('282','265','left','50','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('283','265','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('284','265','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('285','270','realStarted','0000-00-00','2016-11-25','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('286','270','uid','','58384f039676b','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('287','270','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('288','273','finishedDate','','2016-11-27 02:33:52','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('289','273','uid','','5839d58d2bd32','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('290','273','left','10','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('291','273','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('292','273','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('293','274','consumed','0','10','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('294','274','finishedDate','','2016-11-27 02:34:05','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('295','274','uid','','5839d59553c91','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('296','274','left','10','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('297','274','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('298','274','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('299','275','consumed','0','70','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('300','275','assignedTo','neroyang','bjh','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('301','275','finishedDate','','2016-11-27 02:34:19','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('302','275','uid','','5839d5a098fc7','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('303','275','left','70','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('304','275','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('305','275','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('306','276','realStarted','0000-00-00','2016-11-27','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('307','276','consumed','0','30','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('308','276','left','0','30','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('309','276','uid','','5839d5ed1ad3c','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('310','276','status','wait','doing','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('311','277','uid','','5839d607a0612','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('312','277','status','wait','cancel','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('313','277','finishedDate','','0000-00-00','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('314','277','canceledBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('315','277','canceledDate','','2016-11-27 02:35:53','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('316','281','realStarted','0000-00-00','2016-11-27','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('317','281','uid','','583aaaf5d0201','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('318','281','status','wait','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('319','281','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('320','281','finishedDate','','2016-11-27 17:44:26','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('321','288','title','买哈顿图数据数据表命名规范','麦哈顿图数据数据表命名规范','001- <del>买哈顿图数据数据表命名规范</del>
001+ <ins>麦哈顿图数据数据表命名规范</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('322','289','title','麦哈顿图数据数据表命名规范','麦哈顿图数据数据表命名规范 1.0','001- <del>麦哈顿图数据数据表命名规范</del>
001+ <ins>麦哈顿图数据数据表命名规范 1.0</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('323','293','content','# 卖哈顿图数据表命名规范
> # 数据命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan','# 卖哈顿图数据表命名规范
> # 总表命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan
***
># 样本表命名
> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 麦哈顿标识manhattan
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】
> ','002- <del>> # 数据命名</del>
002+ <ins>> # 总表命名</ins>
012+ <ins>***</ins>
013+ <ins>># 样本表命名</ins>
014+ <ins>> ## 基因名</ins>
015+ <ins>> ### 使用缩写，例如lgg，gbm....</ins>
016+ <ins>***</ins>
017+ <ins>> ## 正常与否</ins>
018+ <ins>> ### n 或者 t  （n为正常，t为不正常）</ins>
019+ <ins>***</ins>
020+ <ins>> ## 样本类型</ins>
021+ <ins>> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)</ins>
022+ <ins>***</ins>
023+ <ins>> ## 数据分表</ins>
024+ <ins>> ### 0,1，2...n（0只有单表，>=1表示有多表）</ins>
025+ <ins>***</ins>
026+ <ins>> ## 数据总表数</ins>
027+ <ins>> ### 1,2,3,4...n（1，表示只有单张表，2....n）</ins>
028+ <ins>***</ins>
029+ <ins>> ## 麦哈顿标识manhattan</ins>
030+ <ins>> ## 整合表示例</ins>
031+ <ins>> ### example1：</ins>
032+ <ins>>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】</ins>
033+ <ins>> ### example2:</ins>
034+ <ins>> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】</ins>
035+ <ins>> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】</ins>
036+ <ins>> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】</ins>
037+ <ins>></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('324','294','content','# 卖哈顿图数据表命名规范
> # 总表命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan
***
># 样本表命名
> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 麦哈顿标识manhattan
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】
> ','# 卖哈顿图数据表命名规范
> # 总表命名
> ## 数据类型
> ### 1.c m e （c 拷贝数，m甲基化，e表达量）
> ### 2.gene （标识）
> ### 3.manhattan（标识）
***
>## 整合样例
>### c_gene_manhattan
>### e_gene_manhattan
>### m_gene_manhattan
***
># 样本表命名
> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 麦哈顿标识manhattan
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】
> ','030- <del>> ## 整合表示例</del>
030+ <ins>***</ins>
031- <del>> ### example1：</del>
031+ <ins>> ## 整合表示例</ins>
032- <del>>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】</del>
032+ <ins>> ### example1：</ins>
033- <del>> ### example2:</del>
033+ <ins>>1. #### lgg_n_c_0_1_manhattan   【基因lgg正常拷贝数数据单张表】</ins>
034- <del>> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】</del>
034+ <ins>> ### example2:</ins>
035- <del>> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】</del>
035+ <ins>> 1. #### gbm_t_m_1_3_manhattan 【基因gbm不正常甲基化样本数据三张表第一张】</ins>
036- <del>> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】</del>
036+ <ins>> 2. #### gnm_t_m_2_3_manhattan 【基因gbm不正常甲基化样本数据三张表第二张】</ins>
037- <del>></del>
037+ <ins>> 3. #### gbm_t_m_3_3_manhattan 【基因gbm不正常甲基化样本数据三张表第三张】</ins>
038+ <ins>></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('325','301','consumed','0','20','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('326','301','assignedTo','szy','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('327','301','finishedDate','','2016-11-30 23:20:30','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('328','301','uid','','583eee001076b','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('329','301','left','70','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('330','301','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('331','301','finishedBy','','szy','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('332','315','content','','# linux运维学习任务

***
> 1. ## Linux系统基础
### 这个不用说了，是基础中的基础，连这个都不会就别干了，参考书籍，可以看鸟哥linux基础篇,没必须全部掌握，但基本命令总得会吧。
***
> 2. ## 网络服务
### 服务有很多种，每间公司都会用到不同的，但基础的服务肯定要掌握，如FTP, DNS,SAMBA, 邮件, 这几个大概学一下就行，LAMP和LNMP是必须要熟练，我所指的不是光光会搭建，而是要很熟悉里面的相当配置才行，因为公司最关键的绝对是WEB服务器，所以nginx和apache要熟悉，特别是nginx一定要很熟悉才行，至少有些公司还会用tomcat，这个也最好学一下。其实网络服务方面不用太担心，一般公司的环境都已经搭建好，就算有新服务器或让你整改，公司会有相应的文档让你参照来弄，不会让你乱来的，但至少相关的配置一定要学熟，而且肯定是编译安装多，那些模块要熟悉一下他的作用，特别是PHP那些模块。
***
> 3. ## shell脚本和另一个脚本语言
### shell是运维人员必须具备的，不懂这个连入职都不行，至少也要写出一些系统管理脚本，最简单也得写个监控CPU，内存比率的脚本吧，这是最最最基本了，别以为会写那些猜数字和计算什么数的，这些没什么作用，只作学习意义，写系统脚本才是最有意义，而另一个脚本语言是可选的，一般是3P，即python, perl和php，php就不需要考虑了，除非你要做开发，我个人建议学python会比较好，难实现自动化运维，perl是文本处理很强大，反正这两个学一个就行了。
***
> 4. ## sed和awk工具
### 必须要掌握，在掌握这两个工具同时，还要掌握正则表达式，这个就痛苦了，正则是最难学的表达式，但结合到sed和awk中会很强大，在处理文本内容和过滤WEB内容时十分有用，不过在学shell的同时一般会经常结合用到的，所以学第3点就会顺便学第4点。
***
> 5. ## 文本处理命令
### sort, tr, cut, paste, uniq, tee等，必学，也是结合第3点时一并学习的。
***
> 6. ## 数据库
### 首选mysql，别问我为什么不学sqlserver和oracle，因为Linux用得最多绝对是mysql，增删改查必学，特别要学熟查，其它方面可能不太需要，因为运维人员使用最多还是查，哪些优化和开发语句不会让你弄的。
***
> 7. ## 防火墙
### 不学不行，防火墙也算是个难点，说难不难，说易不易，最重要弄懂规则，如果学过CCNA的朋友可能会比较好学，因为iptables也有NAT表，原理是一样的，而FILTER表用得最多，反正不学就肯定不合格。
***
> 8. ## 监控工具
### 十分十分重要，我个人建议，最好学这3个，cacti，nagios，zabbix，企业用得最多应该是 nagios 和 zabbix，反正都学吧，但nagios会有点难，因为会涉及到用脚本写自动监控，那个地方很难。
***
> 9. ## 集群和热备
### 这个很重要，肯定要懂的，但到了公司就不会让你去弄，因为新手基本不让你碰，集群工具有很多，最好学是LVS，这是必学，最好也学学nginx集群，反向代理，还有热备，这个就更多工具能实现了，像我公司是自己开发热备工具的，mysql热备也要学，就是主从复制，这个别告诉我容易，其实不容易的，要学懂整个流程一点也不容易，只照着做根本没意思。
***
> 10. ## 数据备份
### 不学不行，工具有很多，但至少要把RAID的原理弄懂，特别是企业最常用的1+0或0+1，自己做实验也要弄出来，备份工具有很多，如tar, dump, rsync等，最好多了解一下。
*** 

## 前面3条必须学会，后面的也要学。



***','001- <del></del>
001+ <ins># linux运维学习任务</ins>
002+ <ins></ins>
003+ <ins>***</ins>
004+ <ins>> 1. ## Linux系统基础</ins>
005+ <ins>### 这个不用说了，是基础中的基础，连这个都不会就别干了，参考书籍，可以看鸟哥linux基础篇,没必须全部掌握，但基本命令总得会吧。</ins>
006+ <ins>***</ins>
007+ <ins>> 2. ## 网络服务</ins>
008+ <ins>### 服务有很多种，每间公司都会用到不同的，但基础的服务肯定要掌握，如FTP, DNS,SAMBA, 邮件, 这几个大概学一下就行，LAMP和LNMP是必须要熟练，我所指的不是光光会搭建，而是要很熟悉里面的相当配置才行，因为公司最关键的绝对是WEB服务器，所以nginx和apache要熟悉，特别是nginx一定要很熟悉才行，至少有些公司还会用tomcat，这个也最好学一下。其实网络服务方面不用太担心，一般公司的环境都已经搭建好，就算有新服务器或让你整改，公司会有相应的文档让你参照来弄，不会让你乱来的，但至少相关的配置一定要学熟，而且肯定是编译安装多，那些模块要熟悉一下他的作用，特别是PHP那些模块。</ins>
009+ <ins>***</ins>
010+ <ins>> 3. ## shell脚本和另一个脚本语言</ins>
011+ <ins>### shell是运维人员必须具备的，不懂这个连入职都不行，至少也要写出一些系统管理脚本，最简单也得写个监控CPU，内存比率的脚本吧，这是最最最基本了，别以为会写那些猜数字和计算什么数的，这些没什么作用，只作学习意义，写系统脚本才是最有意义，而另一个脚本语言是可选的，一般是3P，即python, perl和php，php就不需要考虑了，除非你要做开发，我个人建议学python会比较好，难实现自动化运维，perl是文本处理很强大，反正这两个学一个就行了。</ins>
012+ <ins>***</ins>
013+ <ins>> 4. ## sed和awk工具</ins>
014+ <ins>### 必须要掌握，在掌握这两个工具同时，还要掌握正则表达式，这个就痛苦了，正则是最难学的表达式，但结合到sed和awk中会很强大，在处理文本内容和过滤WEB内容时十分有用，不过在学shell的同时一般会经常结合用到的，所以学第3点就会顺便学第4点。</ins>
015+ <ins>***</ins>
016+ <ins>> 5. ## 文本处理命令</ins>
017+ <ins>### sort, tr, cut, paste, uniq, tee等，必学，也是结合第3点时一并学习的。</ins>
018+ <ins>***</ins>
019+ <ins>> 6. ## 数据库</ins>
020+ <ins>### 首选mysql，别问我为什么不学sqlserver和oracle，因为Linux用得最多绝对是mysql，增删改查必学，特别要学熟查，其它方面可能不太需要，因为运维人员使用最多还是查，哪些优化和开发语句不会让你弄的。</ins>
021+ <ins>***</ins>
022+ <ins>> 7. ## 防火墙</ins>
023+ <ins>### 不学不行，防火墙也算是个难点，说难不难，说易不易，最重要弄懂规则，如果学过CCNA的朋友可能会比较好学，因为iptables也有NAT表，原理是一样的，而FILTER表用得最多，反正不学就肯定不合格。</ins>
024+ <ins>***</ins>
025+ <ins>> 8. ## 监控工具</ins>
026+ <ins>### 十分十分重要，我个人建议，最好学这3个，cacti，nagios，zabbix，企业用得最多应该是 nagios 和 zabbix，反正都学吧，但nagios会有点难，因为会涉及到用脚本写自动监控，那个地方很难。</ins>
027+ <ins>***</ins>
028+ <ins>> 9. ## 集群和热备</ins>
029+ <ins>### 这个很重要，肯定要懂的，但到了公司就不会让你去弄，因为新手基本不让你碰，集群工具有很多，最好学是LVS，这是必学，最好也学学nginx集群，反向代理，还有热备，这个就更多工具能实现了，像我公司是自己开发热备工具的，mysql热备也要学，就是主从复制，这个别告诉我容易，其实不容易的，要学懂整个流程一点也不容易，只照着做根本没意思。</ins>
030+ <ins>***</ins>
031+ <ins>> 10. ## 数据备份</ins>
032+ <ins>### 不学不行，工具有很多，但至少要把RAID的原理弄懂，特别是企业最常用的1+0或0+1，自己做实验也要弄出来，备份工具有很多，如tar, dump, rsync等，最好多了解一下。</ins>
033+ <ins>***</ins>
034+ <ins></ins>
035+ <ins>## 前面3条必须学会，后面的也要学。</ins>
036+ <ins></ins>
037+ <ins></ins>
038+ <ins></ins>
039+ <ins>***</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('333','316','content','','# java后端
> 1. ## java 
> ### 掌握基本java语法，面向对象编程思想，继承，组合 等，掌握基本容器，List，Map，Set，掌握字符串操作，io操作。掌握socket编程。
***
> 2. ## SpringMvc
> ### 参考 http://www.cnblogs.com/baiduligang/p/4247164.html
***
> 3. ## mybatis
> ### 学习基本配置，映射文件编写（前提学会mysql）。
> ### 参考 http://www.mybatis.org/mybatis-3/zh/
***
> 4. ## 了解分布式系统与SOA,学习dubbo
> ### 
>5. ## 了解redis缓存，以及redis集群搭建。
>6. ## 了解zookeeper，以及zookeeper集群搭建。
>7. ## 了解linux操作系统，以及shell脚本编写。','001- <del></del>
001+ <ins># java后端</ins>
002+ <ins>> 1. ## java</ins>
003+ <ins>> ### 掌握基本java语法，面向对象编程思想，继承，组合 等，掌握基本容器，List，Map，Set，掌握字符串操作，io操作。掌握socket编程。</ins>
004+ <ins>***</ins>
005+ <ins>> 2. ## SpringMvc</ins>
006+ <ins>> ### 参考 http://www.cnblogs.com/baiduligang/p/4247164.html</ins>
007+ <ins>***</ins>
008+ <ins>> 3. ## mybatis</ins>
009+ <ins>> ### 学习基本配置，映射文件编写（前提学会mysql）。</ins>
010+ <ins>> ### 参考 http://www.mybatis.org/mybatis-3/zh/</ins>
011+ <ins>***</ins>
012+ <ins>> 4. ## 了解分布式系统与SOA,学习dubbo</ins>
013+ <ins>> ###</ins>
014+ <ins>>5. ## 了解redis缓存，以及redis集群搭建。</ins>
015+ <ins>>6. ## 了解zookeeper，以及zookeeper集群搭建。</ins>
016+ <ins>>7. ## 了解linux操作系统，以及shell脚本编写。</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('334','345','title','click','click架构文档','001- <del>click</del>
001+ <ins>click架构文档</ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('335','345','keywords','','架构','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('336','347','content','','<p style=\"text-align:center;\"><span style=\"font-family:\'宋体\';font-size:14px;\">Click<span style=\"font-family:\'宋体\';\">架构文档</span></span></p><h1><span style=\"font-family:\'宋体\';font-size:29px;\">1.</span><strong><span style=\"font-family:\'宋体\';font-size:29px;\"><span style=\"font-family:\'宋体\';\">架构设计</span></span></strong></h1><h2><span style=\"font-family:\'黑体\';font-size:21px;\">1.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">架构设计</span></span></strong></h2><p><img src=\"/data/upload/1/201612/1119315309268s1s.png\" title=\"\" alt=\"\" /><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p style=\"text-indent:28px;text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">分布式</span></span><span style=\"font-family:Arial;color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">面向服务的体系结构（</span></span><span style=\"font-family:Arial;color:rgb(204,0,0);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">SOA</span><span style=\"font-family:Arial;color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">）</span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">，</span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">通过阿里</span>dubbo <span style=\"font-family:\'宋体\';\">框架，实现模块功能服务化，通过</span><span style=\"font-family:Arial;\">zookeeper</span><span style=\"font-family:\'宋体\';\">技术，实现服务注册与发现，系统分布化。通过</span><span style=\"font-family:Arial;\">linkedin </span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">K</span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">afka<span style=\"font-family:\'宋体\';\">技术，实现分布式日志与日志聚合。使用</span><span style=\"font-family:Arial;\">echarts </span><span style=\"font-family:\'宋体\';\">实现前端数据绘制。</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">1.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">web<span style=\"font-family:\'黑体\';\">前端页面展示层</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">前端数据可视模块</span></span></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">前端页面</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">2.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">Ajax<span style=\"font-family:\'黑体\';\">接口封装层（服务消费者）</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">通过注册中心集群发现服务提供者并联合调用相应服务提供者产生相应数据传输对象。</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">3.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">Service<span style=\"font-family:\'黑体\';\">服务层（服务提供者）</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">注册服务，业务逻辑实现，等待消费者调用。</span></span></p><p><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">4.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">缓存层</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">数据磁盘缓存，分布式</span>session<span style=\"font-family:\'宋体\';\">共享，分布式日志缓存。</span></span></p><p><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p><strong><span style=\"font-family:\'黑体\';font-size:21px;\">5.</span></strong><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">数据库</span></span></strong></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">基因数据库，用户数据库，日志数据库，页面相关数据库。</span></span></p><h1><strong><span style=\"font-family:\'宋体\';font-size:29px;\">2.<span style=\"font-family:\'宋体\';\">模块划分</span></span></strong></h1><p style=\"text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p style=\"text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\">&nbsp;</span></p><p><br /></p>','001- <del></del>
001+ <ins><p style=\"text-align:center;\"><span style=\"font-family:\'宋体\';font-size:14px;\">Click<span style=\"font-family:\'宋体\';\">架构文档</span></span></p><h1><span style=\"font-family:\'宋体\';font-size:29px;\">1.</span><strong><span style=\"font-family:\'宋体\';font-size:29px;\"><span style=\"font-family:\'宋体\';\">架构设计</span></span></strong></h1><h2><span style=\"font-family:\'黑体\';font-size:21px;\">1.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">架构设计</span></span></strong></h2><p><img src=\"/data/upload/1/201612/1119315309268s1s.png\" title=\"\" alt=\"\" /><span style=\"font-family:\'宋体\';font-size:14px;\"></span></p><p style=\"text-indent:28px;text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">分布式</span></span><span style=\"font-family:Arial;color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">面向服务的体系结构（</span></span><span style=\"font-family:Arial;color:rgb(204,0,0);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">SOA</span><span style=\"font-family:Arial;color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">）</span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">，</span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\"><span style=\"font-family:\'宋体\';\">通过阿里</span>dubbo <span style=\"font-family:\'宋体\';\">框架，实现模块功能服务化，通过</span><span style=\"font-family:Arial;\">zookeeper</span><span style=\"font-family:\'宋体\';\">技术，实现服务注册与发现，系统分布化。通过</span><span style=\"font-family:Arial;\">linkedin </span></span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">K</span><span style=\"font-family:\'宋体\';color:rgb(51,51,51);letter-spacing:0;font-size:13px;background:rgb(255,255,255);\">afka<span style=\"font-family:\'宋体\';\">技术，实现分布式日志与日志聚合。使用</span><span style=\"font-family:Arial;\">echarts </span><span style=\"font-family:\'宋体\';\">实现前端数据绘制。</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">1.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">web<span style=\"font-family:\'黑体\';\">前端页面展示层</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">前端数据可视模块</span></span></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">前端页面</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">2.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">Ajax<span style=\"font-family:\'黑体\';\">接口封装层（服务消费者）</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">通过注册中心集群发现服务提供者并联合调用相应服务提供者产生相应数据传输对象。</span></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">3.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\">Service<span style=\"font-family:\'黑体\';\">服务层（服务提供者）</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">注册服务，业务逻辑实现，等待消费者调用。</span></span></p><p><span style=\"font-family:\'宋体\';font-size:14px;\"></span></p><h2><span style=\"font-family:\'黑体\';font-size:21px;\">4.</span><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">缓存层</span></span></strong></h2><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">数据磁盘缓存，分布式</span>session<span style=\"font-family:\'宋体\';\">共享，分布式日志缓存。</span></span></p><p><span style=\"font-family:\'宋体\';font-size:14px;\"></span></p><p><strong><span style=\"font-family:\'黑体\';font-size:21px;\">5.</span></strong><strong><span style=\"font-family:\'黑体\';font-size:21px;\"><span style=\"font-family:\'黑体\';\">数据库</span></span></strong></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"></span></p><p style=\"text-indent:28px;\"><span style=\"font-family:\'宋体\';font-size:14px;\"><span style=\"font-family:\'宋体\';\">基因数据库，用户数据库，日志数据库，页面相关数据库。</span></span></p><h1><strong><span style=\"font-family:\'宋体\';font-size:29px;\">2.<span style=\"font-family:\'宋体\';\">模块划分</span></span></strong></h1><p style=\"text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\"></span></p><p style=\"text-align:justify;\"><span style=\"font-family:\'宋体\';font-size:14px;\"></span></p><p><br /></p></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('337','373','content','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_0_1   【基因lgg正常拷贝数数据单张表】
> ### example2: 
> 1. #### gbm_t_m_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
>## 数据类型
>### l取对数
>### y不取对数
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】
> ### example2: 
> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','015- <del>> ## 数据总表数</del>
015+ <ins>>## 数据类型</ins>
016- <del>> ### 1,2,3,4...n（1，表示只有单张表，2....n）</del>
016+ <ins>>### l取对数</ins>
017- <del>***</del>
017+ <ins>>### y不取对数</ins>
018- <del>> ## 整合表示例</del>
018+ <ins>> ## 数据总表数</ins>
019- <del>> ### example1：</del>
019+ <ins>> ### 1,2,3,4...n（1，表示只有单张表，2....n）</ins>
020- <del>>1. #### lgg_n_c_0_1   【基因lgg正常拷贝数数据单张表】</del>
020+ <ins>***</ins>
021- <del>> ### example2:</del>
021+ <ins>> ## 整合表示例</ins>
022- <del>> 1. #### gbm_t_m_1_3 【基因gbm不正常甲基化样本数据三张表第一张】</del>
022+ <ins>> ### example1：</ins>
023- <del>> 2. #### gnm_t_m_2_3 【基因gbm不正常甲基化样本数据三张表第二张】</del>
023+ <ins>>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】</ins>
024- <del>> 3. #### gbm_t_m_3_3 【基因gbm不正常甲基化样本数据三张表第三张】</del>
024+ <ins>> ### example2:</ins>
025- <del>></del>
025+ <ins>> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】</ins>
026+ <ins>> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】</ins>
027+ <ins>> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】</ins>
028+ <ins>></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('338','374','content','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
>## 数据类型
>### l取对数
>### y不取对数
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】
> ### example2: 
> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','# 数据表命名规范

> ## 基因名
> ### 使用缩写，例如lgg，gbm....
***
> ## 正常与否
> ### n 或者 t  （n为正常，t为不正常）
***
> ## 样本类型
> ### m，c，e  (m为甲基化，c为拷贝数，e为表达量)
***
> ## 数据分表
> ### 0,1，2...n（0只有单表，>=1表示有多表）
***
>## 数据类型
>### l取对数
>### y不取对数
***
> ## 数据总表数
> ### 1,2,3,4...n（1，表示只有单张表，2....n）
***
> ## 整合表示例
> ### example1：
>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】
> ### example2: 
> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】
> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】
> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】
> ','018- <del>> ## 数据总表数</del>
018+ <ins>***</ins>
019- <del>> ### 1,2,3,4...n（1，表示只有单张表，2....n）</del>
019+ <ins>> ## 数据总表数</ins>
020- <del>***</del>
020+ <ins>> ### 1,2,3,4...n（1，表示只有单张表，2....n）</ins>
021- <del>> ## 整合表示例</del>
021+ <ins>***</ins>
022- <del>> ### example1：</del>
022+ <ins>> ## 整合表示例</ins>
023- <del>>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】</del>
023+ <ins>> ### example1：</ins>
024- <del>> ### example2:</del>
024+ <ins>>1. #### lgg_n_c_l_0_1   【基因lgg正常拷贝数数据取对数单张表】</ins>
025- <del>> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】</del>
025+ <ins>> ### example2:</ins>
026- <del>> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】</del>
026+ <ins>> 1. #### gbm_t_m_y_1_3 【基因gbm不正常甲基化样本数据三张表第一张】</ins>
027- <del>> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】</del>
027+ <ins>> 2. #### gnm_t_m_y_2_3 【基因gbm不正常甲基化样本数据三张表第二张】</ins>
028- <del>></del>
028+ <ins>> 3. #### gbm_t_m_y_3_3 【基因gbm不正常甲基化样本数据三张表第三张】</ins>
029+ <ins>></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('339','390','content','','<h1>mean mid 表命名规范 1.0<br /></h1><p>表名：数据类型_样本类型_是否取对数_moutain</p><p>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><p>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</p><p>&nbsp; &nbsp; 注：1.geneid为基因id</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</p><p><br /></p>','001- <del></del>
001+ <ins><h1>mean mid 表命名规范 1.0<br /></h1><p>表名：数据类型_样本类型_是否取对数_moutain</p><p>注：1.数据类型为 c 或 e 或 m<br /></p><p>2.样本类型为 n 或 t<br /></p><p>3.是否取对数为 y 或 l<br /></p><p><br /></p><p><br /></p><p>字段：geneid cancertype mean mid</p><p>  注：1.geneid为基因id</p><p>2.cancertype为癌症类型<br /></p><p> 3.mean 为该基因在  数据类型_样本类型_是否取对数  下的样本平均数</p><p> 4.mid 为该基因在  数据类型_样本类型_是否取对数  下的样本中位数</p><p><br /></p></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('340','391','content','<h1>mean mid 表命名规范 1.0<br /></h1><p>表名：数据类型_样本类型_是否取对数_moutain</p><p>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><p>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</p><p>&nbsp; &nbsp; 注：1.geneid为基因id</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</p><p><br /></p>','<h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></h3><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><h2>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</h2><h3>&nbsp; &nbsp; 注：1.geneid为基因id</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</h3><p><br /></p>','001- <del><h1>mean mid 表命名规范 1.0<br /></h1><p>表名：数据类型_样本类型_是否取对数_moutain</p><p>注：1.数据类型为 c 或 e 或 m<br /></p><p>2.样本类型为 n 或 t<br /></p><p>3.是否取对数为 y 或 l<br /></p><p><br /></p><p><br /></p><p>字段：geneid cancertype mean mid</p><p>  注：1.geneid为基因id</p><p>2.cancertype为癌症类型<br /></p><p> 3.mean 为该基因在  数据类型_样本类型_是否取对数  下的样本平均数</p><p> 4.mid 为该基因在  数据类型_样本类型_是否取对数  下的样本中位数</p><p><br /></p></del>
001+ <ins><h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>注：1.数据类型为 c 或 e 或 m<br /></h3><h3>2.样本类型为 n 或 t<br /></h3><h3>3.是否取对数为 y 或 l<br /></h3><p><br /></p><p><br /></p><h2>字段：geneid cancertype mean mid</h2><h3>  注：1.geneid为基因id</h3><h3>2.cancertype为癌症类型<br /></h3><h3> 3.mean 为该基因在  数据类型_样本类型_是否取对数  下的样本平均数</h3><h3> 4.mid 为该基因在  数据类型_样本类型_是否取对数  下的样本中位数</h3><p><br /></p></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('341','392','content','<h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></h3><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><h2>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</h2><h3>&nbsp; &nbsp; 注：1.geneid为基因id</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</h3><p><br /></p>','<h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>&nbsp;&nbsp;&nbsp;&nbsp;注：1.数据类型为 c 或 e 或 m<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.样本类型为 n 或 t<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.是否取对数为 y 或 l<br /></h3><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></p><p>&nbsp;&nbsp;<br /></p><h2>字段：geneid &nbsp;cancertype &nbsp;mean &nbsp;mid&nbsp;</h2><h3>&nbsp; &nbsp; 注：1.geneid为基因id</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.cancertype为癌症类型<br /></h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;3.mean 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本平均数</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;4.mid 为该基因在 &nbsp; &nbsp;&nbsp;数据类型_样本类型_是否取对数 &nbsp; 下的样本中位数</h3><h1>例：</h1><h2>表: c_n_y_moutain</h2><table><tbody><tr class=\"firstRow\"><td width=\"276\" valign=\"top\">geneid</td><td width=\"276\" valign=\"top\">cancertype</td><td width=\"276\" valign=\"top\">mean</td><td width=\"276\" valign=\"top\">mid</td></tr><tr><td width=\"276\" valign=\"top\">1</td><td width=\"276\" valign=\"top\">gbm</td><td width=\"276\" valign=\"top\">0.989767</td><td width=\"276\" valign=\"top\">1</td></tr><tr><td width=\"276\" valign=\"top\">1</td><td width=\"276\" valign=\"top\">lgg</td><td width=\"276\" valign=\"top\">0.775648</td><td width=\"276\" valign=\"top\">0.8</td></tr></tbody></table><p><br /></p><p>行数为24702 * 35</p>','001- <del><h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>注：1.数据类型为 c 或 e 或 m<br /></h3><h3>2.样本类型为 n 或 t<br /></h3><h3>3.是否取对数为 y 或 l<br /></h3><p><br /></p><p><br /></p><h2>字段：geneid cancertype mean mid</h2><h3>  注：1.geneid为基因id</h3><h3>2.cancertype为癌症类型<br /></h3><h3> 3.mean 为该基因在  数据类型_样本类型_是否取对数  下的样本平均数</h3><h3> 4.mid 为该基因在  数据类型_样本类型_是否取对数  下的样本中位数</h3><p><br /></p></del>
001+ <ins><h1>mean mid 表命名规范 1.0<br /></h1><h2>表名：数据类型_样本类型_是否取对数_moutain</h2><h3>注：1.数据类型为 c 或 e 或 m<br /></h3><h3>2.样本类型为 n 或 t<br /></h3><h3>3.是否取对数为 y 或 l<br /></h3><p><br /></p><p><br /></p><h2>字段：geneid cancertype mean mid</h2><h3>  注：1.geneid为基因id</h3><h3>2.cancertype为癌症类型<br /></h3><h3> 3.mean 为该基因在  数据类型_样本类型_是否取对数  下的样本平均数</h3><h3> 4.mid 为该基因在  数据类型_样本类型_是否取对数  下的样本中位数</h3><h1>例：</h1><h2>表: c_n_y_moutain</h2><table><tbody><tr class=\"firstRow\"><td width=\"276\" valign=\"top\">geneid</td><td width=\"276\" valign=\"top\">cancertype</td><td width=\"276\" valign=\"top\">mean</td><td width=\"276\" valign=\"top\">mid</td></tr><tr><td width=\"276\" valign=\"top\">1</td><td width=\"276\" valign=\"top\">gbm</td><td width=\"276\" valign=\"top\">0.989767</td><td width=\"276\" valign=\"top\">1</td></tr><tr><td width=\"276\" valign=\"top\">1</td><td width=\"276\" valign=\"top\">lgg</td><td width=\"276\" valign=\"top\">0.775648</td><td width=\"276\" valign=\"top\">0.8</td></tr></tbody></table><p><br /></p><p>行数为24702 * 35</p></ins>');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('342','452','finishedDate','','2017-06-16 02:06:02','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('343','452','uid','','5942cc864975f','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('344','452','left','30','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('345','452','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('346','452','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('347','453','consumed','0','100','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('348','453','assignedTo','yuchunyu','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('349','453','finishedDate','','2017-06-16 02:06:18','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('350','453','uid','','5942cc9226c92','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('351','453','left','7','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('352','453','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('353','453','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('354','454','consumed','0','3000','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('355','454','assignedTo','wjd','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('356','454','finishedDate','','2017-06-16 02:06:29','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('357','454','uid','','5942cc9e0f8aa','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('358','454','left','200','0','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('359','454','status','doing','done','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('360','454','finishedBy','','neroyang','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('361','455','realStarted','0000-00-00','2017-06-16','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('362','455','uid','','5942ccbb3559c','');
INSERT INTO `zt_history`(`id`,`action`,`field`,`old`,`new`,`diff`) VALUES ('363','455','status','wait','doing','');
DROP TABLE IF EXISTS `zt_kevincalendar`;
CREATE TABLE `zt_kevincalendar` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `calendar` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` enum('nor','hol','law') NOT NULL DEFAULT 'nor',
  `date` date NOT NULL DEFAULT '0000-00-00',
  `desc` text NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
DROP TABLE IF EXISTS `zt_lang`;
CREATE TABLE `zt_lang` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `lang` varchar(30) NOT NULL,
  `module` varchar(30) NOT NULL,
  `section` varchar(30) NOT NULL,
  `key` varchar(60) NOT NULL,
  `value` text NOT NULL,
  `system` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lang` (`lang`,`module`,`section`,`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_mailqueue`;
CREATE TABLE `zt_mailqueue` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `toList` varchar(255) NOT NULL,
  `ccList` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `addedBy` char(30) NOT NULL,
  `addedDate` datetime NOT NULL,
  `sendTime` datetime NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'wait',
  `failReason` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sendTime` (`sendTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_module`;
CREATE TABLE `zt_module` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `root` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `branch` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` char(60) NOT NULL DEFAULT '',
  `parent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `path` char(255) NOT NULL DEFAULT '',
  `grade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `type` char(30) NOT NULL,
  `owner` varchar(30) NOT NULL,
  `short` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`root`,`type`,`path`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('1','1','0','service_data','0',',1,','1','10','story','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('2','1','0','service_admin','0',',2,','1','20','story','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('3','1','0','service_sso','0',',3,','1','30','story','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('4','1','0','web_data','0',',4,','1','40','story','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('5','1','0','web_admin','0',',5,','1','50','story','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('6','1','0','web_sso','0',',6,','1','60','story','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('7','2','0','php后端','0',',7,','1','10','task','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('8','2','0','java后端','0',',8,','1','20','task','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('9','2','0','前端','0',',9,','1','30','task','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('10','3','0','index','0',',10,','1','10','story','','');
INSERT INTO `zt_module`(`id`,`root`,`branch`,`name`,`parent`,`path`,`grade`,`order`,`type`,`owner`,`short`) VALUES ('11','1','0','service_log','0',',11,','1','70','story','','');
DROP TABLE IF EXISTS `zt_product`;
CREATE TABLE `zt_product` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(90) NOT NULL,
  `code` varchar(45) NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'normal',
  `status` varchar(30) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `PO` varchar(30) NOT NULL,
  `QD` varchar(30) NOT NULL,
  `RD` varchar(30) NOT NULL,
  `acl` enum('open','private','custom') NOT NULL DEFAULT 'open',
  `whitelist` varchar(255) NOT NULL,
  `createdBy` varchar(30) NOT NULL,
  `createdDate` datetime NOT NULL,
  `createdVersion` varchar(20) NOT NULL,
  `order` mediumint(8) unsigned NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order` (`order`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
INSERT INTO `zt_product`(`id`,`name`,`code`,`type`,`status`,`desc`,`PO`,`QD`,`RD`,`acl`,`whitelist`,`createdBy`,`createdDate`,`createdVersion`,`order`,`deleted`) VALUES ('1','click基因大数据可视平台','click','normal','normal','','neroyang','neroyang','neroyang','open','','neroyang','2016-11-18 20:20:52','8.3','5','0');
INSERT INTO `zt_product`(`id`,`name`,`code`,`type`,`status`,`desc`,`PO`,`QD`,`RD`,`acl`,`whitelist`,`createdBy`,`createdDate`,`createdVersion`,`order`,`deleted`) VALUES ('2','click问答社区','click_forum','normal','normal','','wjd','wjd','wjd','open','','neroyang','2016-11-18 20:22:17','8.3','10','0');
INSERT INTO `zt_product`(`id`,`name`,`code`,`type`,`status`,`desc`,`PO`,`QD`,`RD`,`acl`,`whitelist`,`createdBy`,`createdDate`,`createdVersion`,`order`,`deleted`) VALUES ('3','click_前端模板','click_front end','normal','normal','','yuchunyu','yuchunyu','yuchunyu','open','','neroyang','2016-11-18 20:23:50','8.3','15','0');
DROP TABLE IF EXISTS `zt_productplan`;
CREATE TABLE `zt_productplan` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL,
  `branch` mediumint(8) unsigned NOT NULL,
  `title` varchar(90) NOT NULL,
  `desc` text NOT NULL,
  `begin` date NOT NULL,
  `end` date NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `plan` (`product`,`end`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_project`;
CREATE TABLE `zt_project` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `isCat` enum('1','0') NOT NULL DEFAULT '0',
  `catID` mediumint(8) unsigned NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'sprint',
  `parent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(90) NOT NULL,
  `code` varchar(45) NOT NULL,
  `begin` date NOT NULL,
  `end` date NOT NULL,
  `days` smallint(5) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `statge` enum('1','2','3','4','5') NOT NULL DEFAULT '1',
  `pri` enum('1','2','3','4') NOT NULL DEFAULT '1',
  `desc` text NOT NULL,
  `openedBy` varchar(30) NOT NULL DEFAULT '',
  `openedDate` int(10) unsigned NOT NULL DEFAULT '0',
  `openedVersion` varchar(20) NOT NULL,
  `closedBy` varchar(30) NOT NULL DEFAULT '',
  `closedDate` int(10) unsigned NOT NULL DEFAULT '0',
  `canceledBy` varchar(30) NOT NULL DEFAULT '',
  `canceledDate` int(10) unsigned NOT NULL DEFAULT '0',
  `PO` varchar(30) NOT NULL DEFAULT '',
  `PM` varchar(30) NOT NULL DEFAULT '',
  `QD` varchar(30) NOT NULL DEFAULT '',
  `RD` varchar(30) NOT NULL DEFAULT '',
  `team` varchar(30) NOT NULL,
  `acl` enum('open','private','custom') NOT NULL DEFAULT 'open',
  `whitelist` varchar(255) NOT NULL,
  `order` mediumint(8) unsigned NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `project` (`parent`,`begin`,`end`,`status`,`order`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
INSERT INTO `zt_project`(`id`,`isCat`,`catID`,`type`,`parent`,`name`,`code`,`begin`,`end`,`days`,`status`,`statge`,`pri`,`desc`,`openedBy`,`openedDate`,`openedVersion`,`closedBy`,`closedDate`,`canceledBy`,`canceledDate`,`PO`,`PM`,`QD`,`RD`,`team`,`acl`,`whitelist`,`order`,`deleted`) VALUES ('1','0','0','sprint','0','click','clickgwas','2016-11-18','2016-12-31','31','doing','1','1','','','0','8.3','','0','','0','neroyang','neroyang','neroyang','neroyang','clickgwas','open','','5','0');
INSERT INTO `zt_project`(`id`,`isCat`,`catID`,`type`,`parent`,`name`,`code`,`begin`,`end`,`days`,`status`,`statge`,`pri`,`desc`,`openedBy`,`openedDate`,`openedVersion`,`closedBy`,`closedDate`,`canceledBy`,`canceledDate`,`PO`,`PM`,`QD`,`RD`,`team`,`acl`,`whitelist`,`order`,`deleted`) VALUES ('2','0','0','sprint','0','新同学学习','study','2016-11-18','2016-12-31','31','doing','1','1','','','0','8.3','','0','','0','','','','','新同学学习','open','','10','0');
DROP TABLE IF EXISTS `zt_projectproduct`;
CREATE TABLE `zt_projectproduct` (
  `project` mediumint(8) unsigned NOT NULL,
  `product` mediumint(8) unsigned NOT NULL,
  `branch` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`project`,`product`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `zt_projectproduct`(`project`,`product`,`branch`) VALUES ('1','1','0');
INSERT INTO `zt_projectproduct`(`project`,`product`,`branch`) VALUES ('1','2','0');
INSERT INTO `zt_projectproduct`(`project`,`product`,`branch`) VALUES ('1','3','0');
DROP TABLE IF EXISTS `zt_projectstory`;
CREATE TABLE `zt_projectstory` (
  `project` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `product` mediumint(8) unsigned NOT NULL,
  `story` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `version` smallint(6) NOT NULL DEFAULT '1',
  UNIQUE KEY `project` (`project`,`story`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_release`;
CREATE TABLE `zt_release` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `branch` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `build` mediumint(8) unsigned NOT NULL,
  `name` char(30) NOT NULL DEFAULT '',
  `date` date NOT NULL,
  `stories` text NOT NULL,
  `bugs` text NOT NULL,
  `leftBugs` text NOT NULL,
  `desc` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'normal',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `build` (`build`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_story`;
CREATE TABLE `zt_story` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `product` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `branch` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `module` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `plan` text NOT NULL,
  `source` varchar(20) NOT NULL,
  `sourceNote` varchar(255) NOT NULL,
  `fromBug` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT '',
  `pri` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `estimate` float unsigned NOT NULL,
  `status` enum('','changed','active','draft','closed') NOT NULL DEFAULT '',
  `color` char(7) NOT NULL,
  `stage` enum('','wait','planned','projected','developing','developed','testing','tested','verified','released') NOT NULL DEFAULT 'wait',
  `mailto` varchar(255) NOT NULL DEFAULT '',
  `openedBy` varchar(30) NOT NULL DEFAULT '',
  `openedDate` datetime NOT NULL,
  `assignedTo` varchar(30) NOT NULL DEFAULT '',
  `assignedDate` datetime NOT NULL,
  `lastEditedBy` varchar(30) NOT NULL DEFAULT '',
  `lastEditedDate` datetime NOT NULL,
  `reviewedBy` varchar(255) NOT NULL,
  `reviewedDate` date NOT NULL,
  `closedBy` varchar(30) NOT NULL DEFAULT '',
  `closedDate` datetime NOT NULL,
  `closedReason` varchar(30) NOT NULL,
  `toBug` mediumint(9) NOT NULL,
  `childStories` varchar(255) NOT NULL,
  `linkStories` varchar(255) NOT NULL,
  `duplicateStory` mediumint(8) unsigned NOT NULL,
  `version` smallint(6) NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `story` (`product`,`module`,`status`,`assignedTo`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('1','2','0','0','','customer','基础功能','0','用户登陆','','','0','0','draft','','wait',',neroyang,wjd','neroyang','2016-11-18 20:28:06','wjd','2016-11-18 20:28:06','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('2','2','0','0','','','','0','问题发布，评论，回复，阅读次数','','','0','0','draft','','wait',',wjd','neroyang','2016-11-18 21:49:28','VickySong','2016-11-18 21:49:28','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('3','1','0','1','','','','0','数据库新方案','','','0','0','draft','','wait','','neroyang','2016-11-18 21:52:01','neroyang','2016-11-18 21:52:01','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('4','1','0','1','','','','0','beesworm','','','0','0','active','','wait','','neroyang','2016-11-18 21:52:24','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('5','1','0','2','','','','0','资源文件上传','','','0','0','active','','wait','','neroyang','2016-11-18 21:53:09','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('6','1','0','2','','','','0','新闻发布','','','0','0','active','','wait','','neroyang','2016-11-18 21:53:50','','0000-00-00 00:00:00','neroyang','2016-11-18 21:54:20','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('7','1','0','3','','','','0','用户注册','','','0','0','active','','wait','','neroyang','2016-11-18 21:54:51','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('8','1','0','3','','','','0','实现用户认证登陆','','','0','0','active','','wait','','neroyang','2016-11-18 21:55:06','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('9','1','0','3','','','','0','用户认证','','','0','0','active','','wait','','neroyang','2016-11-18 21:55:25','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
INSERT INTO `zt_story`(`id`,`product`,`branch`,`module`,`plan`,`source`,`sourceNote`,`fromBug`,`title`,`keywords`,`type`,`pri`,`estimate`,`status`,`color`,`stage`,`mailto`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`lastEditedBy`,`lastEditedDate`,`reviewedBy`,`reviewedDate`,`closedBy`,`closedDate`,`closedReason`,`toBug`,`childStories`,`linkStories`,`duplicateStory`,`version`,`deleted`) VALUES ('10','1','0','2','','','','0','用户相关操作','','','0','0','active','','wait','','neroyang','2016-11-18 21:56:10','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00','','0000-00-00 00:00:00','','0','','','0','1','0');
DROP TABLE IF EXISTS `zt_storyspec`;
CREATE TABLE `zt_storyspec` (
  `story` mediumint(9) NOT NULL,
  `version` smallint(6) NOT NULL,
  `title` varchar(90) NOT NULL,
  `spec` text NOT NULL,
  `verify` text NOT NULL,
  UNIQUE KEY `story` (`story`,`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('1','1','用户登陆','接入sso系统实现用户登入','安全登入');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('2','1','问题发布，评论，回复，阅读次数','问题发布，评论，回复，阅读次数，点赞','');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('3','1','数据库新方案','数据库使用新方案，重写mapper层','与旧版无异');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('4','1','beesworm','beesworm相关功能','');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('5','1','资源文件上传','资源管理中心，实现资源上传','');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('6','1','新闻发布','实现富文本新闻发布','');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('7','1','用户注册','实现用户邮件注册','');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('8','1','实现用户认证登陆','','');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('9','1','用户认证','实现用户token认证','');
INSERT INTO `zt_storyspec`(`story`,`version`,`title`,`spec`,`verify`) VALUES ('10','1','用户相关操作','实现用户增删改查等操作','');
DROP TABLE IF EXISTS `zt_storystage`;
CREATE TABLE `zt_storystage` (
  `story` mediumint(8) unsigned NOT NULL,
  `branch` mediumint(8) unsigned NOT NULL,
  `stage` varchar(50) NOT NULL,
  KEY `story` (`story`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_task`;
CREATE TABLE `zt_task` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `project` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `module` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `story` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `storyVersion` smallint(6) NOT NULL DEFAULT '1',
  `fromBug` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `pri` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `estimate` float unsigned NOT NULL,
  `consumed` float unsigned NOT NULL,
  `left` float unsigned NOT NULL,
  `deadline` date NOT NULL,
  `status` enum('wait','doing','done','pause','cancel','closed') NOT NULL DEFAULT 'wait',
  `color` char(7) NOT NULL,
  `mailto` varchar(255) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `openedBy` varchar(30) NOT NULL,
  `openedDate` datetime NOT NULL,
  `assignedTo` varchar(30) NOT NULL,
  `assignedDate` datetime NOT NULL,
  `estStarted` date NOT NULL,
  `realStarted` date NOT NULL,
  `finishedBy` varchar(30) NOT NULL,
  `finishedDate` datetime NOT NULL,
  `canceledBy` varchar(30) NOT NULL,
  `canceledDate` datetime NOT NULL,
  `closedBy` varchar(30) NOT NULL,
  `closedDate` datetime NOT NULL,
  `closedReason` varchar(30) NOT NULL,
  `lastEditedBy` varchar(30) NOT NULL,
  `lastEditedDate` datetime NOT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `task` (`project`,`module`,`story`,`assignedTo`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('1','1','1','0','1','0','【database】数据新方案','devel','1','70','70','0','2016-11-30','done','',',bjh,neroyang','','neroyang','2016-11-18 22:00:56','bjh','2016-11-27 02:34:19','2016-11-18','2016-11-18','neroyang','2016-11-27 02:34:19','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-27 02:34:19','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('2','1','0','0','1','0','【社区】问答社区','devel','3','250','3000','0','2016-12-25','done','','','','neroyang','2016-11-18 22:03:12','neroyang','2017-06-16 02:06:29','2016-11-30','2016-11-18','neroyang','2017-06-16 02:06:29','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2017-06-16 02:06:29','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('3','2','0','0','1','0','安装linux操作系统','misc','0','0','4','0','2016-11-19','done','','','安装并熟悉linux','neroyang','2016-11-18 22:16:03','gqf','2016-11-25 14:54:36','2016-11-18','2016-11-18','neroyang','2016-11-25 14:54:36','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-25 14:54:36','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('4','2','0','0','1','0','学习html+css,仿照实现www.taobao.com首页布局','misc','0','0','20','0','2016-11-30','done','','','学习html+css,仿照实现www.taobao.com首页布局','neroyang','2016-11-18 22:22:39','neroyang','2016-11-30 23:20:30','2016-11-18','2016-11-18','szy','2016-11-30 23:20:30','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','szy','2016-11-30 23:20:30','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('5','1','0','0','1','0','项目框架搭建及整体设计','design','3','70','0','70','2016-11-25','doing','',',wjd','问答社区软件整体设计方案','neroyang','2016-11-18 23:16:46','wjd','2016-11-18 23:20:41','2016-11-18','2016-11-18','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-18 23:20:41','1');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('6','1','0','0','1','0','【社区】问答社区软件整体设计','design','2','70','1','0','2016-11-26','done','',',VickySong','问答社区软件整体设计方案','neroyang','2016-11-18 23:18:48','wjd','2016-11-25 13:14:13','2016-11-18','0000-00-00','neroyang','2016-11-25 13:14:13','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-25 13:14:13','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('7','2','0','0','1','0','springmvc学习','misc','3','70','0','70','2016-11-24','doing','',',tyf','学习springmvc基础，搭建springmvc，开发一个简易留言板，实现留言增删改查','neroyang','2016-11-18 23:25:03','tyf','2016-11-18 23:25:23','2016-11-18','2016-11-18','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-18 23:25:23','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('8','1','0','0','1','0','【database】数据库新方案数据','design','1','50','70','0','2016-11-25','done','',',bjh','数据库新方案之后相关sql文件','neroyang','2016-11-19 01:44:28','bjh','2016-11-25 19:37:29','2016-11-19','2016-11-19','neroyang','2016-11-25 19:37:29','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-25 19:37:29','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('9','2','7','0','1','0','laravel框架搭建及初级学习','misc','3','70','0','70','2016-11-26','doing','',',lifeng','<p>搭建lamp开发环境，并搭建laravel框架.</p>
<p>laravel5.1.11的一键安装包在附件里.</p>
<p>解压后放到wamp/www/目录下即可</p>
<p><br /></p>
<p><br /></p>','neroyang','2016-11-19 13:21:29','lifeng','2016-11-19 13:22:21','2016-11-19','2016-11-19','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','wjd','2016-11-25 17:45:20','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('10','1','2','0','1','0','【resource service】ResourceService 测试','test','1','5','7','0','2016-11-20','done','',',neroyang','测试资源上传及管理功能','neroyang','2016-11-19 13:28:14','neroyang','2016-11-27 02:33:52','2016-11-19','2016-11-19','neroyang','2016-11-27 02:33:52','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-27 02:33:52','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('11','1','5','0','1','0','【resource web】资源管理服务联调','devel','1','7','0','10','2016-11-21','doing','',',neroyang','资源管理后台页面设计以及服务联调','neroyang','2016-11-19 13:29:42','neroyang','2016-11-22 14:58:43','2016-11-20','2016-11-19','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:08:24','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('12','1','0','0','1','0','vpn搭建','affair','4','7','1','0','2016-11-20','closed','',',yuchunyu','翻墙vpn搭建','neroyang','2016-11-19 13:31:20','closed','2016-11-19 16:19:47','2016-11-19','2016-11-19','neroyang','2016-11-19 13:49:54','','0000-00-00 00:00:00','neroyang','2016-11-19 16:19:47','done','neroyang','2016-11-19 16:19:47','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('28','1','1','0','1','0','【数据库】分布式数据库','devel','0','0','0','0','0000-00-00','wait','','','','neroyang','2016-11-22 20:18:00','neroyang','2016-11-22 20:18:00','0000-00-00','0000-00-00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:05:00','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('13','1','1','0','1','0','【data web】beesworm boxplot','devel','1','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 19:54:39','neroyang','2016-11-22 19:55:50','0000-00-00','0000-00-00','neroyang','2016-11-22 19:55:50','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:11:53','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('14','1','1','0','1','0','【data web】beesworm cutoff','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 19:55:01','neroyang','2016-11-22 19:55:44','0000-00-00','0000-00-00','neroyang','2016-11-22 19:55:44','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:11:39','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('15','1','1','0','1','0','【data web】beesworm T-test','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 19:55:23','neroyang','2016-11-22 19:55:39','0000-00-00','0000-00-00','neroyang','2016-11-22 19:55:39','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:11:25','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('16','1','1','0','1','0','【data service】beesworm data','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 19:56:20','neroyang','2016-11-22 19:56:27','0000-00-00','0000-00-00','neroyang','2016-11-22 19:56:27','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:11:10','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('17','1','2','0','1','0','【admin service】analysis模块管理','devel','0','0','0','0','0000-00-00','wait','','','','neroyang','2016-11-22 19:57:31','neroyang','2016-11-22 19:57:31','0000-00-00','0000-00-00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:07:00','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('18','1','4','0','1','0','【data web】analysis模块管理 服务联调','devel','0','0','0','0','0000-00-00','wait','','','','neroyang','2016-11-22 19:58:27','neroyang','2016-11-22 19:58:27','0000-00-00','0000-00-00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:06:45','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('19','1','3','0','1','0','【sso service】login','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 19:58:54','neroyang','2016-11-22 19:59:52','0000-00-00','0000-00-00','neroyang','2016-11-22 19:59:52','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:10:50','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('20','1','3','0','1','0','【sso service】register ','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 19:59:19','neroyang','2016-11-22 19:59:47','0000-00-00','0000-00-00','neroyang','2016-11-22 19:59:47','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:10:36','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('21','1','3','0','1','0','【sso service】auth','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 19:59:35','neroyang','2016-11-22 19:59:40','0000-00-00','0000-00-00','neroyang','2016-11-22 19:59:40','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:10:19','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('22','1','5','0','1','0','【sso web】管理login，auth服务联调','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 20:00:47','neroyang','2016-11-22 20:00:55','0000-00-00','0000-00-00','neroyang','2016-11-22 20:00:55','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:10:05','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('23','1','5','0','1','0','【admin web】模块管理，page管理，资源管理整合','devel','0','0','0','0','0000-00-00','wait','','','','neroyang','2016-11-22 20:03:01','neroyang','2016-11-22 20:03:01','0000-00-00','0000-00-00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:06:28','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('24','1','1','0','1','0','【data service】mountain','devel','0','0','30','0','0000-00-00','done','','','','neroyang','2016-11-22 20:05:01','neroyang','2017-06-16 02:06:02','0000-00-00','2016-11-27','neroyang','2017-06-16 02:06:02','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2017-06-16 02:06:02','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('25','1','1','0','1','0','【data service】manhattan','devel','0','0','0','0','0000-00-00','done','','','','neroyang','2016-11-22 20:05:54','neroyang','2016-11-22 20:05:54','0000-00-00','2016-11-27','neroyang','2016-11-27 17:44:26','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-27 17:44:26','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('26','1','1','0','1','0','【data service】deflection','devel','0','0','0','0','0000-00-00','cancel','','','','neroyang','2016-11-22 20:06:20','neroyang','2016-11-27 02:35:53','0000-00-00','0000-00-00','','0000-00-00 00:00:00','neroyang','2016-11-27 02:35:53','','0000-00-00 00:00:00','','neroyang','2016-11-27 02:35:53','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('27','1','1','0','1','0','【cache service】分布式缓存','devel','0','0','10','0','0000-00-00','done','','','','neroyang','2016-11-22 20:06:47','neroyang','2016-11-22 20:07:00','0000-00-00','0000-00-00','neroyang','2016-11-22 20:07:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-23 16:09:46','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('29','1','5','0','1','0','【集成】服务部署【阿里云】','devel','1','10','10','0','0000-00-00','done','','','','neroyang','2016-11-23 14:46:24','neroyang','2016-11-24 21:12:58','0000-00-00','2016-11-23','neroyang','2016-11-24 21:12:58','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-24 21:12:58','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('30','1','10','0','1','0','【前端】首页修改 1','devel','1','7','100','0','0000-00-00','done','','','<p>about us</p>
<p>links</p>
<p><br /></p>','neroyang','2016-11-23 15:19:13','neroyang','2017-06-16 02:06:18','0000-00-00','2016-11-23','neroyang','2017-06-16 02:06:18','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2017-06-16 02:06:18','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('32','1','11','0','1','0','【log service】分布式日志与日志聚合','devel','3','10','0','10','0000-00-00','doing','','','','neroyang','2016-11-25 14:36:51','neroyang','2016-11-25 14:36:51','0000-00-00','2017-06-16','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2017-06-16 02:06:52','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('31','1','0','0','1','0','【文档】介绍等相关文档编写','affair','3','20','0','20','0000-00-00','doing','','','','neroyang','2016-11-24 22:15:25','czw','2016-11-25 00:07:25','0000-00-00','2016-11-24','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-25 14:38:59','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('33','1','1','0','1','0','【严重】动态代理，生成数据表映射类','devel','1','10','10','0','0000-00-00','done','','','','neroyang','2016-11-25 22:47:25','neroyang','2016-11-27 02:34:05','0000-00-00','2016-11-25','neroyang','2016-11-27 02:34:05','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','neroyang','2016-11-27 02:34:05','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('34','1','1','0','1','0','【data_service】news管理','devel','2','10','0','10','0000-00-00','wait','','','','neroyang','2016-11-28 18:52:30','neroyang','2016-11-28 18:52:30','0000-00-00','0000-00-00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','','0000-00-00 00:00:00','0');
INSERT INTO `zt_task`(`id`,`project`,`module`,`story`,`storyVersion`,`fromBug`,`name`,`type`,`pri`,`estimate`,`consumed`,`left`,`deadline`,`status`,`color`,`mailto`,`desc`,`openedBy`,`openedDate`,`assignedTo`,`assignedDate`,`estStarted`,`realStarted`,`finishedBy`,`finishedDate`,`canceledBy`,`canceledDate`,`closedBy`,`closedDate`,`closedReason`,`lastEditedBy`,`lastEditedDate`,`deleted`) VALUES ('35','1','1','0','1','0','【data_service】paper管理','devel','2','10','0','10','0000-00-00','wait','','','','neroyang','2016-11-28 18:53:00','neroyang','2016-11-28 18:53:00','0000-00-00','0000-00-00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','0000-00-00 00:00:00','','','0000-00-00 00:00:00','0');
DROP TABLE IF EXISTS `zt_taskestimate`;
CREATE TABLE `zt_taskestimate` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `task` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `left` float unsigned NOT NULL DEFAULT '0',
  `consumed` float unsigned NOT NULL,
  `account` char(30) NOT NULL DEFAULT '',
  `work` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `task` (`task`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('1','1','2016-11-18','70','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('2','3','2016-11-18','9','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('3','4','2016-11-18','70','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('4','6','2016-11-18','0','1','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('5','2','2016-11-18','250','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('6','5','2016-11-18','70','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('7','7','2016-11-18','70','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('8','8','2016-11-19','50','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('9','9','2016-11-19','70','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('10','10','2016-11-19','5','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('11','12','2016-11-19','7','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('12','11','2016-11-19','7','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('13','12','2016-11-19','0','1','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('14','10','2016-11-20','0','7','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('15','15','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('16','14','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('17','13','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('18','16','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('19','21','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('20','20','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('21','19','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('22','22','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('23','27','2016-11-22','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('24','30','2016-11-23','7','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('25','29','2016-11-23','10','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('26','29','2016-11-24','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('27','31','2016-11-24','20','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('28','1','2016-11-25','70','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('29','3','2016-11-25','0','4','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('30','8','2016-11-25','0','70','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('31','33','2016-11-25','10','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('32','33','2016-11-27','0','10','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('33','1','2016-11-27','0','70','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('34','24','2016-11-27','30','30','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('35','25','2016-11-27','0','0','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('36','4','2016-11-30','0','20','szy','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('37','30','2017-06-16','0','100','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('38','2','2017-06-16','0','3000','neroyang','');
INSERT INTO `zt_taskestimate`(`id`,`task`,`date`,`left`,`consumed`,`account`,`work`) VALUES ('39','32','2017-06-16','10','0','neroyang','');
DROP TABLE IF EXISTS `zt_team`;
CREATE TABLE `zt_team` (
  `project` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `account` char(30) NOT NULL DEFAULT '',
  `role` char(30) NOT NULL DEFAULT '',
  `join` date NOT NULL DEFAULT '0000-00-00',
  `days` smallint(5) unsigned NOT NULL,
  `hours` float(2,1) unsigned NOT NULL DEFAULT '0.0',
  PRIMARY KEY (`project`,`account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','neroyang','','2016-11-18','31','9.9');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','wjd','研发主管','2016-11-18','31','9.9');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','yuchunyu','研发主管','2016-11-18','31','9.9');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','bjh','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','czw','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','lifeng','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','tws','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','tyf','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','neroyang','','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','czw','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','bjh','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','zhangjian','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','tyf','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','tws','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','lifeng','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','gqf','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('2','szy','研发','2016-11-18','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','zhangjian','研发','2016-11-19','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','gqf','研发','2016-11-19','31','7.0');
INSERT INTO `zt_team`(`project`,`account`,`role`,`join`,`days`,`hours`) VALUES ('1','szy','研发','2016-11-19','31','7.0');
DROP TABLE IF EXISTS `zt_testresult`;
CREATE TABLE `zt_testresult` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `run` mediumint(8) unsigned NOT NULL,
  `case` mediumint(8) unsigned NOT NULL,
  `version` smallint(5) unsigned NOT NULL,
  `caseResult` char(30) NOT NULL,
  `stepResults` text NOT NULL,
  `lastRunner` varchar(30) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `testresult` (`case`,`version`,`run`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_testrun`;
CREATE TABLE `zt_testrun` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `task` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `case` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `version` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `assignedTo` char(30) NOT NULL DEFAULT '',
  `lastRunner` varchar(30) NOT NULL,
  `lastRunDate` datetime NOT NULL,
  `lastRunResult` char(30) NOT NULL,
  `status` char(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task` (`task`,`case`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_testtask`;
CREATE TABLE `zt_testtask` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(90) NOT NULL,
  `product` mediumint(8) unsigned NOT NULL,
  `project` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `build` char(30) NOT NULL,
  `owner` varchar(30) NOT NULL,
  `pri` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `begin` date NOT NULL,
  `end` date NOT NULL,
  `mailto` varchar(255) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `report` text NOT NULL,
  `status` enum('blocked','doing','wait','done') NOT NULL DEFAULT 'wait',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `build` (`build`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_todo`;
CREATE TABLE `zt_todo` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(30) NOT NULL,
  `date` date NOT NULL,
  `begin` smallint(4) unsigned zerofill NOT NULL,
  `end` smallint(4) unsigned zerofill NOT NULL,
  `type` char(10) NOT NULL,
  `idvalue` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pri` tinyint(3) unsigned NOT NULL,
  `name` char(150) NOT NULL,
  `desc` text NOT NULL,
  `status` enum('wait','doing','done') NOT NULL DEFAULT 'wait',
  `private` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `todo` (`account`,`date`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
INSERT INTO `zt_todo`(`id`,`account`,`date`,`begin`,`end`,`type`,`idvalue`,`pri`,`name`,`desc`,`status`,`private`) VALUES ('1','zhangjian','2016-11-18','2400','2400','custom','0','3','张健  论坛','','wait','0');
INSERT INTO `zt_todo`(`id`,`account`,`date`,`begin`,`end`,`type`,`idvalue`,`pri`,`name`,`desc`,`status`,`private`) VALUES ('2','gqf','2016-11-18','2400','2400','custom','0','3','关起飞  服务器','','done','0');
INSERT INTO `zt_todo`(`id`,`account`,`date`,`begin`,`end`,`type`,`idvalue`,`pri`,`name`,`desc`,`status`,`private`) VALUES ('4','zhangjian','2016-11-19','2400','2400','custom','0','3','张健 论坛 2426640261@qq.com','','wait','0');
DROP TABLE IF EXISTS `zt_user`;
CREATE TABLE `zt_user` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `dept` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `account` char(30) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `role` char(10) NOT NULL DEFAULT '',
  `realname` char(30) NOT NULL DEFAULT '',
  `nickname` char(60) NOT NULL DEFAULT '',
  `commiter` varchar(100) NOT NULL,
  `avatar` char(30) NOT NULL DEFAULT '',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `gender` enum('f','m') NOT NULL DEFAULT 'f',
  `email` char(90) NOT NULL DEFAULT '',
  `skype` char(90) NOT NULL DEFAULT '',
  `qq` char(20) NOT NULL DEFAULT '',
  `yahoo` char(90) NOT NULL DEFAULT '',
  `gtalk` char(90) NOT NULL DEFAULT '',
  `wangwang` char(90) NOT NULL DEFAULT '',
  `mobile` char(11) NOT NULL DEFAULT '',
  `phone` char(20) NOT NULL DEFAULT '',
  `address` char(120) NOT NULL DEFAULT '',
  `zipcode` char(10) NOT NULL DEFAULT '',
  `join` date NOT NULL DEFAULT '0000-00-00',
  `visits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `last` int(10) unsigned NOT NULL DEFAULT '0',
  `fails` tinyint(5) NOT NULL DEFAULT '0',
  `locked` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ranzhi` char(30) NOT NULL DEFAULT '',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`),
  KEY `user` (`dept`,`email`,`commiter`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('1','0','neroyang','bfcc0f5782a9eaf6ae10c40ad239d974','td','neroyang','','','','0000-00-00','m','nerosoft@outlook.com','','','','','','','','','','2016-11-01','91','202.113.13.139','1511075102','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('2','1','wjd','bb388449551c96f949dd6c99e7005a21','td','吴金东','','','','0000-00-00','m','461062411@qq.com','','','','','','','','','','2016-11-01','2','211.81.53.34','1480066421','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('3','1','yuchunyu','698423b50cadf4e548536f39c10b3aa3','td','于春钰','','','','0000-00-00','m','yuchunyu97@163.com','','','','','','','','','','2016-11-01','1','202.113.176.112','1479476055','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('4','0','VickySong','96e79218965eb72c92a549dd5a330112','top','宋老师','','','','0000-00-00','f','','','','','','','','','','','2016-11-01','2','202.113.176.14','1479877719','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('5','0','bjh','19e5bd1b0f2b239146eb82e978570d35','td','毕家豪','','','','0000-00-00','m','1163287093@qq.com','','','','','','','','','','2016-11-01','15','104.160.45.49','1485923101','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('6','0','czw','96e79218965eb72c92a549dd5a330112','td','仇哲炜','','','','0000-00-00','m','','','','','','','','','','','2016-11-01','2','223.104.227.254','1480059554','5','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('7','0','zhangjian','96e79218965eb72c92a549dd5a330112','dev','张健','','','','0000-00-00','m','2426640261@qq.com','','','','','','','','','','2016-11-01','10','123.151.40.34','1481461466','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('8','0','lifeng','96e79218965eb72c92a549dd5a330112','dev','李锋','','','','0000-00-00','m','','','','','','','','','','','2016-11-01','3','123.151.64.142','1481696573','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('9','0','tws','96e79218965eb72c92a549dd5a330112','dev','谭为绶','','','','0000-00-00','m','','','','','','','','','','','2016-11-01','6','202.113.13.136','1492232100','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('10','0','tyf','96e79218965eb72c92a549dd5a330112','dev','仝逸凡','','','','0000-00-00','m','565813476@qq.com','','','','','','','','','','2016-11-01','33','202.113.13.145','1510746935','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('11','0','gqf','96e79218965eb72c92a549dd5a330112','dev','关起飞','','','','0000-00-00','m','','','','','','','','','','','2016-11-01','9','123.151.42.57','1499045757','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('12','0','szy','96e79218965eb72c92a549dd5a330112','dev','宋峥元','','','','0000-00-00','m','','','','','','','','','','','2016-11-01','16','202.113.176.100','1490364962','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('13','0','zyf','96e79218965eb72c92a549dd5a330112','dev','张义飞','','','','0000-00-00','m','','','','','','','','','','','2016-12-02','2','202.113.13.157','1480736541','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('14','0','zmh','96e79218965eb72c92a549dd5a330112','dev','郑敏航','','','','0000-00-00','m','','','','','','','','','','','2016-12-02','3','101.226.69.109','1480776409','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('15','0','huanghao','96e79218965eb72c92a549dd5a330112','dev','黄浩','','','','0000-00-00','m','','','','','','','','','','','2016-12-03','5','202.113.176.176','1482741242','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('16','0','jiangpeng','96e79218965eb72c92a549dd5a330112','dev','姜朋','','','','0000-00-00','m','','','','','','','','','','','2016-12-03','3','211.81.52.3','1481633172','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('17','0','xrs','96e79218965eb72c92a549dd5a330112','dev','徐若思','','','','0000-00-00','m','','','','','','','','','','','2016-12-03','1','106.47.240.242','1480768708','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('18','0','zxt','96e79218965eb72c92a549dd5a330112','dev','zhangxiaotong','','','','0000-00-00','m','','','','','','','','','','','2016-12-07','2','106.47.237.27','1481267999','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('19','0','rwb','96e79218965eb72c92a549dd5a330112','dev','renwenbing','','','','0000-00-00','m','','','','','','','','','','','2016-12-07','4','202.113.13.129','1481593384','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('20','0','dym','670b14728ad9902aecba32e22fa4f6bd','dev','dongyanmei','','','','0000-00-00','m','','','','','','','','','','','2016-12-16','0','','0','0','0000-00-00 00:00:00','','1');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('21','0','qzw','670b14728ad9902aecba32e22fa4f6bd','td','仇哲炜','','','','0000-00-00','m','','','','','','','','','','','2017-01-01','1','104.160.45.49','1484542341','0','0000-00-00 00:00:00','','0');
INSERT INTO `zt_user`(`id`,`dept`,`account`,`password`,`role`,`realname`,`nickname`,`commiter`,`avatar`,`birthday`,`gender`,`email`,`skype`,`qq`,`yahoo`,`gtalk`,`wangwang`,`mobile`,`phone`,`address`,`zipcode`,`join`,`visits`,`ip`,`last`,`fails`,`locked`,`ranzhi`,`deleted`) VALUES ('22','4','que1240434456','dab4b04d4d5e788a9c68cdb8ae0ad515','top','董艳梅','','','','0000-00-00','f','1240434456@qq.com','','','','','','','','','','2017-02-01','6','104.160.45.49','1487928523','0','0000-00-00 00:00:00','','0');
DROP TABLE IF EXISTS `zt_usercontact`;
CREATE TABLE `zt_usercontact` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(30) NOT NULL,
  `listName` varchar(60) NOT NULL,
  `userList` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account` (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_usergroup`;
CREATE TABLE `zt_usergroup` (
  `account` char(30) NOT NULL DEFAULT '',
  `group` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `account` (`account`,`group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('bjh','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('bjh','14');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('czw','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('dym','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('gqf','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('huanghao','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('jiangpeng','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('lifeng','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('neroyang','1');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('neroyang','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('neroyang','3');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('neroyang','6');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('neroyang','8');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('neroyang','13');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('neroyang','16');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('que1240434456','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('que1240434456','3');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('que1240434456','6');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('que1240434456','8');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('que1240434456','9');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('qzw','6');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('rwb','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('szy','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('tws','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('tws','13');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('tyf','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('tyf','13');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('VickySong','9');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('wjd','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('wjd','3');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('wjd','6');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('wjd','15');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('xrs','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('yuchunyu','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('yuchunyu','3');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('yuchunyu','6');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('yuchunyu','12');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('zhangjian','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('zmh','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('zxt','2');
INSERT INTO `zt_usergroup`(`account`,`group`) VALUES ('zyf','2');
DROP TABLE IF EXISTS `zt_userquery`;
CREATE TABLE `zt_userquery` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(30) NOT NULL,
  `module` varchar(30) NOT NULL,
  `title` varchar(90) NOT NULL,
  `form` text NOT NULL,
  `sql` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `query` (`account`,`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `zt_usertpl`;
CREATE TABLE `zt_usertpl` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(30) NOT NULL,
  `type` char(30) NOT NULL,
  `title` varchar(150) NOT NULL,
  `content` text NOT NULL,
  `public` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `account` (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
